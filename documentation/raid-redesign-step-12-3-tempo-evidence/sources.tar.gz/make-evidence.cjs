const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const base = __dirname, repo = '/home/user/projects/project-seeker';
const output = repo + '/documentation/raid-redesign-step-12-3-tempo-evidence';
const sha = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const copy = (from,to) => {fs.mkdirSync(path.dirname(to),{recursive:true});fs.copyFileSync(from,to);};
const changed = [
  'game/src/main/java/ru/homyakin/seeker/game/battle/Battle.java',
  'game/src/main/java/ru/homyakin/seeker/game/battle/BattleContext.java',
  'game/src/main/java/ru/homyakin/seeker/game/battle/BattleInitState.java',
  'game/src/main/java/ru/homyakin/seeker/game/battle/BattlePersonage.java',
  'game/src/main/java/ru/homyakin/seeker/game/battle/BattleTempoVersion.java',
  'game/src/main/java/ru/homyakin/seeker/game/battle/PlayerCombatConfig.java',
  'game/src/main/java/ru/homyakin/seeker/game/duel/DuelService.java',
  'game/src/main/java/ru/homyakin/seeker/game/event/anomaly/action/AnomalyBattleService.java',
  'game/src/main/java/ru/homyakin/seeker/game/event/raid/processing/RaidProcessing.java',
  'game/src/main/java/ru/homyakin/seeker/game/event/world_raid/action/ProcessWorldRaidBattleCommand.java',
  'game/src/main/java/ru/homyakin/seeker/game/item/catalog/EquipmentReleaseCoordinator.java',
  'game/src/main/resources/application.properties',
  'game/src/test/java/ru/homyakin/seeker/game/battle/Step123BattleRunner.java',
  'game/src/test/java/ru/homyakin/seeker/game/battle/BattleTempoTest.java',
  'game/src/test/java/ru/homyakin/seeker/game/battle/BattleTempoVersionTest.java',
  'game/src/test/java/ru/homyakin/seeker/game/battle/PlayerCombatConfigTest.java',
  'game/src/test/java/ru/homyakin/seeker/game/item/catalog/EquipmentReleaseCoordinatorTest.java',
  'game/src/test/java/ru/homyakin/seeker/game/item/catalog/EquipmentReleaseNumericDomainTest.java'
];
if (process.argv.includes('--prepare')) {
  const pvp = JSON.parse(fs.readFileSync(base+'/pvp-fast.json'));
  for (const [key,value] of Object.entries(pvp.sourceHashes)) {
    if (!value || typeof value !== 'object' || !value.readFrom || key === 'temporaryHarness') continue;
    if (!(key.startsWith('game/src/main/java/')&&key.endsWith('.java')) &&
        !(key.startsWith('game/src/main/resources/game-data/')&&key.endsWith('.toml'))) throw Error('Unexpected input '+key);
    if (sha(value.readFrom)!==value.sha256) throw Error('Captured source changed '+key);
    copy(value.readFrom, base+'/frozen-inputs/'+key);
  }
  for (const relative of changed) copy(repo+'/'+relative, base+'/frozen-inputs/'+relative);
  for (const name of ['Battle','BattleContext','BattlePersonage','BattleTempoVersion']) {
    const relative = 'ru/homyakin/seeker/game/battle/'+name+'.class';
    copy(repo+'/game/target/classes/'+relative,base+'/production-classes/'+relative);
  }
  copy(repo+'/game/target/classes/application.properties',base+'/production-classes/application.properties');
  let totals={tests:0,failures:0,errors:0,skipped:0}, suites=[];
  const reports=repo+'/game/target/surefire-reports';
  for(const f of fs.readdirSync(reports).filter(f=>f.startsWith('TEST-')&&f.endsWith('.xml'))){
    const text=fs.readFileSync(reports+'/'+f,'utf8'), tag=text.match(/<testsuite\b[^>]*>/)?.[0];
    if(!tag)continue;
    const row={name:tag.match(/name="([^"]*)"/)?.[1]};
    for(const key of Object.keys(totals)){row[key]=Number(tag.match(new RegExp(key+'="([^"]*)"'))?.[1]||0);totals[key]+=row[key];}
    suites.push(row);
  }
  const log=fs.readFileSync(base+'/full-build.log','utf8');
  if(!log.includes('BUILD SUCCESS')||totals.errors||totals.failures)throw Error('Build not successful');
  const summary={status:'PASS',command:'mvn clean package with explicit Mockito and JaCoCo JVM agents',
    jdk:'25.0.1',checkstyle:'PASS',...totals,passed:totals.tests-totals.skipped,
    skippedSuites:suites.filter(s=>s.skipped),suites,fullBuildLogSha256:sha(base+'/full-build.log'),
    note:'Private process properties from Surefire XML and the local application profile are deliberately not exported. PostgreSQL integration environment not enabled.'};
  fs.writeFileSync(base+'/test-summary.json',JSON.stringify(summary,null,2)+'\n');
  const data=['pvp-fast.json','pvp-baseline.json','pve-fast.json','pve-baseline.json'];
  for(const kind of ['screen','confirm'])for(const suffix of ['summary.json','cases.json.gz','raw.jsonl.gz'])data.push(`${kind}-fast-${suffix}`);
  const sources=['source','classes','frozen-inputs','production-classes','validator.cjs','class-origins.json','test-summary.json','make-evidence.cjs'];
  fs.writeFileSync(base+'/source-entries.list0',sources.join('\0')+'\0');
  fs.writeFileSync(base+'/data-entries.list0',data.join('\0')+'\0');
} else {
  const validation=JSON.parse(fs.readFileSync(base+'/equivalence.json'));
  if(validation.status!=='PASS'||validation.totalBattles!==90200)throw Error('Equivalence incomplete');
  for(const f of ['equivalence.json','test-summary.json'])copy(base+'/'+f,output+'/'+f);
  const files=['equivalence.json','test-summary.json','sources.tar.gz','measurements.tar.gz'];
  const manifest={date:'2026-11-02',baseCommit:'09bb5ef70753e9c95cb3772e4024456ba7d7a208',
    battleTempoVersion:'ACCELERATED_V1',damageMultiplier:'7/4',defaultTempo:'BASELINE_V1',activated:false,
    scope:'Selected public source and class snapshots, not the whole repository or private profiles',
    files:Object.fromEntries(files.map(f=>[f,{sha256:sha(output+'/'+f),bytes:fs.statSync(output+'/'+f).size}])),
    implementationInputs:Object.fromEntries(changed.map(f=>[f,sha(base+'/frozen-inputs/'+f)]))};
  fs.writeFileSync(output+'/manifest.json',JSON.stringify(manifest,null,2)+'\n');
  console.log(JSON.stringify({status:'PASS',battles:validation.totalBattles,tests:JSON.parse(fs.readFileSync(base+'/test-summary.json')).passed,files:manifest.files},null,2));
}
