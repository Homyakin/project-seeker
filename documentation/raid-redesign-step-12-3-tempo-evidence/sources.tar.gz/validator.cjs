const fs = require('fs');
const zlib = require('zlib');
const crypto = require('crypto');
const path = require('path');
// Usage: node validator.cjs [integration-directory] [experiment-directory] [repository-directory]
const integration = path.resolve(process.argv[2] || __dirname);
const experiment = path.resolve(process.argv[3] || '/tmp/seeker-damage-tempo.ZVEAzz');
const repository = path.resolve(process.argv[4] || '/home/user/projects/project-seeker');
const errors = [];
const checks = [];
let summaryNumbersChecked = 0;
function read(file) {
  let value = fs.readFileSync(file);
  if (file.endsWith('.gz')) value = zlib.gunzipSync(value);
  return value.toString();
}
function parse(text) {
  return JSON.parse(text, (key, value, context) =>
    /seed$/i.test(key) && typeof value === 'number' ? context.source : value);
}
function load(file) { return parse(read(file)); }
function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === 'object') return Object.fromEntries(
    Object.keys(value).sort().map(key => [key, canonical(value[key])]));
  return value;
}
function eq(left, right, label) {
  const same = JSON.stringify(canonical(left)) === JSON.stringify(canonical(right));
  checks.push({ label, equal: same });
  if (!same) errors.push(label);
  return same;
}
function assert(test, label) {
  if (!test) errors.push(label);
}
function statistics(values) {
  const sorted = values.toSorted((a, b) => a - b), count = sorted.length;
  return {mean: sorted.reduce((a,b) => a+b, 0)/count,
    median: count%2 ? sorted[(count-1)/2] : (sorted[count/2-1]+sorted[count/2])/2,
    p95: sorted[Math.ceil(.95*count)-1], min: sorted[0], max: sorted[count-1]};
}
function validateStatistics(expected, values, label) {
  for (const [name, actual] of Object.entries(statistics(values))) {
    assert(Math.abs(actual - expected[name]) < 1e-9, `${label}.${name}`);
    summaryNumbersChecked++;
  }
}
function sha(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function rawLines(file) { return read(file).trimEnd().split('\n').map(parse); }
function publicSource(relative) {
  const frozen = `${integration}/frozen-inputs/${relative}`;
  return fs.existsSync(frozen) ? frozen : `${repository}/${relative}`;
}
function capturedSource(key, value) {
  if (key === 'temporaryHarness')
    return `${integration}/source/ru/homyakin/seeker/game/battle/DurationComparison.java`;
  const frozen = `${integration}/frozen-inputs/${key}`;
  return fs.existsSync(frozen) ? frozen : value.readFrom;
}
function compiledProduction(relative) {
  const frozen = `${integration}/production-classes/${relative}`;
  return fs.existsSync(frozen) ? frozen : `${repository}/game/target/classes/${relative}`;
}
const comparisons = [];
function pvp(suffix, factor) {
  const actual = load(`${integration}/pvp-${suffix}.json`);
  const expected = load(`${experiment}/pvp-${factor}.json`);
  eq(actual.manifest, expected.manifest, `PvP ${suffix}: complete equipment manifests`);
  eq(actual.raw, expected.raw, `PvP ${suffix}: complete raw observations including exact 64-bit seed lexemes`);
  eq(actual.summaries, expected.summaries, `PvP ${suffix}: complete summaries`);
  eq(Object.fromEntries(Object.entries(actual).filter(([key]) => key !== 'sourceHashes')),
    Object.fromEntries(Object.entries(expected).filter(([key]) => key !== 'sourceHashes')),
    `PvP ${suffix}: complete artifact excluding provenance hashes`);
  assert(actual.raw.length === 24000 && actual.summaries.length === 48, `PvP ${suffix}: 24000/48 size`);
  for (const summary of actual.summaries) {
    const rows = actual.raw.filter(row => row.condition === summary.condition);
    assert(rows.length === 500, `PvP ${suffix}/${summary.condition}: n=500`);
    for (const field of ['rounds', 'turnsBothTeams', 'turnsFirstTeam', 'turnsSecondTeam'])
      validateStatistics(summary[field], rows.map(row => row[field]), `PvP ${suffix}/${summary.condition}/${field}`);
    assert(summary.timeouts === rows.filter(row => row.timeout).length, `PvP ${suffix}/${summary.condition}: timeouts`);
  }
  let hashes = 0;
  for (const [key, value] of Object.entries(actual.sourceHashes)) {
    if (value && typeof value === 'object' && value.readFrom && value.sha256) {
      assert(sha(capturedSource(key, value)) === value.sha256, `PvP ${suffix}: captured source hash ${key}`);
      hashes++;
    }
  }
  comparisons.push({kind:'pvp', variant:suffix, previousNumerator:factor, battles:actual.raw.length,
    conditions:actual.conditions, capturedSourceHashesValidated:hashes, timeouts:actual.raw.filter(row=>row.timeout).length});
}
function pve(suffix, factor) {
  const actual = load(`${integration}/pve-${suffix}.json`), expected = load(`${experiment}/pve-${factor}.json`);
  eq(actual, expected, `PvE ${suffix}: exact complete artifact including 64-bit seeds, initial stats, IDs, outcomes and duration`);
  assert(actual.samplesJson.length === 1000, `PvE ${suffix}: n=1000`);
  const completed = actual.samplesJson.filter(row=>!row.timeout);
  for (const field of ['rounds','turnsBothTeams','turnsPlayersOnly','turnsEnemiesOnly'])
    validateStatistics(actual.summary[field], completed.map(row=>row[field]), `PvE ${suffix}/${field}`);
  assert(actual.summary.wins === completed.filter(row=>row.outcome==='WIN').length, `PvE ${suffix}: win count`);
  comparisons.push({kind:'pve',variant:suffix,previousNumerator:factor,battles:actual.samplesJson.length,
    timeouts:actual.samplesJson.filter(row=>row.timeout).length});
}
function screen(kind) {
  const actualFile = `${integration}/${kind}-fast-raw.jsonl.gz`;
  const expectedFile = `${experiment}/${kind}-7-raw.jsonl.gz`;
  const actual = rawLines(actualFile), expected = rawLines(expectedFile);
  eq(actual, expected, `${kind}: every raw row, all combat metrics, pair side, exact 64-bit seed`);
  const cases = load(`${integration}/${kind}-fast-cases.json.gz`);
  eq(cases, load(`${experiment}/${kind}-7-cases.json.gz`), `${kind}: exact full case/equipment manifests`);
  const actualSummary = load(`${integration}/${kind}-fast-summary.json`);
  const expectedSummary = load(`${experiment}/${kind}-7-summary.json`);
  const strip = value => Object.fromEntries(Object.entries(value).filter(([key])=>key!=='sinkAudit'));
  eq(strip(actualSummary), strip(expectedSummary), `${kind}: all summary metadata/statistics except obsolete experimental counter`);
  const groups = new Map();
  for (const row of actual) {
    const group = groups.get(row.case)||[]; group.push(row.sample); groups.set(row.case,group);
  }
  for (const summary of actualSummary.summaries) {
    const rows = groups.get(summary.case);
    assert(rows.length === (kind === 'confirm' ? 1000 : 200), `${kind}/${summary.case}: sample count`);
    for (const field of ['rounds','actions','attempts','movementTurns','firstDeathRound','healing','reactionDamage','accumulationDischarges'])
      validateStatistics(summary[field], rows.map(row=>row[field]), `${kind}/${summary.case}/${field}`);
    for (const [field,outcome] of [['wins','WIN'],['losses','LOSS'],['draws','DRAW'],['timeouts','TIMEOUT']])
      assert(summary[field]===rows.filter(row=>row.outcome===outcome).length, `${kind}/${summary.case}/${field}`);
  }
  assert(actualSummary.forcedMoveViolations===0 && actual.every(row=>row.sample.forcedMoveViolations===0), `${kind}: no invalid forced moves`);
  comparisons.push({kind,variant:'fast',previousNumerator:7,battles:actual.length,conditions:cases.length,
    timeouts:actual.filter(row=>row.sample.outcome==='TIMEOUT').length,forcedMoveViolations:actualSummary.forcedMoveViolations});
}
pvp('fast',7); pve('fast',7); screen('screen'); screen('confirm');
const baselinesPending = [];
for (const kind of ['pvp','pve']) {
  if (fs.existsSync(`${integration}/${kind}-baseline.json`)) {
    if (kind==='pvp') pvp('baseline',4); else pve('baseline',4);
  } else baselinesPending.push(kind);
}
const sourceDir = `${integration}/source/ru/homyakin/seeker/game/battle/`;
const harnessChanges = [
  ['DurationComparison.java', `${experiment}/source-harness/DurationComparison.java`,
    'new Battle(seed).process(first, second, MAX_ROUNDS)',
    'new Battle(seed).process(first, second, MAX_ROUNDS, Boolean.getBoolean("tempo.integration.baseline") ? BattleTempoVersion.BASELINE_V1 : BattleTempoVersion.ACCELERATED_V1)'],
  ['RaidDurationProbe.java', `${experiment}/source-harness/RaidDurationProbe.java`,
    'new Battle(seed).process(players, enemies, MAX_ROUNDS)',
    'new Battle(seed).process(players, enemies, MAX_ROUNDS, Boolean.getBoolean("tempo.integration.baseline") ? BattleTempoVersion.BASELINE_V1 : BattleTempoVersion.ACCELERATED_V1)'],
  ['Step123BattleRunner.java',publicSource('game/src/test/java/ru/homyakin/seeker/game/battle/Step123BattleRunner.java'),
    'new BattleContext(firstTeam, secondTeam, random)',
    'new BattleContext(firstTeam, secondTeam, random, Boolean.getBoolean("tempo.integration.baseline") ? BattleTempoVersion.BASELINE_V1 : BattleTempoVersion.ACCELERATED_V1)']
];
for (const [file, original, before, after] of harnessChanges)
  eq(read(sourceDir+file), read(original).replace(before,after), `${file}: only explicit production tempo selection differs from tested original`);
for (const file of ['DurationDamageScale.java','DamageTempoBalanceStudy.java'])
  eq(read(sourceDir+file), read(`${experiment}/source/ru/homyakin/seeker/game/battle/${file}`), `${file}: byte-identical metadata/study helper`);
const classFiles = [];
function scan(dir) { for(const entry of fs.readdirSync(dir,{withFileTypes:true})) {
  const file=path.join(dir,entry.name); if(entry.isDirectory())scan(file);else classFiles.push(file);
} }
scan(`${integration}/classes`);
assert(classFiles.every(file=>!/(BattlePersonage|BattleContext|BattleTempoVersion|Battle)\.class$/.test(file)),
  'Integration class directory contains no production combat class overlays');
const origins = load(`${integration}/class-origins.json`);
for (const name of ['Battle','BattleContext','BattlePersonage','BattleTempoVersion']) {
  const origin = origins[`ru.homyakin.seeker.game.battle.${name}`];
  // The origin is the original JVM's recorded location, not the evidence extraction directory.
  assert(origin && typeof origin.origin === 'string' && origin.origin.startsWith('file:') && origin.origin.endsWith('/game/target/classes/'), `${name}: recorded actual runtime origin is production target/classes`);
  assert(origin.sha256 === sha(compiledProduction(`ru/homyakin/seeker/game/battle/${name}.class`)), `${name}: recorded runtime class hash equals preserved compiled production class`);
}
const defaultResources = {};
for (const relative of ['game/src/main/resources/application.properties','game/target/classes/application.properties']) {
  const file = relative.startsWith('game/target/classes/')
    ? compiledProduction(relative.slice('game/target/classes/'.length)) : publicSource(relative);
  const text = read(file);
  assert(/^homyakin\.seeker\.player-combat\.tempo-version=BASELINE_V1$/m.test(text), `${relative}: default tempo remains BASELINE_V1`);
  assert(/^homyakin\.seeker\.player-combat\.version=LEGACY_SKILLS_V1$/m.test(text), `${relative}: default combat remains legacy`);
  assert(/^homyakin\.seeker\.equipment-release\.activate-on-startup=false$/m.test(text), `${relative}: rollout disabled`);
  defaultResources[relative] = {sha256:sha(file),tempo:'BASELINE_V1',combat:'LEGACY_SKILLS_V1',activateOnStartup:false};
}
const report={status:errors.length?'FAIL':'PASS',errors,checks,summaryNumbersChecked,comparisons,
  totalBattles:comparisons.reduce((sum,row)=>sum+row.battles,0),baselinesPending,
  seedPrecision:'JSON numeric seed lexemes preserved as strings using JSON.parse reviver source; no Number conversion',
  excludedMetadata:'PvP sourceHashes necessarily differ for new production files/harness. Screening sinkAudit is obsolete experimental helper counter unused in production. No combat numeric fields or outcomes excluded.',
  productionOverlayAbsent:true,
  provenanceNote:'Frozen public sources and production class snapshots are preferred when present. class-origins.json records the original JVM location; extraction-relative directories are not expected to match it.',
  productionClassOrigins:origins, defaultResources,
  temporaryClassHashes:Object.fromEntries(classFiles.map(file=>[path.relative(integration,file),sha(file)])),
  sources:Object.fromEntries(fs.readdirSync(sourceDir).filter(file=>file.endsWith('.java')).map(file=>[file,sha(sourceDir+file)]))};
fs.writeFileSync(`${integration}/equivalence.json`,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
process.exitCode=errors.length?1:0;
