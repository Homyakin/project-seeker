package ru.homyakin.seeker.game.battle;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import ru.homyakin.seeker.game.battle.skill.active_impl.ActiveEnum;
import ru.homyakin.seeker.game.battle.targeting.TargetingTactic;
import ru.homyakin.seeker.game.item.catalog.EquipmentCatalogLoader;
import ru.homyakin.seeker.game.item.catalog.EquipmentCatalogVersion;
import ru.homyakin.seeker.game.item.catalog.ItemModifiersToml;
import ru.homyakin.seeker.game.item.catalog.ItemObjectsToml;
import ru.homyakin.seeker.game.item.models.Item;
import ru.homyakin.seeker.game.item.models.ItemObject;
import ru.homyakin.seeker.game.item.models.ItemRarity;
import ru.homyakin.seeker.game.item.models.Modifier;
import ru.homyakin.seeker.game.item.modifier.ModifierCompatibility;
import ru.homyakin.seeker.game.personage.models.PersonageSlot;
import ru.homyakin.seeker.utils.RandomUtils;

/** Temporary, standalone diagnostic. No Spring, database, or repository writes. */
public final class DurationComparison {
    private static final Path REPOSITORY = Path.of("/home/user/projects/project-seeker");
    private static final long ROOT_SEED = 2026110201L;
    private static final int MAX_ROUNDS = 10000;
    private static final List<Integer> LEVELS = List.of(0, 3, 6);
    private static final List<String> REGIMES = List.of("COMMON_NO_MODS", "RARE_FULL");
    private static final List<Build> BUILDS = List.of(
        new Build("F", Position.FRONT, List.of("sword", "shield", "cuirass", "greaves", "sabatons", "great_helm", "gauntlets"),
            Map.of("sword", "double", "shield", "furious")),
        new Build("D", Position.FRONT, List.of("rapier", "dagger", "breastplate", "leather_chausses", "boots", "leather_helm", "leather_gloves"),
            Map.of("rapier", "double", "dagger", "precise")),
        new Build("A", Position.BACK, List.of("longbow", "robe", "cloth_chausses", "cloth_boots", "hood", "cloth_gloves"),
            Map.of("longbow", "double")),
        new Build("M", Position.MID, List.of("staff", "orb", "wizard_robe", "arcane_chausses", "arcane_boots", "circlet", "arcane_gloves"),
            Map.of("staff", "precise", "orb", "furious"))
    );
    private static final List<Scenario> SCENARIOS = List.of(
        new Scenario("N1_F", List.of("F")), new Scenario("N1_D", List.of("D")),
        new Scenario("N1_A", List.of("A")), new Scenario("N1_M", List.of("M")),
        new Scenario("N3_FDA", List.of("F", "D", "A")),
        new Scenario("N3_FDM", List.of("F", "D", "M")),
        new Scenario("N7_FFDDAAM", List.of("F", "F", "D", "D", "A", "A", "M")),
        new Scenario("N15_4F4D4A3M", List.of("F", "F", "F", "F", "D", "D", "D", "D", "A", "A", "A", "A", "M", "M", "M"))
    );

    private DurationComparison() { }

    public static void main(String[] args) throws Exception {
        if (args.length != 3 || (!args[0].equals("OLD") && !args[0].equals("NEW"))) {
            throw new IllegalArgumentException("Usage: DurationComparison OLD|NEW samples outputJson");
        }
        final String mode = args[0];
        final int samples = Integer.parseInt(args[1]);
        if (samples <= 0) throw new IllegalArgumentException("samples must be positive");
        final var oldCatalog = oldCatalog();
        final var newCatalog = newCatalog();
        validate(oldCatalog);
        validate(newCatalog);
        final var catalog = mode.equals("OLD") ? oldCatalog : newCatalog;
        final var summaries = new ArrayList<Map<String, Object>>();
        final var raw = new ArrayList<Map<String, Object>>();
        int conditionIndex = 0;
        for (final var scenario : SCENARIOS) {
            for (final int level : LEVELS) {
                for (final var regime : REGIMES) {
                    final int group = conditionIndex++;
                    final String condition = scenario.code + "/+" + level + "/" + regime;
                    final var rows = new ArrayList<Map<String, Object>>();
                    for (int sample = 0; sample < samples; sample++) {
                        final long seed = iterationSeed(ROOT_SEED + group, sample);
                        final var row = RandomUtils.withSeed(seed, () -> battle(mode, catalog, scenario, level, regime, seed));
                        row.put("condition", condition);
                        row.put("conditionIndex", group);
                        row.put("sampleIndex", sample);
                        rows.add(row);
                        raw.add(row);
                    }
                    final long timeouts = rows.stream().filter(row -> (boolean) row.get("timeout")).count();
                    summaries.add(map("condition", condition, "conditionIndex", group,
                        "scenario", scenario.code, "composition", scenario.members, "partySize", scenario.members.size(),
                        "level", level, "regime", regime, "samples", samples, "timeouts", timeouts,
                        "timeoutRate", (double) timeouts / samples,
                        "rounds", statistics(rows, "rounds"), "turnsBothTeams", statistics(rows, "turnsBothTeams"),
                        "turnsFirstTeam", statistics(rows, "turnsFirstTeam"), "turnsSecondTeam", statistics(rows, "turnsSecondTeam")));
                    System.err.println(mode + " " + condition + " samples=" + samples + " timeouts=" + timeouts);
                }
            }
        }
        if (conditionIndex != 48) throw new IllegalStateException("Expected 48 conditions");
        final var manifest = new ArrayList<Map<String, Object>>();
        for (final var build : BUILDS) for (final int level : LEVELS) for (final var regime : REGIMES) {
            manifest.add(buildManifest(mode, catalog, build, level, regime));
        }
        final var output = map("schemaVersion", 1, "mode", mode, "rootSeed", ROOT_SEED,
            "sampleSeedFormula", "SplitMix64(rootSeed + conditionIndex + GOLDEN_GAMMA * (sampleIndex + 1))",
            "samplesPerCondition", samples, "conditions", conditionIndex, "totalBattles", raw.size(),
            "maxRounds", MAX_ROUNDS, "comparison", "Separate within-version mirrors using identical item codes, modifiers, positions, levels and seeds",
            "catalog", mode.equals("OLD") ? "ORIGINAL_40_ITEMS_11_MODIFIERS" : "SCALING_V5",
            "skillFormula", mode.equals("OLD") ? "LEGACY_SKILLS_V1" : "SCALING_SKILLS_V2",
            "targetingTactic", "THREAT", "externalEffects", "NONE",
            "turnDefinition", "Sum of BattlePersonageStats.turnsCount for both teams; includes invoked queued moves, even if the mover is defeated before acting",
            "timeoutHandling", "Right censored at maxRounds; all rows retained in all summaries. Turns are observed at censoring. No censored observation is silently excluded.",
            "quantiles", "Median averages the central pair; p95 is nearest-rank ceil(0.95*n). Timeouts contribute censored observed values.",
            "oldLegacyEnhancePercentPerLevel", 5, "sourceHashes", sourceHashes(mode),
            "oldBattleContextSourceOverride", mode.equals("OLD") ? System.getProperty("duration.oldBattleContextSource", "UNSPECIFIED_CURRENT_REPOSITORY_SOURCE_HASHED") : "NOT_APPLICABLE",
            "manifest", manifest, "summaries", summaries, "raw", raw);
        final Path outputPath = Path.of(args[2]).toAbsolutePath();
        if (outputPath.getParent() != null) Files.createDirectories(outputPath.getParent());
        new ObjectMapper().writerWithDefaultPrettyPrinter().writeValue(outputPath.toFile(), output);
        System.err.println("Wrote " + outputPath);
    }

    private static Map<String, Object> battle(String mode, Catalog catalog, Scenario scenario, int level, String regime, long seed) {
        final var first = team(mode, catalog, scenario, level, regime);
        final var second = team(mode, catalog, scenario, level, regime);
        int rounds;
        boolean timeout = false;
        Boolean firstWin = null;
        try {
            final var result = new Battle(seed).process(first, second, MAX_ROUNDS, Boolean.getBoolean("tempo.integration.baseline") ? BattleTempoVersion.BASELINE_V1 : BattleTempoVersion.ACCELERATED_V1);
            rounds = result.rounds();
            firstWin = result.firstWin();
        } catch (IllegalStateException exception) {
            if (!exception.getMessage().equals("Battle did not finish within " + MAX_ROUNDS + " rounds")) throw exception;
            rounds = MAX_ROUNDS;
            timeout = true;
        }
        final long firstTurns = first.stream().mapToLong(personage -> personage.battlePersonageStats().turnsCount()).sum();
        final long secondTurns = second.stream().mapToLong(personage -> personage.battlePersonageStats().turnsCount()).sum();
        return map("seed", seed, "rounds", rounds, "turnsBothTeams", firstTurns + secondTurns,
            "turnsFirstTeam", firstTurns, "turnsSecondTeam", secondTurns, "timeout", timeout,
            "firstWin", firstWin, "survivorsFirstTeam", first.stream().filter(BattlePersonage::isAlive).count(),
            "survivorsSecondTeam", second.stream().filter(BattlePersonage::isAlive).count());
    }

    private static List<BattlePersonage> team(String mode, Catalog catalog, Scenario scenario, int level, String regime) {
        final var result = new ArrayList<BattlePersonage>();
        for (final String code : scenario.members) {
            final var build = BUILDS.stream().filter(candidate -> candidate.code.equals(code)).findFirst().orElseThrow();
            final var items = items(catalog, build, level, regime);
            final var personage = mode.equals("OLD")
                ? new BattlePersonage(items, build.position, Optional.of(build.code))
                : BattlePersonage.forScalingSkillsV2Combat(items, build.position, Map.of(), Optional.of(build.code));
            personage.setTargetingTactic(TargetingTactic.THREAT);
            if (personage.usesScalingCombatRules() != mode.equals("NEW")) throw new IllegalStateException("Wrong combat mode");
            result.add(personage);
        }
        return List.copyOf(result);
    }

    private static List<Item> items(Catalog catalog, Build build, int level, String regime) {
        final boolean modified = regime.equals("RARE_FULL");
        return build.itemCodes.stream().map(code -> {
            final var object = Optional.ofNullable(catalog.objects.get(code)).orElseThrow();
            final var modifierCode = modifierCode(build, object);
            return new Item(object, modified ? Optional.of(catalog.modifiers.get(modifierCode)) : Optional.empty(),
                modified ? ItemRarity.RARE : ItemRarity.COMMON, level);
        }).toList();
    }

    private static String modifierCode(Build build, ItemObject object) {
        if (build.handModifiers.containsKey(object.code())) return build.handModifiers.get(object.code());
        if (object.slots().size() != 1) throw new IllegalArgumentException("Unexpected multi-slot armor");
        return switch (object.slots().iterator().next()) {
            case BODY, PANTS -> "healing";
            case SHOES -> "swift";
            case HELMET -> "counter";
            case GLOVES -> "thorny";
            default -> throw new IllegalArgumentException("Unassigned hand modifier");
        };
    }

    private static void validate(Catalog catalog) {
        for (final var build : BUILDS) {
            final var occupied = EnumSet.noneOf(PersonageSlot.class);
            for (final var item : items(catalog, build, 0, "RARE_FULL")) {
                final var modifier = item.modifier().orElseThrow();
                for (final var slot : item.object().slots()) {
                    if (!occupied.add(slot)) throw new IllegalArgumentException("Overlapping slot " + slot);
                    if (!ModifierCompatibility.isCompatible(item.object(), modifier, slot)) {
                        throw new IllegalArgumentException("Incompatible " + item.object().code() + "/" + modifier.code() + "/" + slot);
                    }
                }
                if (item.skillPoints() != 2 * item.object().slots().size()) throw new IllegalStateException("Unexpected skill points");
            }
            if (!occupied.equals(EnumSet.allOf(PersonageSlot.class))) throw new IllegalArgumentException("Incomplete build " + build.code);
        }
    }

    private static Map<String, Object> buildManifest(String mode, Catalog catalog, Build build, int level, String regime) {
        final var entries = new ArrayList<Map<String, Object>>();
        for (final var item : items(catalog, build, level, regime)) {
            final var object = item.object();
            final var attacks = item.itemAttacks().stream().map(attack -> map("type", attack.attackType().name(),
                "minRange", attack.minRange(), "maxRange", attack.maxRange(), "attack", attack.attack())).toList();
            final var modifier = item.modifier().map(value -> map("code", value.code(), "activeEnum", value.activeEnum().name(),
                "type", value.type().name(), "availableOnSlots", value.availableOnSlots().stream().map(Enum::name).sorted().toList())).orElse(null);
            entries.add(map("code", object.code(), "slots", object.slots().stream().map(Enum::name).sorted().toList(),
                "rarity", item.rarity().name(), "enhanceLevel", item.enhanceLevel(), "progression", object.progressionVersion().name(),
                "health", item.health(), "attacks", attacks, "defense", item.itemDefense().map(value -> map("type", value.defenseType().name(), "defense", value.defense())).orElse(null),
                "critChance", item.critChance(), "dodgeChance", item.dodgeChance(), "critMultiplier", item.critMultiplier(),
                "speed", item.speed(), "baseThreat", item.baseThreat(), "impact", item.impact(), "modifier", modifier,
                "skillPoints", item.modifier().isPresent() ? item.skillPoints() : 0));
        }
        return map("mode", mode, "build", build.code, "position", build.position.name(), "tactic", "THREAT",
            "level", level, "regime", regime, "items", entries);
    }

    private static Catalog oldCatalog() throws Exception {
        try (InputStream objects = resource("game-data/item_objects_catalog.toml");
             InputStream modifiers = resource("game-data/item_modifiers_catalog.toml")) {
            final var catalog = catalog(ItemObjectsToml.load(objects).itemObjects(), ItemModifiersToml.load(modifiers).modifiers());
            if (catalog.objects.size() != 40 || catalog.modifiers.size() != 11) throw new IllegalStateException("Unexpected original catalog size");
            return catalog;
        }
    }

    private static Catalog newCatalog() {
        final var loaded = EquipmentCatalogLoader.loadValidated(EquipmentCatalogVersion.SCALING_V5);
        return catalog(loaded.itemObjects(), loaded.modifiers());
    }

    private static Catalog catalog(List<ItemObject> objects, List<Modifier> modifiers) {
        return new Catalog(objects.stream().collect(Collectors.toMap(ItemObject::code, value -> value)),
            modifiers.stream().collect(Collectors.toMap(Modifier::code, value -> value)));
    }

    private static InputStream resource(String path) {
        final var stream = DurationComparison.class.getClassLoader().getResourceAsStream(path);
        if (stream == null) throw new IllegalArgumentException("Missing resource " + path);
        return stream;
    }

    private static long iterationSeed(long seed, int iteration) {
        long value = seed + 0x9e3779b97f4a7c15L * (iteration + 1L);
        value = (value ^ (value >>> 30)) * 0xbf58476d1ce4e5b9L;
        value = (value ^ (value >>> 27)) * 0x94d049bb133111ebL;
        return value ^ (value >>> 31);
    }

    private static Map<String, Object> statistics(List<Map<String, Object>> rows, String field) {
        final var values = rows.stream().map(row -> ((Number) row.get(field)).longValue()).sorted().toList();
        final int count = values.size();
        final double median = count % 2 == 1 ? values.get(count / 2)
            : (values.get(count / 2 - 1) + values.get(count / 2)) / 2.0;
        return map("median", median, "p95", values.get((int) Math.ceil(0.95 * count) - 1),
            "mean", values.stream().mapToLong(Long::longValue).average().orElseThrow(), "min", values.getFirst(), "max", values.getLast());
    }

    /** Hash relevant combat, progression, catalog-loader inputs; no application profiles or secrets. */
    private static Map<String, Object> sourceHashes(String mode) throws Exception {
        final var result = new LinkedHashMap<String, Object>();
        final String java = "game/src/main/java/ru/homyakin/seeker/";
        final var paths = new ArrayList<String>(List.of(
            java + "game/battle/Battle.java", java + "game/battle/BattleContext.java",
            java + "game/battle/BattlePersonage.java", java + "game/battle/CombatRules.java",
            java + "game/battle/BattleLine.java", java + "game/battle/Position.java",
            java + "game/battle/targeting/TargetingMath.java", java + "utils/RandomUtils.java", java + "utils/MathUtils.java",
            java + "game/item/models/Item.java", java + "game/item/models/ItemObject.java",
            java + "game/item/models/ItemAttack.java", java + "game/item/models/ItemRarity.java",
            java + "game/item/catalog/ItemObjectsToml.java", java + "game/item/catalog/ItemModifiersToml.java",
            java + "game/item/modifier/ModifierCompatibility.java",
            java + "game/item/storm/StormEnhanceConfig.java",
            java + "game/battle/skill/active_impl/DoubleAttack.java", java + "game/battle/skill/active_impl/Berserk.java",
            java + "game/battle/skill/active_impl/PreciseStrike.java", java + "game/battle/skill/active_impl/SelfHeal.java",
            java + "game/battle/skill/active_impl/HitAndRun.java", java + "game/battle/skill/active_impl/CounterAttack.java",
            java + "game/battle/skill/active_impl/Thorns.java",
            "game/src/main/resources/game-data/item_objects_catalog.toml",
            "game/src/main/resources/game-data/item_modifiers_catalog.toml",
            "game/src/main/resources/game-data/catalog/scaling_v5/item_objects.toml",
            "game/src/main/resources/game-data/catalog/scaling_v5/item_modifiers.toml",
            "game/src/main/resources/game-data/catalog/scaling_v5/default_items.toml",
            java + "game/item/catalog/EquipmentCatalogLoader.java", java + "game/item/catalog/EquipmentCatalogValidator.java",
            java + "game/item/catalog/EquipmentCatalogRelease.java"
        ));
        if (mode.equals("NEW")) {
            paths.add(java + "game/battle/VersionedBattleTurn.java");
            paths.add(java + "game/battle/SeededBattleRandom.java");
            paths.add(java + "game/battle/VersionedTeamSkillState.java");
            paths.add(java + "game/item/storm/ItemProgression.java");
            try (var files = Files.list(REPOSITORY.resolve(java + "game/battle/skill/scaling"))) {
                files.filter(path -> path.toString().endsWith(".java")).sorted().forEach(path -> paths.add(REPOSITORY.relativize(path).toString()));
            }
        }
        for (final String relative : paths) {
            Path path = REPOSITORY.resolve(relative);
            if (mode.equals("OLD") && relative.endsWith("/BattleContext.java") && System.getProperty("duration.oldBattleContextSource") != null) {
                path = Path.of(System.getProperty("duration.oldBattleContextSource"));
            }
            result.put(relative, map("readFrom", path.toString(), "sha256", sha256(path)));
        }
        final Path harness = Path.of(System.getProperty("duration.harnessSource", "/tmp/seeker-duration-comparison.XNZy7z/DurationComparison.java"));
        result.put("temporaryHarness", map("readFrom", harness.toString(), "sha256", sha256(harness)));
        result.put("scope", "Selected relevant Java sources plus both catalogs used by validation; these are source-file hashes, not a complete runtime class-loading trace");
        return result;
    }

    private static String sha256(Path path) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(path)));
    }

    private static Map<String, Object> map(Object... values) {
        final var result = new LinkedHashMap<String, Object>();
        for (int index = 0; index < values.length; index += 2) result.put((String) values[index], values[index + 1]);
        return result;
    }

    private record Catalog(Map<String, ItemObject> objects, Map<String, Modifier> modifiers) { }
    private record Build(String code, Position position, List<String> itemCodes, Map<String, String> handModifiers) { }
    private record Scenario(String code, List<String> members) { }
}
