package ru.homyakin.seeker.game.battle;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;

/** Records the actual production class origins; never substitutes a combat implementation. */
public final class TempoIntegrationOrigin {
    private TempoIntegrationOrigin() { }

    public static void main(String[] args) throws Exception {
        final var records = new LinkedHashMap<String, Object>();
        for (final var type : List.of(Battle.class, BattleContext.class, BattlePersonage.class, BattleTempoVersion.class)) {
            final String origin = type.getProtectionDomain().getCodeSource().getLocation().toString();
            if (!origin.endsWith("/game/target/classes/")) throw new AssertionError("Not production classes: " + origin);
            try (final var in = type.getResourceAsStream(type.getSimpleName() + ".class")) {
                records.put(type.getName(), java.util.Map.of("origin", origin,
                    "sha256", HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(in.readAllBytes()))));
            }
        }
        new ObjectMapper().writerWithDefaultPrettyPrinter().writeValue(Path.of(args[0]).toFile(), records);
    }
}
