package ru.homyakin.seeker.game.battle;

import java.util.Map;

/** Temporary experimental sink scaling. Never included in the application artifact. */
final class DurationDamageScale {
    static final int NUMERATOR = Integer.getInteger("tempo.numerator", 4);
    private static long legacyApplications;
    private static long versionedApplications;
    private static long damageBefore;
    private static long damageAfter;

    static {
        if (NUMERATOR < 4 || NUMERATOR > 7) {
            throw new IllegalArgumentException("Only 4/4, 5/4, 6/4 and 7/4 are study variants");
        }
    }

    private DurationDamageScale() { }

    static int apply(int damage, boolean versioned) {
        if (damage < 0) throw new IllegalArgumentException("Negative damage");
        final int scaled = Math.toIntExact((Math.multiplyExact((long) damage, NUMERATOR) + 2L) / 4L);
        if (versioned) versionedApplications++; else legacyApplications++;
        damageBefore = Math.addExact(damageBefore, damage);
        damageAfter = Math.addExact(damageAfter, scaled);
        return scaled;
    }

    static double factor() { return NUMERATOR / 4.0; }

    static Map<String, Object> audit() {
        return Map.of("numerator", NUMERATOR, "denominator", 4,
            "legacySinkApplications", legacyApplications, "versionedSinkApplications", versionedApplications,
            "damageBeforeScaling", damageBefore, "damageAfterScalingBeforeOverkill", damageAfter,
            "scope", "Counters are sequential per JVM; damage sums precede HP/overkill clamp, not actual damage totals");
    }
}
