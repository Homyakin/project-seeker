package ru.homyakin.seeker.game.battle;

import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import ru.homyakin.seeker.game.battle.simulation.RaidSimulationFixtures;
import ru.homyakin.seeker.game.battle.simulation.RaidSimulationFixtures.ReferenceBuild;
import ru.homyakin.seeker.game.event.launched.RaidParams;
import ru.homyakin.seeker.game.event.models.EventStatus;
import ru.homyakin.seeker.game.event.raid.generator.RaidGenerator;
import ru.homyakin.seeker.game.event.raid.models.LaunchedRaidEvent;
import ru.homyakin.seeker.game.event.raid.models.RaidType;
import ru.homyakin.seeker.game.item.catalog.EquipmentCatalogLoader;
import ru.homyakin.seeker.game.item.catalog.EquipmentCatalogVersion;
import ru.homyakin.seeker.game.item.catalog.ItemObjectsToml;
import ru.homyakin.seeker.game.item.models.Item;
import ru.homyakin.seeker.game.item.models.ItemObject;
import ru.homyakin.seeker.utils.RandomUtils;
import ru.homyakin.seeker.utils.ResourceUtils;

/** Temporary diagnostic only; does not start Spring, use a database or accept future PvE balance. */
public final class RaidDurationProbe {
    private static final int ITERATIONS = 1000;
    private static final int MAX_ROUNDS = 10000;
    private static final long ROOT_SEED = 20260901L;
    private static final List<ReferenceBuild> COMPOSITION = List.of(
        ReferenceBuild.LEATHER_PIERCE, ReferenceBuild.ARCANE_MAGE, ReferenceBuild.PLATE_TANK
    );
    private static final Map<String, ItemObject> LEGACY = ResourceUtils.calc(
        "game-data/item_objects_catalog.toml", ItemObjectsToml::load
    ).orElseThrow().itemObjects().stream().collect(Collectors.toMap(ItemObject::code, Function.identity()));
    private static final Map<String, ItemObject> V5 = EquipmentCatalogLoader
        .loadValidated(EquipmentCatalogVersion.SCALING_V5).itemObjects().stream()
        .collect(Collectors.toMap(ItemObject::code, Function.identity()));

    private RaidDurationProbe() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2 || !(args[0].equals("OLD") || args[0].equals("NEW"))) {
            throw new IllegalArgumentException("Usage: RaidDurationProbe OLD|NEW outputJson");
        }
        final String mode = args[0];
        final var samples = new ArrayList<Sample>(ITERATIONS);
        for (int iteration = 0; iteration < ITERATIONS; iteration++) {
            final int index = iteration;
            final long seed = iterationSeed(ROOT_SEED, iteration);
            samples.add(RandomUtils.withSeed(seed, () -> observe(mode, index, seed)));
        }
        final var complete = samples.stream().filter(sample -> !sample.timeout()).toList();
        final long wins = complete.stream().filter(sample -> sample.outcome().equals("WIN")).count();
        final long draws = complete.stream().filter(sample -> sample.outcome().equals("DRAW")).count();
        final var summary = new LinkedHashMap<String, Object>();
        summary.put("attempted", samples.size());
        summary.put("completed", complete.size());
        summary.put("timeouts", samples.size() - complete.size());
        summary.put("draws", draws);
        summary.put("wins", wins);
        summary.put("winRateAmongCompleted", complete.isEmpty() ? null : (double) wins / complete.size());
        summary.put("rounds", stats(complete.stream().map(sample -> (long) sample.rounds()).toList()));
        summary.put("turnsBothTeams", stats(complete.stream().map(Sample::turnsBothTeams).toList()));
        summary.put("turnsPlayersOnly", stats(complete.stream().map(Sample::turnsPlayersOnly).toList()));
        summary.put("turnsEnemiesOnly", stats(complete.stream().map(Sample::turnsEnemiesOnly).toList()));
        final var output = new LinkedHashMap<String, Object>();
        output.put("purpose", "Diagnostic of the existing, not-yet-adapted PvE generator; not final raid acceptance");
        output.put("mode", mode);
        output.put("rules", mode.equals("OLD") ? "LEGACY_SKILLS_V1; run with historical BattleContext overlay"
            : "SCALING_V5 equipment / SCALING_SKILLS_V2 player combat rules");
        output.put("generator", "Current RaidGenerator, MYCONID_COLONY level 10; NPCs retain generator-created rules");
        output.put("comparisonScope", "Same historical item codes and positions; each generator uses its team's legacyPower, "
            + "so enemy stats and random streams need not be identical across modes");
        output.put("durationUnit", "Rounds are global initiative ticks, not seconds or one action per participant");
        output.put("turnUnit", "Sum of BattlePersonageStats.turnsCount; own turns can include movement or skill-only turns");
        output.put("statisticsScope", "All completed battles; timeouts are listed but excluded from duration/turn summaries");
        output.put("seedMethod", "Exact copy of CombatSimulator.iterationSeed (package-private), SplitMix64");
        output.put("rootSeed", ROOT_SEED);
        output.put("iterations", ITERATIONS);
        output.put("maxRounds", MAX_ROUNDS);
        output.put("composition", COMPOSITION);
        output.put("partySize", COMPOSITION.size());
        output.put("difficulty", 10);
        output.put("effects", "PersonageEffects.EMPTY");
        output.put("gearManifest", COMPOSITION.stream().map(build -> Map.of(
            "build", build.name(), "position", build.position(), "items", items(mode, build)
        )).toList());
        output.put("summary", summary);
        output.put("samplesJson", samples);
        final var mapper = JsonMapper.builder().addModule(new Jdk8Module()).build();
        try (final var stream = Files.newOutputStream(Path.of(args[1]), StandardOpenOption.CREATE_NEW)) {
            mapper.writerWithDefaultPrettyPrinter().writeValue(stream, output);
        }
        System.out.println(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(summary));
    }

    private static Sample observe(String mode, int iteration, long seed) {
        final var players = mode.equals("OLD") ? RaidSimulationFixtures.team(COMPOSITION)
            : COMPOSITION.stream().map(build -> BattlePersonage.forScalingSkillsV2Combat(
                items(mode, build), build.position(), Map.of(), Optional.of(build.name())
            )).toList();
        final var start = LocalDateTime.of(2026, 1, 1, 0, 0);
        final var event = new LaunchedRaidEvent(
            1L, 1, start, start.plusHours(1), EventStatus.LAUNCHED, new RaidParams(10, 0)
        );
        final var enemies = new RaidGenerator().generate(RaidType.MYCONID_COLONY, event, players);
        final var playerManifests = players.stream().map(RaidDurationProbe::manifest).toList();
        final var enemyManifests = enemies.stream().map(RaidDurationProbe::manifest).toList();
        int rounds = MAX_ROUNDS;
        boolean timeout = false;
        String outcome;
        List<BattlePersonageInitSnapshot> initialState = List.of();
        try {
            final var result = new Battle(seed).process(players, enemies, MAX_ROUNDS, Boolean.getBoolean("tempo.integration.baseline") ? BattleTempoVersion.BASELINE_V1 : BattleTempoVersion.ACCELERATED_V1);
            rounds = result.rounds();
            final boolean playerAlive = players.stream().anyMatch(BattlePersonage::isAlive);
            final boolean enemyAlive = enemies.stream().anyMatch(BattlePersonage::isAlive);
            outcome = result.firstWin() ? "WIN" : enemyAlive ? "LOSS" : playerAlive ? "WIN" : "DRAW";
            initialState = result.initState().personagesById().values().stream()
                .sorted(Comparator.comparing(snapshot -> snapshot.id().toString())).toList();
        } catch (IllegalStateException exception) {
            if (!exception.getMessage().equals("Battle did not finish within " + MAX_ROUNDS + " rounds")) {
                throw exception;
            }
            timeout = true;
            outcome = "TIMEOUT";
        }
        final long playerTurns = turns(players);
        final long enemyTurns = turns(enemies);
        return new Sample(iteration, seed, rounds, playerTurns + enemyTurns, playerTurns, enemyTurns,
            outcome, timeout, playerManifests, enemyManifests, initialState);
    }

    private static List<Item> items(String mode, ReferenceBuild build) {
        final var catalog = mode.equals("OLD") ? LEGACY : V5;
        return build.itemCodes().stream().map(code -> Item.fromObject(Optional.ofNullable(catalog.get(code))
            .orElseThrow(() -> new IllegalStateException("Missing " + mode + " item " + code)))).toList();
    }

    private static Map<String, Object> manifest(BattlePersonage personage) {
        final var result = new LinkedHashMap<String, Object>();
        result.put("id", personage.id());
        result.put("name", personage.name());
        result.put("maxHealth", personage.maxHealth());
        result.put("speed", personage.initiative());
        result.put("critChance", personage.critChance());
        result.put("dodgeChance", personage.dodgeChance());
        result.put("critMultiplier", personage.critMultiplier());
        result.put("defenses", personage.defenses());
        result.put("attacksByRange", personage.attacksByRange());
        result.put("items", personage.itemSnapshots());
        result.put("skills", personage.skillSnapshots());
        result.put("startPosition", personage.startPosition());
        result.put("legacyPower", personage.legacyPower());
        result.put("usesScalingCombatRules", personage.usesScalingCombatRules());
        return result;
    }

    private static long turns(List<BattlePersonage> team) {
        return team.stream().mapToLong(personage -> personage.battlePersonageStats().turnsCount()).sum();
    }

    private static Statistics stats(List<Long> values) {
        if (values.isEmpty()) {
            return new Statistics(0, null, null, null, null, null);
        }
        final var sorted = values.stream().sorted().toList();
        final int count = sorted.size();
        final int middle = count / 2;
        final double median = count % 2 == 1 ? sorted.get(middle)
            : (sorted.get(middle - 1) + sorted.get(middle)) / 2.0;
        return new Statistics(count, values.stream().mapToLong(Long::longValue).average().orElseThrow(),
            median, sorted.get((int) Math.ceil(0.95 * count) - 1), sorted.getFirst(), sorted.getLast());
    }

    // Copied exactly from CombatSimulator.iterationSeed; inaccessible from this package.
    private static long iterationSeed(long seed, int iteration) {
        var mixed = seed + 0x9e3779b97f4a7c15L * (iteration + 1L);
        mixed = (mixed ^ mixed >>> 30) * 0xbf58476d1ce4e5b9L;
        mixed = (mixed ^ mixed >>> 27) * 0x94d049bb133111ebL;
        return mixed ^ mixed >>> 31;
    }

    public record Statistics(int count, Double mean, Double median, Long p95, Long min, Long max) {
    }

    public record Sample(int iteration, long seed, int rounds, long turnsBothTeams, long turnsPlayersOnly,
                         long turnsEnemiesOnly, String outcome, boolean timeout,
                         List<Map<String, Object>> playersBeforeBattle, List<Map<String, Object>> enemiesBeforeBattle,
                         List<BattlePersonageInitSnapshot> initialState) {
    }
}
