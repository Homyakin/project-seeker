package ru.homyakin.seeker.game.battle;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.ToLongFunction;
import java.util.regex.Pattern;
import java.util.zip.GZIPOutputStream;
import ru.homyakin.seeker.game.battle.Step123BattleRunner.Gear;
import ru.homyakin.seeker.game.battle.Step123ReferenceTeams.Specialization;
import ru.homyakin.seeker.game.battle.Step123ReferenceTeams.Tier;
import ru.homyakin.seeker.game.battle.Step12RepresentativeBuilds.Assignment;
import ru.homyakin.seeker.game.battle.Step12RepresentativeBuilds.Build;
import ru.homyakin.seeker.game.battle.simulation.Step12SimulationFixtures.MixedBuild;
import ru.homyakin.seeker.game.battle.simulation.Step12SimulationFixtures.RoleBuild;
import ru.homyakin.seeker.game.battle.simulation.Step12SimulationFixtures.V3Build;
import ru.homyakin.seeker.game.battle.skill.active_impl.ActiveEnum;
import ru.homyakin.seeker.game.battle.targeting.TargetingTactic;
import ru.homyakin.seeker.game.item.catalog.EquipmentCatalogVersion;
import ru.homyakin.seeker.game.item.models.Item;
import ru.homyakin.seeker.game.item.models.ItemRarity;

/** Standalone diagnostic only: compiled into a temporary class overlay, not the game. */
public final class DamageTempoBalanceStudy {
    private static final ObjectMapper JSON = new ObjectMapper();
    private static final int MAX_ROUNDS = 10000;
    private static final List<Tier> TIERS = List.of(Tier.BEGINNER, Tier.MID, Tier.STRONG);

    private DamageTempoBalanceStudy() { }

    public static void main(String[] args) throws Exception {
        if (args.length != 1) throw new IllegalArgumentException("Specify unused output prefix");
        final Path prefix = Path.of(args[0]).toAbsolutePath();
        final int pairs = Integer.getInteger("tempo.pairs", 100);
        final long root = Long.getLong("tempo.seed", 2026110202L);
        final var filter = Pattern.compile(System.getProperty("tempo.filter", ".*"));
        final var selected = cases().stream().filter(c -> filter.matcher(c.code()).find()).toList();
        if (pairs < 2 || selected.isEmpty()) throw new IllegalArgumentException("Invalid run");
        final var summaries = new ArrayList<Map<String, Object>>();
        final var definitions = new ArrayList<Map<String, Object>>();
        long battles = 0;
        long violations = 0;
        long timeouts = 0;
        try (final var raw = new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(
            Files.newOutputStream(Path.of(prefix + "-raw.jsonl.gz"), StandardOpenOption.CREATE_NEW)), StandardCharsets.UTF_8))) {
            for (final var c : selected) {
                final var observations = new ArrayList<Sample>();
                for (int pair = 0; pair < pairs; pair++) {
                    final long seed = iterationSeed(root + c.seedGroup().hashCode(), pair);
                    for (final boolean reverse : List.of(false, true)) {
                        final var o = Step123BattleRunner.observe(c.left(), c.right(), c.level(), seed,
                            reverse, MAX_ROUNDS, c.disabledLeft(), Set.of());
                        final var audit = Step123CorrectionsStudy.audit(o.initialPositions(), o.events(), reverse);
                        final long firstDeath = o.events().stream().filter(e -> e instanceof BattleEvent.PersonageDefeated)
                            .mapToLong(BattleEvent::round).min().orElse(-1);
                        final long reaction = o.events().stream().mapToLong(e -> reactionDamage(e)).sum();
                        final long discharges = o.events().stream().filter(e -> e instanceof BattleEvent.SkillChargeChanged charge
                            && charge.discharged()).count();
                        final var s = new Sample(pair, reverse, seed, o.outcome(), o.rounds(),
                            o.left().actions() + o.right().actions(), o.left().attempts() + o.right().attempts(),
                            o.left().movementTurns() + o.right().movementTurns(), firstDeath,
                            o.left().healing() + o.right().healing(), reaction, discharges,
                            audit.forcedMoves(), audit.violations(), audit.maxDistance(), o.left(), o.right());
                        raw.write(JSON.writeValueAsString(map("case", c.code(), "numerator", DurationDamageScale.NUMERATOR,
                            "sample", s)));
                        raw.newLine();
                        observations.add(s);
                        battles++;
                        violations += audit.violations();
                        timeouts += o.outcome().equals("TIMEOUT") ? 1 : 0;
                    }
                }
                final var summary = map("case", c.code(), "family", c.family(), "tier", c.tier(),
                    "level", c.level(), "size", c.left().size(), "pairs", pairs, "battles", observations.size(),
                    "wins", observations.stream().filter(s -> s.outcome().equals("WIN")).count(),
                    "losses", observations.stream().filter(s -> s.outcome().equals("LOSS")).count(),
                    "draws", observations.stream().filter(s -> s.outcome().equals("DRAW")).count(),
                    "timeouts", observations.stream().filter(s -> s.outcome().equals("TIMEOUT")).count(),
                    "rounds", stats(observations, Sample::rounds), "actions", stats(observations, Sample::actions),
                    "attempts", stats(observations, Sample::attempts), "movementTurns", stats(observations, Sample::movementTurns),
                    "firstDeathRound", stats(observations, Sample::firstDeathRound), "healing", stats(observations, Sample::healing),
                    "reactionDamage", stats(observations, Sample::reactionDamage),
                    "accumulationDischarges", stats(observations, Sample::accumulationDischarges));
                summaries.add(summary);
                definitions.add(map("case", c, "leftEquipment", manifest(c.left(), c.level()),
                    "rightEquipment", manifest(c.right(), c.level())));
                System.err.println("factor=" + DurationDamageScale.factor() + " " + c.code() + " " + summaries.size() + "/" + selected.size());
            }
        }
        try (final var out = new GZIPOutputStream(Files.newOutputStream(Path.of(prefix + "-cases.json.gz"), StandardOpenOption.CREATE_NEW))) {
            JSON.writeValue(out, definitions);
        }
        final var output = map("purpose", "Diagnostic damage tempo screen; no live settings changed and no universal 50/50 target",
            "catalog", "SCALING_V5", "combat", "SCALING_SKILLS_V2", "numerator", DurationDamageScale.NUMERATOR,
            "denominator", 4, "factor", DurationDamageScale.factor(), "rootSeed", root, "pairsPerCondition", pairs,
            "filter", filter.pattern(), "conditions", selected.size(), "battles", battles, "timeouts", timeouts,
            "forcedMoveViolations", violations, "maxRounds", MAX_ROUNDS,
            "seeds", "SplitMix64(rootSeed + JavaStringHash(seedGroup), pairIndex); identical across factors, both side orders",
            "quantiles", "Median averages central pair; p95 nearest rank ceil(0.95*n). Timeouts retained at maxRounds",
            "units", "Rounds are initiative ticks, actions are performed turns, not seconds; firstDeath=-1 if absent",
            "scope", "Working references preserve actual0/2/4 points. RISK_FULL uses separate full-modifier diagnostics. No effects",
            "scaling", "Round-half-up final post-defense/post-variance damage once at both HP sinks; expected normal damage also scaled; healing unchanged",
            "sinkAudit", DurationDamageScale.audit(), "summaries", summaries);
        try (final var out = Files.newOutputStream(Path.of(prefix + "-summary.json"), StandardOpenOption.CREATE_NEW)) {
            JSON.writerWithDefaultPrettyPrinter().writeValue(out, output);
        }
        if (violations != 0 || timeouts != 0) throw new IllegalStateException("Movement violation or timeout: retained in output");
    }

    static List<Case> cases() {
        final var result = new ArrayList<Case>();
        for (final var tier : TIERS) {
            for (final int size : List.of(1, 3, 7, 15)) {
                final var team = Step123ReferenceTeams.mainTeam(tier, size).members();
                add(result, "REFERENCE_MIRROR_N" + size, "REFERENCE_MIRROR", tier, team, team, Set.of());
            }
            final var main = Step123ReferenceTeams.mainTeam(tier, 3).members();
            for (final var spec : Specialization.values()) {
                add(result, "REFERENCE_MAIN_VS_" + spec, "REFERENCE_RESPONSE", tier, main,
                    Step123ReferenceTeams.specializedTeam(tier, spec).members(), Set.of());
            }
            final var builds = new LinkedHashMap<String, Build>();
            for (final var role : RoleBuild.values()) builds.put(role.name(), Step12RepresentativeBuilds.role(role));
            builds.put("RAIDER", Step12RepresentativeBuilds.mixed(MixedBuild.RAIDER));
            builds.put("DUELIST", Step12RepresentativeBuilds.mixed(MixedBuild.DUELIST));
            final var pairs = List.of(
                "GUARDIAN/BRUISER", "ASSASSIN/BRUISER", "RAIDER/BRUISER", "DUELIST/BRUISER",
                "TACTICIAN_PHYSICAL/BRUISER", "TACTICIAN_MAGICAL/BRUISER", "BREAKER_PHYSICAL/BRUISER",
                "BREAKER_MAGICAL/BRUISER", "SKIRMISHER/BRUISER", "ASSASSIN/RANGER_MAGICAL",
                "RAIDER/RANGER_MAGICAL", "DUELIST/RANGER_MAGICAL", "SKIRMISHER/BREAKER_PHYSICAL",
                "TACTICIAN_PHYSICAL/BREAKER_PHYSICAL", "TACTICIAN_MAGICAL/BREAKER_MAGICAL",
                "BREAKER_PHYSICAL/RANGER_PHYSICAL", "BREAKER_MAGICAL/RANGER_MAGICAL",
                "RANGER_PHYSICAL/RANGER_MAGICAL", "ASSASSIN/GUARDIAN", "RAIDER/GUARDIAN",
                "DUELIST/ASSASSIN", "RAIDER/ASSASSIN");
            for (final var pair : pairs) {
                final var keys = pair.split("/");
                add(result, "ROLE_" + keys[0] + "_VS_" + keys[1], "ROLE_PROTECTED", tier,
                    protectedTeam(builds.get(keys[0]), tier), protectedTeam(builds.get(keys[1]), tier), Set.of());
            }
            final var mobile = Step123ReferenceTeams.specializedTeam(tier, Specialization.MOBILE).members();
            final var support = Step123BattleStudy.historicalV3Build(V3Build.CROSSBOW_SUPPORT).withPosition(Position.MID);
            for (final var front : List.of(V3Build.BRUISER_BLUNT, V3Build.BREAKER_CLOSE_SLASH, V3Build.ASSASSIN_PIERCE)) {
                final var right = List.of(Step123BattleStudy.historicalV3Build(front).withPosition(Position.FRONT), support, support)
                    .stream().map(build -> new Gear(build, EquipmentCatalogVersion.SCALING_V5)).toList();
                for (final boolean disabled : List.of(false, true)) {
                    add(result, "MOBILE_NICHE_VS_" + front + (disabled ? "_OFF" : "_ON"), "MOBILE_NICHE", tier,
                        mobile, right, disabled ? Set.of(ActiveEnum.HIT_AND_RUN) : Set.of());
                }
            }
        }
        for (final int level : List.of(3, 6)) {
            for (final var pair : Step12RepresentativeRisks.pairs(ItemRarity.RARE)) {
                if (!Set.of("RISK05_GUARD_REACTIONS_MELEE", "RISK06_GUARD_MAGIC_ACCESS_RESPONSE",
                    "RISK09_ACCUMULATION_DAMAGE", "RISK10_ACCUMULATION_ACCESS_RESPONSE").contains(pair.code())) continue;
                final var left = pair.left().stream().map(b -> new Gear(b, EquipmentCatalogVersion.SCALING_V5)).toList();
                final var right = pair.right().stream().map(b -> new Gear(b, EquipmentCatalogVersion.SCALING_V5)).toList();
                result.add(new Case("FULL_" + pair.code() + "_L" + level, "RISK_FULL", "FULL_MODIFIERS", level,
                    "FULL_" + pair.code() + "_L" + level, left, right, Set.of()));
            }
        }
        if (Boolean.getBoolean("tempo.includeDirectResponses")) {
            for (final var tier : List.of(Tier.MID, Tier.STRONG)) {
                add(result, "DIRECT_PRESSURE_VS_FLANK", "DIRECT_RESPONSE", tier,
                    Step123ReferenceTeams.specializedTeam(tier, Specialization.PRESSURE).members(),
                    Step123ReferenceTeams.specializedTeam(tier, Specialization.FLANK).members(), Set.of());
            }
        }
        result.sort(Comparator.comparing(Case::code));
        if (result.stream().map(Case::code).distinct().count() != result.size()) throw new IllegalStateException("Duplicate case");
        return List.copyOf(result);
    }

    private static List<Gear> protectedTeam(Build tested, Tier tier) {
        final var guardian = Step12RepresentativeBuilds.role(RoleBuild.GUARDIAN);
        final var ranger = Step12RepresentativeBuilds.role(RoleBuild.RANGER_PHYSICAL).withPosition(Position.MID);
        if (tested.position() == Position.BACK) tested = tested.withPosition(Position.MID);
        return List.of(gear(guardian, tier), gear(tested, tier), gear(ranger, tier));
    }

    private static Gear gear(Build build, Tier tier) {
        final var assignments = new LinkedHashMap<String, Assignment>();
        if (tier.profilePoints() > 0) for (final var item : build.items(0)) {
            final var original = build.assignments().get(item.object().code());
            if (original == null) continue;
            final int points = original.rarity().skillPoints() * tier.profilePoints() / 4;
            if (points == 0) throw new IllegalArgumentException("Unsupported profile carrier");
            final var rarity = Arrays.stream(ItemRarity.values()).filter(r -> r.skillPoints() == points).findFirst().orElseThrow();
            assignments.put(item.object().code(), new Assignment(original.skill(), rarity));
        }
        return new Gear(build.withAssignments(assignments), EquipmentCatalogVersion.SCALING_V5);
    }

    private static void add(List<Case> cases, String name, String family, Tier tier,
                            List<Gear> left, List<Gear> right, Set<ActiveEnum> disabled) {
        final String code = name + "_" + tier;
        final String group = name.replace("_OFF", "").replace("_ON", "") + "_" + tier;
        cases.add(new Case(code, family, tier.name(), tier.level(), group, left, right, disabled));
    }

    private static List<Map<String, Object>> manifest(List<Gear> members, int level) {
        return members.stream().map(g -> map("build", g.build(), "catalog", g.catalog(),
            "actualSkillPoints", g.items(level).stream().mapToInt(Item::skillPoints).sum(),
            "items", g.items(level).stream().map(i -> map("code", i.object().code(), "rarity", i.rarity(),
                "level", i.enhanceLevel(), "points", i.modifier().isPresent() ? i.skillPoints() : 0,
                "skill", i.modifier().map(m -> m.activeEnum().name()).orElse("NONE"),
                "health", i.health(), "speed", i.speed(), "attacks", i.itemAttacks(),
                "defense", i.itemDefense().map(d -> map("type", d.defenseType(), "value", d.defense())).orElse(null))).toList())).toList();
    }

    private static long reactionDamage(BattleEvent event) {
        if (event instanceof BattleEvent.ScalingSkillDamage d && Set.of(ActiveEnum.THORNS, ActiveEnum.COUNTER_ATTACK).contains(d.skill())) return d.damageTaken();
        if (event instanceof BattleEvent.SkillDamage d && Set.of(ActiveEnum.THORNS, ActiveEnum.COUNTER_ATTACK).contains(d.skill())) return d.damageTaken();
        return 0;
    }

    private static Map<String, Object> stats(List<Sample> samples, ToLongFunction<Sample> field) {
        final var values = samples.stream().mapToLong(field).sorted().toArray();
        final int n = values.length;
        return map("median", n % 2 == 0 ? (values[n/2-1] + values[n/2]) / 2.0 : (double) values[n/2],
            "p95", values[(int) Math.ceil(0.95 * n) - 1], "mean", Arrays.stream(values).average().orElseThrow(),
            "min", values[0], "max", values[n-1]);
    }

    private static long iterationSeed(long seed, int iteration) {
        long mixed = seed + 0x9e3779b97f4a7c15L * (iteration + 1L);
        mixed = (mixed ^ mixed >>> 30) * 0xbf58476d1ce4e5b9L;
        mixed = (mixed ^ mixed >>> 27) * 0x94d049bb133111ebL;
        return mixed ^ mixed >>> 31;
    }

    private static Map<String, Object> map(Object... pairs) {
        final var result = new LinkedHashMap<String, Object>();
        for (int i = 0; i < pairs.length; i += 2) result.put((String) pairs[i], pairs[i+1]);
        return result;
    }

    record Case(String code, String family, String tier, int level, String seedGroup,
                List<Gear> left, List<Gear> right, Set<ActiveEnum> disabledLeft) { }

    record Sample(int pair, boolean reverse, long seed, String outcome, int rounds, long actions,
                  long attempts, long movementTurns, long firstDeathRound, long healing, long reactionDamage,
                  long accumulationDischarges, long forcedMoves, long forcedMoveViolations, long maxForcedDistance,
                  Step12RepresentativeBattleRunner.TeamMeasure left, Step12RepresentativeBattleRunner.TeamMeasure right) { }
}
