package ru.homyakin.seeker.game.battle;

import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.homyakin.seeker.game.battle.Step123ReferenceTeams.ReferenceTeam;
import ru.homyakin.seeker.game.battle.Step123ReferenceTeams.Specialization;
import ru.homyakin.seeker.game.battle.Step123ReferenceTeams.Tier;
import ru.homyakin.seeker.game.battle.simulation.Step12SimulationFixtures;
import ru.homyakin.seeker.game.battle.simulation.Step12SimulationFixtures.V3Build;
import ru.homyakin.seeker.game.battle.skill.active_impl.ActiveEnum;
import ru.homyakin.seeker.game.battle.skill.scaling.SkillFormulaVersion;
import ru.homyakin.seeker.game.item.catalog.EquipmentCatalogVersion;
import ru.homyakin.seeker.game.item.models.ItemProgressionVersion;
import ru.homyakin.seeker.game.item.models.ItemRarity;
import ru.homyakin.seeker.game.personage.models.PersonageSlot;
import ru.homyakin.seeker.utils.RandomUtils;

class Step123ReferenceTeamsTest {
    @Test
    void mainTeamsCoverEverySizeWithLegalFourthCatalogItemsAndExplicitCombatOrder() {
        for (final var tier : Tier.values()) {
            for (int size = 1; size <= 30; size++) {
                final var team = Step123ReferenceTeams.mainTeam(tier, size);
                Assertions.assertEquals(size, team.members().size());
                Assertions.assertEquals(team, Step123ReferenceTeams.mainTeam(tier, size));
                assertLegal(team);
                final var personages = RandomUtils.withSeed(2026102306L, team::personages);
                Assertions.assertEquals(size, personages.size());
                final var context = new BattleContext(personages, team.personages(), new SeededBattleRandom(2026102306L));
                Assertions.assertTrue(context.usesScalingSkillOrder());
                for (final var personage : personages) {
                    Assertions.assertTrue(personage.skillSnapshots().stream().allMatch(snapshot ->
                        snapshot.formulaVersion() == SkillFormulaVersion.SCALING_SKILLS_V2
                    ));
                }
            }
        }
        Assertions.assertThrows(IllegalArgumentException.class, () -> Step123ReferenceTeams.mainTeam(Tier.MID, 0));
        Assertions.assertThrows(IllegalArgumentException.class, () -> Step123ReferenceTeams.mainTeam(Tier.MID, 31));
    }

    @Test
    void mainCycleHasExactCountsPlacementsAndAssignmentCarriers() {
        final var three = Step123ReferenceTeams.mainTeam(Tier.MID, 3);
        Assertions.assertEquals(List.of("GUARDIAN", "RANGER_PHYSICAL", "RANGER_MAGICAL"), codes(three));
        Assertions.assertEquals(List.of(Position.FRONT, Position.MID, Position.MID), three.members().stream()
            .map(member -> member.build().position()).toList());
        final var seven = Step123ReferenceTeams.mainTeam(Tier.MID, 7);
        Assertions.assertEquals(List.of("GUARDIAN", "RANGER_PHYSICAL", "RANGER_MAGICAL", "GUARDIAN",
            "BRUISER", "RANGER_PHYSICAL", "RANGER_MAGICAL"), codes(seven));
        final var fifteen = Step123ReferenceTeams.mainTeam(Tier.MID, 15);
        Assertions.assertEquals(Map.of("GUARDIAN", 5L, "BRUISER", 2L, "RANGER_PHYSICAL", 4L, "RANGER_MAGICAL", 4L),
            codes(fifteen).stream().collect(java.util.stream.Collectors.groupingBy(
                java.util.function.Function.identity(), java.util.stream.Collectors.counting())));
        for (final var member : seven.members()) {
            final var build = member.build();
            final String carrier = switch (build.code()) {
                case "GUARDIAN" -> "tower_shield";
                case "BRUISER" -> "sledgehammer";
                case "RANGER_PHYSICAL" -> "longbow";
                case "RANGER_MAGICAL" -> "battle_staff";
                default -> throw new IllegalStateException(build.code());
            };
            Assertions.assertEquals(Set.of(carrier), build.assignments().keySet());
            Assertions.assertEquals(build.code().startsWith("RANGER") ? Position.MID : Position.FRONT, build.position());
        }
    }

    @Test
    void beginnerUsesCommonBasesAndStrongDoesNotAddPointsBeyondMid() {
        final var beginner = Step123ReferenceTeams.mainTeam(Tier.BEGINNER, 15);
        final var mid = Step123ReferenceTeams.mainTeam(Tier.MID, 15);
        final var strong = Step123ReferenceTeams.mainTeam(Tier.STRONG, 15);
        for (int index = 0; index < mid.members().size(); index++) {
            Assertions.assertEquals(beginner.members().get(index).build().itemCodes(), mid.members().get(index).build().itemCodes());
            Assertions.assertEquals(mid.members().get(index).build(), strong.members().get(index).build());
            Assertions.assertEquals(0, beginner.members().get(index).items(0).stream().mapToInt(item -> item.skillPoints()).sum());
            Assertions.assertEquals(4, mid.members().get(index).items(10).stream().mapToInt(item -> item.skillPoints()).sum());
            Assertions.assertEquals(4, strong.members().get(index).items(20).stream().mapToInt(item -> item.skillPoints()).sum());
            Assertions.assertTrue(beginner.members().get(index).items(0).stream().allMatch(item ->
                item.rarity() == ItemRarity.COMMON && item.modifier().isEmpty() && item.enhanceLevel() == 0
            ));
        }
    }

    @Test
    void mobileTemplateUsesFourHitAndRunPointsAndTheActualHistoricalCrossbowSupport() {
        final var mobile = Step123ReferenceTeams.specializedTeam(Tier.MID, Specialization.MOBILE);
        final var tested = mobile.members().getFirst().build();
        Assertions.assertEquals(List.of("spear", "dirk", "breastplate", "leather_chausses", "boots",
            "leather_helm", "leather_gloves"), tested.itemCodes());
        Assertions.assertEquals(Position.FRONT, tested.position());
        Assertions.assertEquals(Set.of("boots", "leather_helm"), tested.assignments().keySet());
        tested.assignments().values().forEach(assignment -> {
            Assertions.assertEquals(ActiveEnum.HIT_AND_RUN, assignment.skill());
            Assertions.assertEquals(ItemRarity.RARE, assignment.rarity());
        });
        for (final var member : mobile.members().subList(1, 3)) {
            Assertions.assertEquals(Position.MID, member.build().position());
            Assertions.assertEquals(Step12SimulationFixtures.v3Items(V3Build.CROSSBOW_SUPPORT, 10), member.items(10));
        }
        Assertions.assertEquals(List.of("GUARDIAN", "BRUISER", "BRUISER"),
            codes(Step123ReferenceTeams.specializedTeam(Tier.MID, Specialization.PRESSURE)));
        Assertions.assertEquals(List.of("GUARDIAN", "ASSASSIN", "RAIDER"),
            codes(Step123ReferenceTeams.specializedTeam(Tier.MID, Specialization.FLANK)));
        for (final var tier : Tier.values()) {
            for (final var specialization : Specialization.values()) {
                assertLegal(Step123ReferenceTeams.specializedTeam(tier, specialization));
            }
        }
    }

    @Test
    void knownPurchaseAndRarityCostsAreExplicitAndDoNotIncludeStormEnhancement() throws Exception {
        for (final var tier : List.of(Tier.MID, Tier.STRONG)) {
            Assertions.assertEquals(4725, knownGold(Step123ReferenceTeams.mainTeam(tier, 3)));
            Assertions.assertEquals(10600, knownGold(Step123ReferenceTeams.mainTeam(tier, 7)));
            Assertions.assertEquals(23625, knownGold(Step123ReferenceTeams.mainTeam(tier, 15)));
            Assertions.assertEquals(3000, knownGold(Step123ReferenceTeams.specializedTeam(tier, Specialization.MOBILE)));
            Assertions.assertEquals(4725, knownGold(Step123ReferenceTeams.specializedTeam(tier, Specialization.PRESSURE)));
            Assertions.assertEquals(6450, knownGold(Step123ReferenceTeams.specializedTeam(tier, Specialization.FLANK)));
        }
        Assertions.assertEquals(2100, knownGold(Step123ReferenceTeams.mainTeam(Tier.BEGINNER, 3)));
        for (final var specialization : Specialization.values()) {
            Assertions.assertEquals(2100, knownGold(Step123ReferenceTeams.specializedTeam(Tier.BEGINNER, specialization)));
        }
    }

    private static List<String> codes(ReferenceTeam team) {
        return team.members().stream().map(member -> member.build().code()).toList();
    }

    private static long knownGold(ReferenceTeam team) throws Exception {
        return Step123BattleStudy.knownGold(team.members(), team.tier().level());
    }

    private static void assertLegal(ReferenceTeam team) {
        for (final var member : team.members()) {
            Assertions.assertEquals(EquipmentCatalogVersion.SCALING_V4, member.catalog());
            final var occupied = EnumSet.noneOf(PersonageSlot.class);
            for (final var item : member.items(team.tier().level())) {
                Assertions.assertEquals(ItemProgressionVersion.V1, item.object().progressionVersion());
                Assertions.assertEquals(team.tier().level(), item.enhanceLevel());
                item.object().slots().forEach(slot -> Assertions.assertTrue(occupied.add(slot)));
            }
            Assertions.assertEquals(EnumSet.allOf(PersonageSlot.class), occupied);
        }
    }
}
