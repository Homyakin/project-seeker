package ru.homyakin.seeker.game.battle;

import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import ru.homyakin.seeker.game.battle.Step123BattleRunner.Gear;
import ru.homyakin.seeker.game.battle.Step12RepresentativeBuilds.Assignment;
import ru.homyakin.seeker.game.battle.Step12RepresentativeBuilds.Build;
import ru.homyakin.seeker.game.battle.simulation.Step12SimulationFixtures.MixedBuild;
import ru.homyakin.seeker.game.battle.simulation.Step12SimulationFixtures.RoleBuild;
import ru.homyakin.seeker.game.battle.simulation.Step12SimulationFixtures.V3Build;
import ru.homyakin.seeker.game.battle.skill.active_impl.ActiveEnum;
import ru.homyakin.seeker.game.battle.targeting.TargetingTactic;
import ru.homyakin.seeker.game.item.catalog.EquipmentCatalogVersion;
import ru.homyakin.seeker.game.item.models.Item;
import ru.homyakin.seeker.game.item.models.ItemRarity;

/**
 * Explicit inputs for later PvE studies, not victorious teams or a power-based difficulty ladder.
 *
 * <p>Main teams use the fixed cycle G,R,M,G,B,R,M, truncated at the requested size in 1..30.
 * G and B start in front; R and M start in the middle, within a front guard's protection.
 * Thus size 3 is G,R,M; size 7 has 2G/1B/2R/2M; size 15 has 5G/2B/4R/4M.
 * The cycle never consults displayed power, opponents, outcomes or random selection.</p>
 */
public final class Step123ReferenceTeams {
    private static final List<RoleBuild> CYCLE = List.of(
        RoleBuild.GUARDIAN, RoleBuild.RANGER_PHYSICAL, RoleBuild.RANGER_MAGICAL,
        RoleBuild.GUARDIAN, RoleBuild.BRUISER, RoleBuild.RANGER_PHYSICAL, RoleBuild.RANGER_MAGICAL
    );

    private Step123ReferenceTeams() {
    }

    public static ReferenceTeam mainTeam(Tier tier, int size) {
        Objects.requireNonNull(tier, "Tier must be specified");
        if (size < 1 || size > 30) {
            throw new IllegalArgumentException("Reference team size must be in 1..30");
        }
        final var members = new ArrayList<Gear>();
        for (int index = 0; index < size; index++) {
            final var role = CYCLE.get(index % CYCLE.size());
            var build = Step12RepresentativeBuilds.role(role);
            if (role == RoleBuild.RANGER_PHYSICAL || role == RoleBuild.RANGER_MAGICAL) {
                build = build.withPosition(Position.MID);
            }
            members.add(gear(build, tier));
        }
        return new ReferenceTeam("MAIN_" + size + "_" + tier, tier, members);
    }

    public static ReferenceTeam specializedTeam(Tier tier, Specialization specialization) {
        Objects.requireNonNull(tier, "Tier must be specified");
        Objects.requireNonNull(specialization, "Specialization must be specified");
        final var guardian = Step12RepresentativeBuilds.role(RoleBuild.GUARDIAN);
        final var bruiser = Step12RepresentativeBuilds.role(RoleBuild.BRUISER);
        final List<Build> builds = switch (specialization) {
            case MOBILE -> {
                final var mobile = Step12RepresentativeBuilds.hand(
                    "MOBILE_SPEAR_LEATHER", List.of("spear", "dirk"), "LEATHER",
                    Position.FRONT, TargetingTactic.THREAT
                ).withAssignments(Map.of(
                    "boots", new Assignment(ActiveEnum.HIT_AND_RUN, ItemRarity.RARE),
                    "leather_helm", new Assignment(ActiveEnum.HIT_AND_RUN, ItemRarity.RARE)
                ));
                final var support = Step123BattleStudy.historicalV3Build(V3Build.CROSSBOW_SUPPORT)
                    .withPosition(Position.MID);
                yield List.of(mobile, support, support);
            }
            case PRESSURE -> List.of(guardian, bruiser, bruiser);
            case FLANK -> List.of(
                guardian, Step12RepresentativeBuilds.role(RoleBuild.ASSASSIN),
                Step12RepresentativeBuilds.mixed(MixedBuild.RAIDER)
            );
        };
        return new ReferenceTeam(specialization + "_" + tier, tier,
            builds.stream().map(build -> gear(build, tier)).toList());
    }

    private static Gear gear(Build build, Tier tier) {
        return new Gear(tier == Tier.BEGINNER ? build.withAssignments(Map.of()) : build,
            EquipmentCatalogVersion.SCALING_V4);
    }

    /** Writes only an explicitly requested new file; does not run battles, connect to a DB or activate a release. */
    public static void main(String[] args) throws Exception {
        if (args.length != 1 || args[0].isBlank()) {
            throw new IllegalArgumentException("Specify one new JSON output path");
        }
        final var teams = new ArrayList<ReferenceTeam>();
        for (final var tier : Tier.values()) {
            for (final int size : List.of(3, 7, 15)) {
                teams.add(mainTeam(tier, size));
            }
            for (final var specialization : Specialization.values()) {
                teams.add(specializedTeam(tier, specialization));
            }
        }
        final var exported = teams.stream().map(team -> new ExportedTeam(
            team.code(), team.tier(), team.tier().level(),
            team.members().stream().map(member -> new ExportedMember(
                member.build().code(), member.catalog(), member.build().position(), member.build().tactic(),
                member.items(team.tier().level())
            )).toList()
        )).toList();
        final var json = JsonMapper.builder().addModule(new Jdk8Module()).build();
        try (final var output = Files.newOutputStream(Path.of(args[0]), StandardOpenOption.CREATE_NEW)) {
            json.writerWithDefaultPrettyPrinter().writeValue(output, Map.of(
                "purpose", "Input baselines for later PvE studies; no victory or strict tier-strength claim",
                "cycle", "G,R,M,G,B,R,M", "combat", "SCALING_SKILLS_V2", "teams", exported
            ));
        }
    }

    public enum Tier {
        BEGINNER(0),
        MID(10),
        STRONG(20);

        private final int level;

        Tier(int level) {
            this.level = level;
        }

        public int level() {
            return level;
        }
    }

    public enum Specialization {
        MOBILE,
        PRESSURE,
        FLANK,
    }

    public record ReferenceTeam(String code, Tier tier, List<Gear> members) {
        public ReferenceTeam {
            Objects.requireNonNull(code);
            Objects.requireNonNull(tier);
            members = List.copyOf(members);
            if (members.isEmpty() || members.size() > 30) {
                throw new IllegalArgumentException("Reference team size must be in 1..30");
            }
        }

        /** Creates fresh battle state; callers may wrap this in RandomUtils.withSeed when they need fixed UUIDs. */
        public List<BattlePersonage> personages() {
            return members.stream().map(member -> {
                final var build = member.build();
                final var personage = BattlePersonage.forScalingSkillsV2Combat(
                    member.items(tier.level()), build.position(), Map.of(), Optional.of(build.code())
                );
                personage.setTargetingTactic(build.tactic());
                return personage;
            }).toList();
        }
    }

    private record ExportedTeam(String code, Tier tier, int enhanceLevel, List<ExportedMember> members) {
    }

    private record ExportedMember(String code, EquipmentCatalogVersion catalog, Position position,
                                  TargetingTactic tactic, List<Item> items) {
    }
}
