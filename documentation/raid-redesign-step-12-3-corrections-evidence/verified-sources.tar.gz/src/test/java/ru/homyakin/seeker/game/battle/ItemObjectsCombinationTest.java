package ru.homyakin.seeker.game.battle;

import ru.homyakin.seeker.game.item.catalog.ItemObjectsToml;
import ru.homyakin.seeker.game.item.models.AttackType;
import ru.homyakin.seeker.game.item.models.DefaultItems;
import ru.homyakin.seeker.game.item.models.DefenseType;
import ru.homyakin.seeker.game.item.models.Item;
import ru.homyakin.seeker.game.item.models.ItemAttack;
import ru.homyakin.seeker.game.item.models.ItemDefense;
import ru.homyakin.seeker.game.item.models.ItemObject;

import org.apache.commons.math3.stat.descriptive.rank.Percentile;
import org.junit.jupiter.api.Test;
import ru.homyakin.seeker.game.personage.models.PersonageSlot;
import ru.homyakin.seeker.utils.ResourceUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Loads {@code game-data/item_objects_catalog.toml}, builds every loadout with one object per slot,
 * runs {@link Battle}, ranks by {@link BattlePersonage#legacyPower()}.
 */
class ItemObjectsCombinationTest {
    private static final String TOML_PATH = "game-data/item_objects_catalog.toml";
    private static final double BASE_CRIT_MULTIPLIER = 1.2;

    @Test
    void rankEachItemObjectByPower() {
        final var ranked = loadObjects().stream()
            .map(object -> {
                final var personage = personageFrom(List.of(object));
                final var power = personage.legacyPower();
                assertTrue(
                    Double.isFinite(power) && power > 0,
                    () -> object.code() + " has invalid power: " + power
                );
                return new RankedObject(object, power);
            })
            .sorted(Comparator.comparingDouble(RankedObject::power))
            .toList();

        assertFalse(ranked.isEmpty());
        printObjectPowerStats("objects", ranked);
        printObjectPowerStatsBySlot(ranked);
        assertDefaultItemsWeakestPerSlot(ranked);
    }

    @Test
    void rankAllCombinationsByPower() {
        final var objects = loadObjects();
        final var bySlot = groupBySlot(objects);
        final var combinations = allSlotCombinations(bySlot);
        final var baseline = personageFrom(combinations.getFirst());

        final var ranked = combinations.stream()
            .map(codes -> {
                final var personage = personageFrom(codes);
                assertDoesNotThrow(() -> new Battle().process(
                    List.of(personage),
                    List.of(baseline)
                ));
                return new RankedLoadout(codes, personage.legacyPower());
            })
            .sorted(Comparator.comparingDouble(RankedLoadout::power))
            .toList();

        assertFalse(ranked.isEmpty());
        printPowerStats(ranked);
    }

    @Test
    void referenceLoadoutsMatchTargetStats() {
        final var objectsByCode = loadObjects().stream()
            .collect(Collectors.toMap(ItemObject::code, object -> object));

        assertLoadoutStats(
            objectsByCode,
            List.of("mace", "tower_shield", "cuirass", "greaves", "sabatons", "great_helm", "gauntlets"),
            new LoadoutStats(2280, DefenseType.PLATE, 198, AttackType.BLUNT, 298, 1, 2, 1, 1.25, 87, 56)
        );
        assertLoadoutStats(
            objectsByCode,
            List.of("spear", "dirk", "breastplate", "leather_chausses", "boots", "leather_helm", "leather_gloves"),
            new LoadoutStats(1600, DefenseType.LEATHER, 96, AttackType.PIERCE, 362, 2, 10, 12, 1.55, 138, 15)
        );
        assertLoadoutStats(
            objectsByCode,
            List.of("sword", "shortsword", "breastplate", "leather_chausses", "boots", "leather_helm", "leather_gloves"),
            new LoadoutStats(1600, DefenseType.LEATHER, 96, AttackType.SLASH, 350, 1, 9, 9, 1.55, 140, 16)
        );
        assertLoadoutStats(
            objectsByCode,
            List.of("staff", "orb", "wizard_robe", "arcane_chausses", "arcane_boots", "circlet", "arcane_gloves"),
            new LoadoutStats(1270, DefenseType.ARCANE, 122, AttackType.MAGICAL, 360, 3, 13, 7, 1.63, 156, 9)
        );
        assertLoadoutStats(
            objectsByCode,
            List.of("staff", "orb", "robe", "cloth_chausses", "cloth_boots", "hood", "cloth_gloves"),
            new LoadoutStats(1090, DefenseType.CLOTH, 65, AttackType.MAGICAL, 360, 3, 10, 7, 1.58, 178, 10)
        );
    }

    @Test
    void armorMaterialRulesHoldPerSlot() {
        final var objectsByCode = loadObjects().stream()
            .collect(Collectors.toMap(ItemObject::code, object -> object));

        assertArmorSlotRules(objectsByCode, "robe", "wizard_robe", "breastplate", "cuirass");
        assertArmorSlotRules(objectsByCode, "cloth_chausses", "arcane_chausses", "leather_chausses", "greaves");
        assertArmorSlotRules(objectsByCode, "cloth_boots", "arcane_boots", "boots", "sabatons");
        assertArmorSlotRules(objectsByCode, "hood", "circlet", "leather_helm", "great_helm");
        assertArmorSlotRules(objectsByCode, "cloth_gloves", "arcane_gloves", "leather_gloves", "gauntlets");
        assertArmorSlotRules(objectsByCode, "buckler", "tome", "shield", "tower_shield");
    }

    @Test
    void objectStatsStayWithinCaps() {
        for (final var object : loadObjects()) {
            assertTrue(object.critChance() <= 5, () -> object.code() + " critChance is above cap");
            assertTrue(object.dodgeChance() <= 5, () -> object.code() + " dodgeChance is above cap");
            assertTrue(object.critMultiplier() <= 0.1, () -> object.code() + " critMultiplier is above cap");
            assertTrue(object.speed() <= 50, () -> object.code() + " speed is above cap");
            assertTrue(object.baseThreat() <= 20, () -> object.code() + " baseThreat is above cap");
        }
    }

    private static void printObjectPowerStatsBySlot(List<RankedObject> catalogRankedAscending) {
        final var defaultsBySlot = defaultObjectsBySlot();
        System.out.println("objects by slot:");
        for (final var slot : PersonageSlot.values()) {
            final var slotRanked = rankObjectsForSlot(slot, catalogRankedAscending, defaultsBySlot.get(slot));
            printObjectPowerStats(slot.name(), slotRanked);
            printSlotRanking(slot, slotRanked, defaultsBySlot.get(slot));
        }
    }

    private static void assertDefaultItemsWeakestPerSlot(List<RankedObject> catalogRankedAscending) {
        final var defaultsBySlot = defaultObjectsBySlot();
        for (final var slot : PersonageSlot.values()) {
            final var defaultObject = defaultsBySlot.get(slot);
            final var slotRanked = rankObjectsForSlot(slot, catalogRankedAscending, defaultObject);
            final var defaultPower = slotRanked.stream()
                .filter(ranked -> ranked.object().code().equals(defaultObject.code()))
                .mapToDouble(RankedObject::power)
                .findFirst()
                .orElseThrow();
            final var minCatalogPower = catalogRankedAscending.stream()
                .filter(ranked -> ranked.object().slots().contains(slot))
                .mapToDouble(RankedObject::power)
                .min()
                .orElseThrow();

            assertTrue(
                defaultPower <= minCatalogPower,
                () -> defaultObject.code() + " power " + defaultPower
                    + " exceeds weakest catalog object for " + slot + " (" + minCatalogPower + ")"
            );
        }
    }

    private static List<RankedObject> rankObjectsForSlot(
        PersonageSlot slot,
        List<RankedObject> catalogRankedAscending,
        ItemObject defaultObject
    ) {
        final var slotRanked = catalogRankedAscending.stream()
            .filter(rankedObject -> rankedObject.object().slots().contains(slot))
            .collect(Collectors.toCollection(ArrayList::new));
        final var defaultPower = personageFrom(List.of(defaultObject)).legacyPower();
        slotRanked.add(new RankedObject(defaultObject, defaultPower));
        slotRanked.sort(Comparator.comparingDouble(RankedObject::power));
        return slotRanked;
    }

    private static void printSlotRanking(PersonageSlot slot, List<RankedObject> slotRankedAscending, ItemObject defaultObject) {
        System.out.println(slot.name() + " ranking:");
        for (var i = 0; i < slotRankedAscending.size(); i++) {
            final var ranked = slotRankedAscending.get(i);
            final var marker = ranked.object().code().equals(defaultObject.code()) ? " [default]" : "";
            System.out.printf("%2d. %.2f  %s%s%n", i + 1, ranked.power(), ranked.object().code(), marker);
        }
    }

    private static Map<PersonageSlot, ItemObject> defaultObjectsBySlot() {
        final var defaultsBySlot = new EnumMap<PersonageSlot, ItemObject>(PersonageSlot.class);
        defaultsBySlot.put(PersonageSlot.MAIN_HAND, DefaultItems.MAIN_FIST.object());
        defaultsBySlot.put(PersonageSlot.OFF_HAND, DefaultItems.OFF_FIST.object());
        defaultsBySlot.put(PersonageSlot.BODY, DefaultItems.SHIRT.object());
        defaultsBySlot.put(PersonageSlot.PANTS, DefaultItems.PANTS.object());
        defaultsBySlot.put(PersonageSlot.SHOES, DefaultItems.SHOES.object());
        defaultsBySlot.put(PersonageSlot.HELMET, DefaultItems.HELMET.object());
        defaultsBySlot.put(PersonageSlot.GLOVES, DefaultItems.GLOVES.object());
        return defaultsBySlot;
    }

    private static void printObjectPowerStats(String title, List<RankedObject> rankedAscending) {
        final var powers = rankedAscending.stream().mapToDouble(RankedObject::power).toArray();
        final var percentile = new Percentile();
        final var avg = Arrays.stream(powers).average().orElse(0);

        System.out.println(title + ": " + powers.length);
        System.out.printf("min: %.2f%n", powers[0]);
        System.out.printf("max: %.2f%n", powers[powers.length - 1]);
        System.out.printf("avg: %.2f%n", avg);

        final int[] percentiles = {1, 5, 10, 25, 50, 75, 90, 95, 99};
        for (final int p : percentiles) {
            final var value = percentile.evaluate(powers, p);
            System.out.printf("p%d: %.2f  %s%n", p, value, objectAtPower(rankedAscending, value).code());
        }

        System.out.printf("min object: %.2f  %s%n", powers[0], rankedAscending.getFirst().object().code());
        System.out.printf("max object: %.2f  %s%n", powers[powers.length - 1], rankedAscending.getLast().object().code());
    }

    private static ItemObject objectAtPower(List<RankedObject> rankedAscending, double targetPower) {
        return rankedAscending.stream()
            .min(Comparator.comparingDouble(entry -> Math.abs(entry.power() - targetPower)))
            .orElseThrow()
            .object();
    }

    private static void printPowerStats(List<RankedLoadout> rankedAscending) {
        final var powers = rankedAscending.stream().mapToDouble(RankedLoadout::power).toArray();
        final var percentile = new Percentile();
        final var avg = Arrays.stream(powers).average().orElse(0);

        System.out.println("combinations: " + powers.length);
        System.out.printf("min: %.2f%n", powers[0]);
        System.out.printf("max: %.2f%n", powers[powers.length - 1]);
        System.out.printf("avg: %.2f%n", avg);

        final int[] percentiles = {1, 5, 10, 25, 50, 75, 90, 95, 99};
        for (final int p : percentiles) {
            final var value = percentile.evaluate(powers, p);
            System.out.printf("p%d: %.2f  %s%n", p, value, formatCodes(loadoutAtPower(rankedAscending, value)));
        }

        System.out.printf("min loadout: %.2f  %s%n", powers[0], formatCodes(rankedAscending.getFirst().codes()));
        System.out.printf("max loadout: %.2f  %s%n", powers[powers.length - 1], formatCodes(rankedAscending.getLast().codes()));
        assertTrue(powers[0] > 80_000);
        assertTrue(powers[powers.length - 1] < 105_000);
    }

    private static List<ItemObject> loadoutAtPower(List<RankedLoadout> rankedAscending, double targetPower) {
        return rankedAscending.stream()
            .min(Comparator.comparingDouble(loadout -> Math.abs(loadout.power() - targetPower)))
            .orElseThrow()
            .codes();
    }

    private static List<ItemObject> loadObjects() {
        return ResourceUtils.calc(TOML_PATH, ItemObjectsToml::load)
            .orElseThrow(() -> new IllegalStateException("Missing " + TOML_PATH))
            .itemObjects();
    }

    private static Map<PersonageSlot, List<ItemObject>> groupBySlot(List<ItemObject> objects) {
        final var bySlot = new EnumMap<PersonageSlot, List<ItemObject>>(PersonageSlot.class);
        for (final var slot : PersonageSlot.values()) {
            final var slotObjects = objects.stream()
                .filter(object -> object.slots().contains(slot))
                .toList();
            assertFalse(
                slotObjects.isEmpty(),
                () -> "No objects for slot " + slot + " in " + TOML_PATH
            );
            bySlot.put(slot, slotObjects);
        }
        return bySlot;
    }

    private static List<List<ItemObject>> allSlotCombinations(Map<PersonageSlot, List<ItemObject>> bySlot) {
        final var combinations = new ArrayList<List<ItemObject>>();
        collectSlotCombinations(bySlot, Set.of(), List.of(), combinations);
        for (final var loadout : combinations) {
            final var usedSlots = loadout.stream()
                .flatMap(object -> object.slots().stream())
                .collect(Collectors.toSet());
            assertEquals(Set.copyOf(List.of(PersonageSlot.values())), usedSlots);
            assertEquals(
                usedSlots.size(),
                loadout.stream().mapToInt(object -> object.slots().size()).sum(),
                () -> "Overlapping slots in " + formatCodes(loadout)
            );
        }
        return combinations;
    }

    private static void collectSlotCombinations(
        Map<PersonageSlot, List<ItemObject>> bySlot,
        Set<PersonageSlot> occupiedSlots,
        List<ItemObject> loadout,
        List<List<ItemObject>> combinations
    ) {
        final var nextSlot = Arrays.stream(PersonageSlot.values())
            .filter(slot -> !occupiedSlots.contains(slot))
            .findFirst();
        if (nextSlot.isEmpty()) {
            combinations.add(List.copyOf(loadout));
            return;
        }

        for (final var object : bySlot.get(nextSlot.orElseThrow())) {
            if (!disjoint(object.slots(), occupiedSlots)) {
                continue;
            }
            final var nextOccupiedSlots = new java.util.HashSet<>(occupiedSlots);
            nextOccupiedSlots.addAll(object.slots());

            final var nextLoadout = new ArrayList<>(loadout);
            nextLoadout.add(object);

            collectSlotCombinations(bySlot, Set.copyOf(nextOccupiedSlots), List.copyOf(nextLoadout), combinations);
        }
    }

    private static boolean disjoint(Set<PersonageSlot> slots, Set<PersonageSlot> occupiedSlots) {
        return slots.stream().noneMatch(occupiedSlots::contains);
    }

    private static BattlePersonage personageFrom(List<ItemObject> objects) {
        final var items = objects.stream().map(Item::fromObject).toList();
        return new BattlePersonage(items, Position.FRONT);
    }

    private static String formatCodes(List<ItemObject> objects) {
        return objects.stream()
            .map(ItemObject::code)
            .collect(Collectors.joining(", "));
    }

    private static void assertLoadoutStats(
        Map<String, ItemObject> objectsByCode,
        List<String> codes,
        LoadoutStats expected
    ) {
        final var objects = codes.stream()
            .map(objectsByCode::get)
            .toList();
        assertFalse(objects.contains(null), () -> "Missing object in " + codes);

        final var attack = objects.stream()
            .flatMap(object -> object.attacks().stream())
            .filter(itemAttack -> itemAttack.attackType() == expected.attackType())
            .mapToInt(ItemAttack::attack)
            .sum();
        final var maxRange = objects.stream()
            .flatMap(object -> object.attacks().stream())
            .mapToInt(ItemAttack::maxRange)
            .max()
            .orElse(1);
        final var defense = objects.stream()
            .flatMap(object -> object.defense().stream())
            .filter(itemDefense -> itemDefense.defenseType() == expected.defenseType())
            .mapToInt(ItemDefense::defense)
            .sum();

        assertEquals(expected.health(), objects.stream().mapToInt(ItemObject::health).sum(), codes.toString());
        assertEquals(expected.defense(), defense, codes.toString());
        assertEquals(expected.attack(), attack, codes.toString());
        assertEquals(expected.range(), maxRange, codes.toString());
        assertEquals(expected.critChance(), objects.stream().mapToInt(ItemObject::critChance).sum(), codes.toString());
        assertEquals(expected.dodgeChance(), objects.stream().mapToInt(ItemObject::dodgeChance).sum(), codes.toString());
        assertEquals(
            expected.critMultiplier(),
            BASE_CRIT_MULTIPLIER + objects.stream().mapToDouble(ItemObject::critMultiplier).sum(),
            0.000_001,
            codes.toString()
        );
        assertEquals(expected.speed(), objects.stream().mapToInt(ItemObject::speed).sum(), codes.toString());
        assertEquals(expected.baseThreat(), objects.stream().mapToInt(ItemObject::baseThreat).sum(), codes.toString());
    }

    private static void assertArmorSlotRules(
        Map<String, ItemObject> objectsByCode,
        String clothCode,
        String arcaneCode,
        String leatherCode,
        String plateCode
    ) {
        final var cloth = objectsByCode.get(clothCode);
        final var arcane = objectsByCode.get(arcaneCode);
        final var leather = objectsByCode.get(leatherCode);
        final var plate = objectsByCode.get(plateCode);
        final var slotLabel = clothCode + "/" + arcaneCode + "/" + leatherCode + "/" + plateCode;

        assertTrue(
            cloth.speed() > arcane.speed()
                && arcane.speed() > leather.speed()
                && leather.speed() > plate.speed(),
            () -> slotLabel + ": speed should rank cloth > arcane > leather > plate"
        );
        assertTrue(
            plate.health() > leather.health()
                && leather.health() > arcane.health()
                && arcane.health() > cloth.health(),
            () -> slotLabel + ": health should rank plate > leather > arcane > cloth"
        );
        assertTrue(
            plate.defense().orElseThrow().defense() > arcane.defense().orElseThrow().defense()
                && arcane.defense().orElseThrow().defense() > leather.defense().orElseThrow().defense()
                && leather.defense().orElseThrow().defense() > cloth.defense().orElseThrow().defense(),
            () -> slotLabel + ": defense should rank plate > arcane > leather > cloth"
        );
    }

    private record RankedObject(ItemObject object, double power) {
    }

    private record RankedLoadout(List<ItemObject> codes, double power) {
    }

    private record LoadoutStats(
        int health,
        DefenseType defenseType,
        int defense,
        AttackType attackType,
        int attack,
        int range,
        int critChance,
        int dodgeChance,
        double critMultiplier,
        int speed,
        int baseThreat
    ) {
    }
}
