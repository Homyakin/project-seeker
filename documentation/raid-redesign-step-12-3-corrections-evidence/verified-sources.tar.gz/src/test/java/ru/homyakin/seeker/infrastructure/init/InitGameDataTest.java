package ru.homyakin.seeker.infrastructure.init;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.Mockito;
import ru.homyakin.seeker.game.item.catalog.EquipmentCatalogVersion;
import ru.homyakin.seeker.game.item.catalog.EquipmentReleaseConfig;
import ru.homyakin.seeker.game.item.catalog.EquipmentReleaseCoordinator;
import ru.homyakin.seeker.game.item.database.ItemCatalogLifecycleDao;
import ru.homyakin.seeker.game.battle.PlayerCombatConfig;
import ru.homyakin.seeker.game.personage.power.PowerDisplayService;
import ru.homyakin.seeker.game.personage.power.PowerDisplayVersion;
import ru.homyakin.seeker.game.event.service.EventService;
import ru.homyakin.seeker.game.item.ItemCatalogService;
import ru.homyakin.seeker.game.badge.action.BadgeService;
import ru.homyakin.seeker.game.rumor.RumorService;
import ru.homyakin.seeker.game.tavern_menu.menu.MenuService;

import static org.mockito.Mockito.mock;

public class InitGameDataTest {
    private final InitGameDataConfig config = new InitGameDataConfig();
    private final ItemCatalogService itemCatalogService = mock(ItemCatalogService.class);
    private final InitGameData initGameData = new InitGameData(
        mock(EventService.class),
        mock(MenuService.class),
        mock(RumorService.class),
        mock(BadgeService.class),
        new EquipmentReleaseCoordinator(
            new EquipmentReleaseConfig(),
            new PlayerCombatConfig(),
            new PowerDisplayService(PowerDisplayVersion.LEGACY_V1),
            itemCatalogService,
            mock(ItemCatalogLifecycleDao.class)
        ),
        config
    );

    @ParameterizedTest
    @EnumSource(InitGameDataType.class)
    public void When_LoadRaids_Then_NoErrors(InitGameDataType type) {
        config.setType(type);
        Assertions.assertDoesNotThrow(initGameData::loadRaids);
    }

    @ParameterizedTest
    @EnumSource(InitGameDataType.class)
    public void When_LoadMenuItems_Then_NoErrors(InitGameDataType type) {
        config.setType(type);
        Assertions.assertDoesNotThrow(initGameData::loadMenuItems);
    }

    @ParameterizedTest
    @EnumSource(InitGameDataType.class)
    public void When_LoadRumors_Then_NoErrors(InitGameDataType type) {
        config.setType(type);
        Assertions.assertDoesNotThrow(initGameData::loadRumors);
    }

    @ParameterizedTest
    @EnumSource(InitGameDataType.class)
    public void When_LoadBadges_Then_NoErrors(InitGameDataType type) {
        config.setType(type);
        Assertions.assertDoesNotThrow(initGameData::loadBadges);
    }

    @ParameterizedTest
    @EnumSource(InitGameDataType.class)
    public void When_LoadItemsCatalog_Then_NoErrors(InitGameDataType type) {
        config.setType(type);
        Assertions.assertDoesNotThrow(initGameData::loadItemsCatalog);
        Mockito.verify(itemCatalogService).stageRelease(
            Mockito.eq(EquipmentCatalogVersion.SCALING_V1),
            Mockito.argThat(codes -> codes.size() == 40),
            Mockito.argThat(codes -> codes.size() == 11)
        );
        Mockito.verify(itemCatalogService, Mockito.never()).stageRelease(
            Mockito.eq(EquipmentCatalogVersion.SCALING_V2),
            Mockito.anyList(),
            Mockito.anyList()
        );
        Mockito.verify(itemCatalogService, Mockito.never()).activateRelease(Mockito.any());
    }

    @ParameterizedTest
    @EnumSource(InitGameDataType.class)
    public void When_LoadPersonalQuests_Then_NoErrors(InitGameDataType type) {
        config.setType(type);
        Assertions.assertDoesNotThrow(initGameData::loadPersonalQuests);
    }

    @ParameterizedTest
    @EnumSource(InitGameDataType.class)
    public void When_LoadWorldRaids_Then_NoErrors(InitGameDataType type) {
        config.setType(type);
        Assertions.assertDoesNotThrow(initGameData::loadWorldRaids);
    }
}
