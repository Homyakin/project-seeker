package ru.homyakin.seeker.game.group.action.personage;

import io.vavr.control.Either;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.homyakin.seeker.common.models.GroupId;
import ru.homyakin.seeker.game.group.action.GroupTaxService;
import ru.homyakin.seeker.game.group.entity.GroupConfig;
import ru.homyakin.seeker.game.group.entity.GroupStorage;
import ru.homyakin.seeker.game.group.entity.personage.GroupPersonageStorage;
import ru.homyakin.seeker.game.group.error.ConfirmLeaveGroupMemberResult;
import ru.homyakin.seeker.game.group.error.LeaveGroupMemberError;
import ru.homyakin.seeker.game.personage.models.PersonageId;
import ru.homyakin.seeker.utils.TimeUtils;

@Component
public class ConfirmLeaveGroupMemberCommand {
    private final GroupPersonageStorage groupPersonageStorage;
    private final GroupStorage groupStorage;
    private final GroupConfig config;
    private final GroupTaxService groupTaxService;

    public ConfirmLeaveGroupMemberCommand(
        GroupPersonageStorage groupPersonageStorage,
        GroupStorage groupStorage,
        GroupConfig config,
        GroupTaxService groupTaxService
    ) {
        this.groupPersonageStorage = groupPersonageStorage;
        this.groupStorage = groupStorage;
        this.config = config;
        this.groupTaxService = groupTaxService;
    }

    @Transactional
    public Either<LeaveGroupMemberError.NotGroupMember, ConfirmLeaveGroupMemberResult> execute(
        PersonageId personageId,
        GroupId groupId
    ) {
        final var personageMemberGroup = groupPersonageStorage.getPersonageMemberGroup(personageId);
        if (!personageMemberGroup.isGroupMember(groupId)) {
            return Either.left(LeaveGroupMemberError.NotGroupMember.INSTANCE);
        }
        return Either.right(leave(personageId, groupId));
    }

    @Transactional
    public Either<LeaveGroupMemberError.NotGroupMember, ConfirmLeaveGroupMemberResult> execute(
        PersonageId personageId
    ) {
        final var personageMemberGroup = groupPersonageStorage.getPersonageMemberGroup(personageId);
        if (!personageMemberGroup.hasGroup()) {
            return Either.left(LeaveGroupMemberError.NotGroupMember.INSTANCE);
        }
        final var groupId = personageMemberGroup.groupId().get();
        return Either.right(leave(personageId, groupId));
    }

    private ConfirmLeaveGroupMemberResult leave(PersonageId personageId, GroupId groupId) {
        groupTaxService.applyLeave(groupId, personageId);
        groupPersonageStorage.clearMemberGroup(personageId, TimeUtils.moscowTime());
        final var memberCount = groupStorage.memberCount(groupId);
        if (memberCount == 0) {
            groupStorage.deleteTag(groupId);
            return new ConfirmLeaveGroupMemberResult(
                ConfirmLeaveGroupMemberResult.LeaveType.LAST_MEMBER,
                config.personageJoinGroupTimeout(),
                groupId
            );
        } else {
            return new ConfirmLeaveGroupMemberResult(
                ConfirmLeaveGroupMemberResult.LeaveType.NOT_LAST_MEMBER,
                config.personageJoinGroupTimeout(),
                groupId
            );
        }
    }
}
