package ru.homyakin.seeker.game.battle;

import ru.homyakin.seeker.game.item.models.AttackType;
import ru.homyakin.seeker.game.item.models.DefenseType;
import ru.homyakin.seeker.game.item.models.Item;
import ru.homyakin.seeker.game.item.models.ItemAttack;
import ru.homyakin.seeker.game.item.models.ItemDefense;
import ru.homyakin.seeker.game.item.models.ItemObject;
import ru.homyakin.seeker.game.item.models.ItemRarity;
import ru.homyakin.seeker.game.item.models.ImpactStrength;
import ru.homyakin.seeker.game.item.models.Modifier;
import ru.homyakin.seeker.game.event.world_raid.entity.WorldRaidPersonage;
import ru.homyakin.seeker.game.personage.models.Characteristics;
import ru.homyakin.seeker.game.personage.models.PersonageSlot;
import ru.homyakin.seeker.game.personage.power.PowerDisplaySnapshot;
import ru.homyakin.seeker.game.personage.models.effect.PersonageEffects;
import ru.homyakin.seeker.utils.TimeUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import java.util.function.Supplier;

import ru.homyakin.seeker.game.battle.effect.PeriodicDamageEffect;
import ru.homyakin.seeker.game.battle.effect.PersonageBattleEffects;
import ru.homyakin.seeker.game.battle.effect.TemporaryMaxRangeBonus;
import ru.homyakin.seeker.game.battle.skill.AttackPowerSkill;
import ru.homyakin.seeker.game.battle.skill.ActiveSkill;
import ru.homyakin.seeker.game.battle.skill.DamageDealSkill;
import ru.homyakin.seeker.game.battle.skill.HealthPowerSkill;
import ru.homyakin.seeker.game.battle.skill.ItemSkill;
import ru.homyakin.seeker.game.battle.skill.SkillPowerInputs;
import ru.homyakin.seeker.game.battle.skill.TurnSkill;
import ru.homyakin.seeker.game.battle.skill.active_impl.ActiveEnum;
import ru.homyakin.seeker.game.battle.skill.active_impl.SkillMapper;
import ru.homyakin.seeker.game.battle.skill.scaling.AttackAccess;
import ru.homyakin.seeker.game.battle.skill.scaling.NonNegativeRational;
import ru.homyakin.seeker.game.battle.skill.scaling.ScalingSkillBook;
import ru.homyakin.seeker.game.battle.skill.scaling.ScalingSkillMath;
import ru.homyakin.seeker.game.battle.skill.scaling.SkillFormulaVersion;
import ru.homyakin.seeker.game.battle.targeting.TargetingMath;
import ru.homyakin.seeker.game.battle.targeting.TargetingTactic;
import ru.homyakin.seeker.utils.MathUtils;
import ru.homyakin.seeker.utils.ProbabilityPicker;
import ru.homyakin.seeker.utils.RandomUtils;

public class BattlePersonage {
    private static final int THREAT_FROM_DAMAGE = 5;
    private static final int THREAT_LOSE_FROM_DAMAGE = 8;
    private static final int THREAT_FROM_KILL = THREAT_FROM_DAMAGE * 10;
    private static final int RANGE_PERCENT = 10;

    /**
     * Effective defense weight for {@code defenseType} against {@code attackType} (see {@link #refreshDefenseReduce()}).
     * Package-private for tests in this package.
     */
    static double damageMitigationMultiplier(DefenseType defenseType, AttackType attackType) {
        return CombatRules.defenseWeight(defenseType, attackType);
    }

    /**
     * Defense effectiveness against attack type as percent (100 = baseline).
     */
    public static int damageMitigationPercent(DefenseType defenseType, AttackType attackType) {
        return (int) Math.round(damageMitigationMultiplier(defenseType, attackType) * 100);
    }

    private final UUID id = RandomUtils.randomUuid();
    private final Optional<String> name;
    private final Optional<PowerDisplaySnapshot> displayedPower;
    private final int maxHealth;
    private final int legacyPowerMaxHealth;
    private final int legacyPowerSlotOneAttackSum;
    private final int impactStrength;
    private int health;
    private final Set<AttackType> attackTypes = EnumSet.noneOf(AttackType.class);
    private final List<ItemSkill> itemSkills = new ArrayList<>();
    private final Map<ActiveEnum, ActiveSkill> legacySkillsByCode = new EnumMap<>(ActiveEnum.class);
    private final ScalingSkillBook scalingSkills;
    private final Map<UUID, ScalingBleedingEffect> scalingBleedings = new TreeMap<>();
    private final List<ItemAttack> scalingBaseAttackParts;
    private final List<Integer> legacyAttackPercentChanges = new ArrayList<>();
    private final Optional<AttackType> primaryAttackType;
    private double preBattleAttackScale = 1.0;
    private final List<BattleItemInitSnapshot> itemSnapshots;
    private final List<BattleSkillInitSnapshot> skillSnapshots;
    private final Map<AttackType, Integer>[] rangeAttack;
    private final Map<AttackType, Integer>[] rangeAttackCrit;
    private final Map<DefenseType, Integer> defense;
    private final Map<AttackType, Double> defenseReduce;
    private final List<TurnSkill.TurnStartSkill> turnStartSkills = new ArrayList<>();
    private final List<TurnSkill.TurnEndSkill> turnEndSkills = new ArrayList<>();
    private final List<DamageDealSkill.OnHitSkill> onHitSkills = new ArrayList<>();
    private final List<DamageDealSkill.OnCritSkill> onCritSkills = new ArrayList<>();
    private final List<DamageDealSkill.OnMissSkill> onMissSkills = new ArrayList<>();
    private final List<DamageDealSkill.OnDamageReceiveSkill> onDamageReceiveSkills = new ArrayList<>();
    private final List<DamageDealSkill.OnCritReceiveSkill> onCritReceiveSkills = new ArrayList<>();
    private final List<DamageDealSkill.OnDodgeSkill> onDodgeSkills = new ArrayList<>();
    private final int critChance;
    private final int dodgeChance;
    private final double critMultiplier;
    private final int speed;
    private final int baseThreat;
    private final boolean scalingCombatRules;
    private int bonusThreat = 0;
    private boolean suppressAutomaticThreatLoss;
    private int cumulativeSpeed;
    private boolean readyToAct;
    private final Position startPosition;
    private int currentPosition = -1;
    private BattleAdvanceDirection advanceDirection;
    private final int baseMaxRange;
    private final PersonageBattleEffects combatEffects = new PersonageBattleEffects();
    private TargetingTactic targetingTactic = TargetingTactic.THREAT;

    private long normalDamageDealt;
    private long normalAttackCount;
    private long critDamageDealt;
    private long critsCount;
    private long skillDamageDealt;
    private long skillDamageCount;
    private long damageBlocked;
    private long actualDamageTaken;
    private long blockCount;
    private long damageDodged;
    private long dodgesCount;
    private long missesCount;
    private int turnsCount;

    public BattlePersonage(List<Item> items, Position startPosition) {
        this(items, startPosition, Map.of());
    }

    public BattlePersonage(List<Item> items, Position startPosition, Optional<String> name) {
        this(items, startPosition, Map.of(), PersonageEffects.EMPTY, null, name);
    }

    public static BattlePersonage forCombat(List<Item> items, Position startPosition, PersonageEffects effects) {
        return forCombat(items, startPosition, effects, Optional.empty());
    }

    public static BattlePersonage forCombat(
        List<Item> items,
        Position startPosition,
        PersonageEffects effects,
        Optional<String> name
    ) {
        return new BattlePersonage(items, startPosition, Map.of(), effects, TimeUtils.moscowTime(), name);
    }

    public static BattlePersonage forCombat(
        List<Item> items,
        Position startPosition,
        PersonageEffects effects,
        Optional<String> name,
        SkillFormulaVersion formulaVersion
    ) {
        if (formulaVersion == null) {
            throw new IllegalArgumentException("Player combat formula version must be specified");
        }
        return new BattlePersonage(
            items,
            startPosition,
            Map.of(),
            effects,
            TimeUtils.moscowTime(),
            name,
            formulaVersion,
            Map.of(),
            formulaVersion == SkillFormulaVersion.SCALING_SKILLS_V2,
            formulaVersion == SkillFormulaVersion.SCALING_SKILLS_V2
                ? PowerDisplaySnapshot.forEquipment(items)
                : Optional.empty()
        );
    }

    public BattlePersonage(WorldRaidPersonage personage, Position startPosition) {
        this(
            itemsFromWorldRaidPersonage(personage),
            startPosition,
            skillPointsFromWorldRaidPersonage(personage),
            PersonageEffects.EMPTY,
            null,
            Optional.empty(),
            SkillFormulaVersion.LEGACY_SKILLS_V1,
            skillVersionsFromWorldRaidPersonage(personage)
        );
    }

    public BattlePersonage(List<Item> items, Position startPosition, Map<ActiveEnum, Integer> skillPointsByActive) {
        this(items, startPosition, skillPointsByActive, PersonageEffects.EMPTY, null);
    }

    public BattlePersonage(
        List<Item> items,
        Position startPosition,
        Map<ActiveEnum, Integer> skillPointsByActive,
        SkillFormulaVersion formulaVersion
    ) {
        this(items, startPosition, skillPointsByActive, PersonageEffects.EMPTY, null, Optional.empty(), formulaVersion);
    }

    public static BattlePersonage forScalingSkills(
        List<Item> items,
        Position startPosition,
        Map<ActiveEnum, Integer> skillPointsByActive
    ) {
        return new BattlePersonage(
            items,
            startPosition,
            skillPointsByActive,
            PersonageEffects.EMPTY,
            null,
            Optional.empty(),
            SkillFormulaVersion.SCALING_SKILLS_V1,
            Map.of()
        );
    }

    public static BattlePersonage forScalingSkills(
        List<Item> items,
        Position startPosition,
        Map<ActiveEnum, Integer> skillPointsByActive,
        SkillFormulaVersion formulaVersion
    ) {
        if (formulaVersion != SkillFormulaVersion.SCALING_SKILLS_V1
            && formulaVersion != SkillFormulaVersion.SCALING_SKILLS_V2) {
            throw new IllegalArgumentException("A scaling formula version is required");
        }
        return new BattlePersonage(
            items,
            startPosition,
            skillPointsByActive,
            PersonageEffects.EMPTY,
            null,
            Optional.empty(),
            formulaVersion,
            Map.of()
        );
    }

    /**
     * Creates a battle participant that must use the second scaling combat rules even when no scaling skill is active.
     */
    public static BattlePersonage forScalingSkillsV2Combat(
        List<Item> items,
        Position startPosition,
        Map<ActiveEnum, Integer> skillPointsByActive,
        Optional<String> name
    ) {
        return new BattlePersonage(
            items,
            startPosition,
            skillPointsByActive,
            PersonageEffects.EMPTY,
            null,
            name,
            SkillFormulaVersion.SCALING_SKILLS_V2,
            Map.of(),
            true
        );
    }

    public static BattlePersonage withSkillVersions(
        List<Item> items,
        Position startPosition,
        Map<ActiveEnum, Integer> skillPointsByActive,
        Map<ActiveEnum, SkillFormulaVersion> versions
    ) {
        return new BattlePersonage(
            items,
            startPosition,
            skillPointsByActive,
            PersonageEffects.EMPTY,
            null,
            Optional.empty(),
            SkillFormulaVersion.LEGACY_SKILLS_V1,
            versions
        );
    }

    public BattlePersonage(
        List<Item> items,
        Position startPosition,
        Map<ActiveEnum, Integer> skillPointsByActive,
        PersonageEffects effects,
        LocalDateTime now
    ) {
        this(items, startPosition, skillPointsByActive, effects, now, Optional.empty());
    }

    public BattlePersonage(
        List<Item> items,
        Position startPosition,
        Map<ActiveEnum, Integer> skillPointsByActive,
        PersonageEffects effects,
        LocalDateTime now,
        Optional<String> name
    ) {
        this(
            items,
            startPosition,
            skillPointsByActive,
            effects,
            now,
            name,
            SkillFormulaVersion.LEGACY_SKILLS_V1,
            Map.of()
        );
    }

    public BattlePersonage(
        List<Item> items,
        Position startPosition,
        Map<ActiveEnum, Integer> skillPointsByActive,
        PersonageEffects effects,
        LocalDateTime now,
        Optional<String> name,
        SkillFormulaVersion formulaVersion
    ) {
        this(items, startPosition, skillPointsByActive, effects, now, name, formulaVersion, Map.of());
    }

    private BattlePersonage(
        List<Item> items,
        Position startPosition,
        Map<ActiveEnum, Integer> skillPointsByActive,
        PersonageEffects effects,
        LocalDateTime now,
        Optional<String> name,
        SkillFormulaVersion defaultFormulaVersion,
        Map<ActiveEnum, SkillFormulaVersion> skillVersions
    ) {
        this(
            items,
            startPosition,
            skillPointsByActive,
            effects,
            now,
            name,
            defaultFormulaVersion,
            skillVersions,
            false
        );
    }

    private BattlePersonage(
        List<Item> items,
        Position startPosition,
        Map<ActiveEnum, Integer> skillPointsByActive,
        PersonageEffects effects,
        LocalDateTime now,
        Optional<String> name,
        SkillFormulaVersion defaultFormulaVersion,
        Map<ActiveEnum, SkillFormulaVersion> skillVersions,
        boolean forceScalingCombatRules
    ) {
        this(
            items,
            startPosition,
            skillPointsByActive,
            effects,
            now,
            name,
            defaultFormulaVersion,
            skillVersions,
            forceScalingCombatRules,
            Optional.empty()
        );
    }

    private BattlePersonage(
        List<Item> items,
        Position startPosition,
        Map<ActiveEnum, Integer> skillPointsByActive,
        PersonageEffects effects,
        LocalDateTime now,
        Optional<String> name,
        SkillFormulaVersion defaultFormulaVersion,
        Map<ActiveEnum, SkillFormulaVersion> skillVersions,
        boolean forceScalingCombatRules,
        Optional<PowerDisplaySnapshot> displayedPower
    ) {
        this.name = name;
        this.displayedPower = displayedPower;
        this.defense = new EnumMap<>(DefenseType.class);
        var maxRange = 1;
        var activeSkills = new EnumMap<ActiveEnum, Integer>(ActiveEnum.class);
        var totalCritChance = 0;
        var totalDodgeChance = 0;
        var totalCritMultiplier = CombatRules.BASE_CRIT_MULTIPLIER;
        var totalSpeed = 0;
        var totalBaseThreat = 0;
        final var builtItemSnapshots = new ArrayList<BattleItemInitSnapshot>();
        final var builtAttackParts = new ArrayList<ItemAttack>();
        for (final var item : items) {
            totalCritChance += item.critChance();
            totalDodgeChance += item.dodgeChance();
            totalCritMultiplier += item.critMultiplier();
            totalSpeed += item.speed();
            totalBaseThreat += item.baseThreat();
            for (final var attack : item.itemAttacks()) {
                maxRange = Math.max(maxRange, attack.maxRange());
                builtAttackParts.add(attack);
            }
            if (item.modifier().isPresent() && item.rarity() != ItemRarity.COMMON) {
                activeSkills.merge(item.modifier().get().activeEnum(), item.skillPoints(), Integer::sum);
            }
            if (shouldSnapshotItem(item)) {
                builtItemSnapshots.add(new BattleItemInitSnapshot(
                    item.object().code(),
                    item.rarity(),
                    item.modifier().map(Modifier::activeEnum)
                ));
            }
        }
        this.scalingBaseAttackParts = List.copyOf(builtAttackParts);
        this.primaryAttackType = calculatePrimaryAttackType(scalingBaseAttackParts);
        this.itemSnapshots = List.copyOf(builtItemSnapshots);
        for (final var entry : skillPointsByActive.entrySet()) {
            activeSkills.put(entry.getKey(), activeSkills.getOrDefault(entry.getKey(), 0) + entry.getValue());
        }
        this.critMultiplier = totalCritMultiplier;
        final var builtSkillSnapshots = new ArrayList<BattleSkillInitSnapshot>();
        final var scalingSkillPoints = new EnumMap<ActiveEnum, Integer>(ActiveEnum.class);
        final var scalingSkillVersions = new EnumMap<ActiveEnum, SkillFormulaVersion>(ActiveEnum.class);
        for (final var entry : activeSkills.entrySet()) {
            if (entry.getValue() > 0) {
                final var formulaVersion = skillVersions.getOrDefault(
                    entry.getKey(),
                    defaultFormulaVersion == null
                        ? SkillFormulaVersion.LEGACY_SKILLS_V1
                        : defaultFormulaVersion
                );
                if (formulaVersion == SkillFormulaVersion.SCALING_SKILLS_V1
                    || formulaVersion == SkillFormulaVersion.SCALING_SKILLS_V2) {
                    scalingSkillPoints.put(entry.getKey(), entry.getValue());
                    scalingSkillVersions.put(entry.getKey(), formulaVersion);
                } else {
                    final var skill = SkillMapper.map(entry.getKey(), entry.getValue());
                    itemSkills.add(skill);
                    legacySkillsByCode.put(entry.getKey(), skill);
                }
                builtSkillSnapshots.add(new BattleSkillInitSnapshot(entry.getKey(), entry.getValue(), formulaVersion));
            }
        }
        this.scalingSkills = new ScalingSkillBook(scalingSkillPoints, scalingSkillVersions);
        this.scalingCombatRules = forceScalingCombatRules || !scalingSkillPoints.isEmpty();
        this.skillSnapshots = List.copyOf(builtSkillSnapshots);
        for (final var skill : itemSkills) {
            switch (skill) {
                case TurnSkill.TurnStartSkill turnStartSkill -> turnStartSkills.add(turnStartSkill);
                case TurnSkill.TurnEndSkill turnEndSkill -> turnEndSkills.add(turnEndSkill);
                case DamageDealSkill.OnHitSkill onHitSkill -> onHitSkills.add(onHitSkill);
                case DamageDealSkill.OnCritSkill onCritSkill -> onCritSkills.add(onCritSkill);
                case DamageDealSkill.OnMissSkill onMissSkill -> onMissSkills.add(onMissSkill);
                case DamageDealSkill.OnDamageReceiveSkill onDamageReceiveSkill ->
                    onDamageReceiveSkills.add(onDamageReceiveSkill);
                case DamageDealSkill.OnCritReceiveSkill onCritReceiveSkill ->
                    onCritReceiveSkills.add(onCritReceiveSkill);
                case DamageDealSkill.OnDodgeSkill onDodgeSkill -> onDodgeSkills.add(onDodgeSkill);
            }
        }

        this.rangeAttack = newRangeAttackSlotMaps(maxRange);
        for (final var item : items) {
            for (final var attack : item.itemAttacks()) {
                attackTypes.add(attack.attackType());
                for (int i = attack.minRange(); i <= attack.maxRange(); i++) {
                    rangeAttack[i].merge(
                        attack.attackType(),
                        attack.attack(),
                        Integer::sum
                    );
                }
            }
            if (item.itemDefense().isPresent()) {
                defense.merge(
                    item.itemDefense().get().defenseType(),
                    item.itemDefense().get().defense(),
                    Integer::sum
                );
            }
            this.health += item.health();
        }
        this.rangeAttackCrit = newRangeAttackSlotMaps(maxRange);
        for (int i = 1; i <= maxRange; i++) {
            for (var entry : rangeAttack[i].entrySet()) {
                rangeAttackCrit[i].put(entry.getKey(), (int) (entry.getValue() * this.critMultiplier));
            }
        }
        this.defenseReduce = new EnumMap<>(AttackType.class);
        refreshDefenseReduce();
        this.critChance = totalCritChance;
        this.dodgeChance = totalDodgeChance;
        this.speed = totalSpeed;
        this.baseThreat = totalBaseThreat;
        this.impactStrength = ImpactStrength.fromItems(items);
        this.startPosition = startPosition;
        this.baseMaxRange = maxRange;
        this.cumulativeSpeed = RandomUtils.getInInterval(0, CombatRules.INITIATIVE_THRESHOLD / 2);
        this.legacyPowerMaxHealth = this.health;
        this.legacyPowerSlotOneAttackSum = slotOneAttackSum();
        if (now != null && !effects.isEmpty()) {
            applyPersonageEffects(items, effects.activeAt(now));
        }
        this.maxHealth = this.health;
    }

    int slotOneAttackSum() {
        return rangeAttack[1].values().stream().mapToInt(Integer::intValue).sum();
    }

    private static boolean shouldSnapshotItem(Item item) {
        return item.object().code() != null;
    }

    private void applyPersonageEffects(List<Item> items, PersonageEffects effects) {
        if (effects.isEmpty()) {
            return;
        }
        final var baseCharacteristics = items.stream()
            .map(Item::visibleCharacteristics)
            .collect(Characteristics::empty, Characteristics::add, Characteristics::add);
        final var modifiedCharacteristics = baseCharacteristics.apply(effects);
        health = modifiedCharacteristics.health();
        final var baseAttack = baseCharacteristics.attack();
        if (baseAttack > 0) {
            rescaleRangeAttack((double) modifiedCharacteristics.attack() / baseAttack);
        }
    }

    private void rescaleRangeAttack(double factor) {
        preBattleAttackScale *= factor;
        for (int i = 1; i < rangeAttack.length; i++) {
            for (final var entry : new HashMap<>(rangeAttack[i]).entrySet()) {
                rangeAttack[i].put(entry.getKey(), Math.max(0, (int) (entry.getValue() * factor)));
            }
            rangeAttackCrit[i].clear();
            for (final var entry : rangeAttack[i].entrySet()) {
                rangeAttackCrit[i].put(entry.getKey(), (int) (entry.getValue() * critMultiplier));
            }
        }
    }

    private static List<Item> itemsFromWorldRaidPersonage(WorldRaidPersonage personage) {
        final var items = new ArrayList<Item>();
        items.add(new Item(
            new ItemObject(
                "world_raid_personage",
                Set.of(PersonageSlot.MAIN_HAND),
                java.util.Optional.empty(),
                java.util.Optional.empty(),
                personage.health(),
                personage.critChance(),
                personage.dodgeChance(),
                personage.critMultiplier(),
                personage.speed(),
                personage.baseThreat(),
                Map.of()
            ),
            java.util.Optional.empty(),
            ItemRarity.COMMON
        ));
        for (final var attack : personage.attacksOrEmpty()) {
            items.add(new Item(
                new ItemObject(
                    "world_raid_attack",
                    Set.of(PersonageSlot.MAIN_HAND),
                    java.util.Optional.of(new ItemAttack(attack.attackType(), attack.range(), attack.attack())),
                    java.util.Optional.empty(),
                    0,
                    0,
                    0,
                    0.0,
                    0,
                    0,
                    Map.of()
                ),
                java.util.Optional.empty(),
                ItemRarity.COMMON
            ));
        }
        for (final var defense : personage.defensesOrEmpty()) {
            items.add(new Item(
                new ItemObject(
                    "world_raid_defense",
                    Set.of(PersonageSlot.BODY),
                    java.util.Optional.empty(),
                    java.util.Optional.of(new ItemDefense(defense.defenseType(), defense.defense())),
                    0,
                    0,
                    0,
                    0.0,
                    0,
                    0,
                    Map.of()
                ),
                java.util.Optional.empty(),
                ItemRarity.COMMON
            ));
        }
        return items;
    }

    private static Map<ActiveEnum, Integer> skillPointsFromWorldRaidPersonage(WorldRaidPersonage personage) {
        final var points = new HashMap<ActiveEnum, Integer>();
        for (final var skill : personage.skillsOrEmpty()) {
            points.put(skill.activeEnum(), points.getOrDefault(skill.activeEnum(), 0) + skill.rank().requiredPoints());
        }
        return points;
    }

    private static Map<ActiveEnum, SkillFormulaVersion> skillVersionsFromWorldRaidPersonage(
        WorldRaidPersonage personage
    ) {
        final var versions = new EnumMap<ActiveEnum, SkillFormulaVersion>(ActiveEnum.class);
        for (final var skill : personage.skillsOrEmpty()) {
            final var previous = versions.putIfAbsent(skill.activeEnum(), skill.version());
            if (previous != null && previous != skill.version()) {
                throw new IllegalArgumentException(
                    "Conflicting formula versions for skill " + skill.activeEnum()
                );
            }
        }
        return versions;
    }

    @SuppressWarnings("unchecked")
    private static Map<AttackType, Integer>[] newRangeAttackSlotMaps(int maxSlot) {
        final Map<AttackType, Integer>[] maps = new Map[maxSlot + 1];
        for (int i = 1; i <= maxSlot; i++) {
            maps[i] = new EnumMap<>(AttackType.class);
        }
        return maps;
    }

    /**
     * @return true if damage was applied (not dodged)
     */
    public boolean receiveDamageFrom(BattlePersonage attacker, DamageRoll roll, BattleActionLog log, int round, BattleContext context) {
        if (RandomUtils.processChance(dodgeChance)) {
            dodgesCount++;
            damageDodged += roll.amount();
            attacker.recordMiss();
            log.add(new BattleEvent.AttackDodged(attacker.id(), id, round));
            log.addAll(applyOnDodgeSkills(context, attacker, round));
            if (attacker.isAlive()) {
                log.addAll(attacker.applyOnMissSkills(context, this, round));
            }
            return false;
        }
        int mitigated = 0;
        for (var entry : roll.attack().entrySet()) {
            mitigated += (int) (entry.getValue() * defenseReduce.get(entry.getKey()));
        }
        final int damageTaken = takeDamage(roll.amount(), mitigated);
        attacker.recordDamageDealt(damageTaken, roll.crit());
        log.add(new BattleEvent.DamageReceived(id, attacker.id(), roll, damageTaken, health, round));
        if (isAlive()) {
            log.addAll(applyOnDamageReceiveSkills(context, attacker, round));
            if (roll.crit() && attacker.isAlive()) {
                log.addAll(applyOnCritReceiveSkills(context, attacker, round));
            }
        }
        if (attacker.isAlive()) {
            log.addAll(attacker.applyOnHitSkills(context, this, round));
            if (roll.crit() && isAlive()) {
                log.addAll(attacker.applyOnCritSkills(context, this, round));
            }
        }
        return true;
    }

    /**
     * Skill-triggered damage: no dodge, mitigation + variance applied, emits {@link BattleEvent.SkillDamage}.
     * Death is NOT logged here — callers are responsible for detecting and logging {@link BattleEvent.PersonageDefeated}.
     */
    public List<BattleEvent> applySkillDamage(AttackType type, int rawAttack, BattlePersonage attacker, ActiveEnum skill, int round) {
        if (!isAlive()) {
            return List.of();
        }
        final int damageTaken = takeDamage(rawAttack, (int) (rawAttack * defenseReduce.get(type)));
        attacker.recordSkillDamageDealt(damageTaken);
        return List.of(new BattleEvent.SkillDamage(id, attacker.id(), skill, type, damageTaken, health, round));
    }

    /**
     * Environmental / timed damage: no dodge, same mitigation variance as normal hits.
     */
    public void applyEffectDamage(AttackType type, int rawAttack, UUID sourceId, ActiveEnum skill, BattleActionLog log, int round) {
        final boolean wasAlive = isAlive();
        applyEffectDamageWithoutDefeatEvent(type, rawAttack, sourceId, skill, log, round);
        if (wasAlive && !isAlive()) {
            log.add(new BattleEvent.PersonageDefeated(id, sourceId, round));
        }
    }

    /**
     * Common-turn variant that lets the caller place threat changes before the defeat event.
     *
     * @return actual damage taken
     */
    public int applyEffectDamageWithoutDefeatEvent(
        AttackType type,
        int rawAttack,
        UUID sourceId,
        ActiveEnum skill,
        BattleActionLog log,
        int round
    ) {
        if (!isAlive()) {
            return 0;
        }
        final int damageTaken = takeDamage(rawAttack, (int) (rawAttack * defenseReduce.get(type)));
        log.add(new BattleEvent.EffectDamage(id, sourceId, skill, type, damageTaken, health, round));
        return damageTaken;
    }

    /**
     * Core stat-tracking and health-reduction step shared by all damage paths.
     * {@code rawAmount} is the pre-mitigation value used only for blocked-damage stats;
     * {@code mitigated} is the post-mitigation value that variance and health subtraction operate on.
     *
     * @return actual damage taken (post-mitigation, post-variance)
     */
    private int takeDamage(int rawAmount, int mitigated) {
        if (!suppressAutomaticThreatLoss) {
            bonusThreat = Math.max(0, bonusThreat - THREAT_LOSE_FROM_DAMAGE);
        }
        damageBlocked += rawAmount;
        blockCount++;
        final int healthBefore = health;
        final int withVariance = RandomUtils.getInPercentRange(mitigated, RANGE_PERCENT);
        this.health = Math.max(0, health - withVariance);
        final int damageTaken = healthBefore - health;
        actualDamageTaken += damageTaken;
        return damageTaken;
    }

    public Set<AttackType> attackTypes() {
        return attackTypes;
    }

    public boolean isAlive() {
        return health > 0;
    }

    public void heal(int amount) {
        if (!isAlive() || amount <= 0) {
            return;
        }
        this.health = (int) Math.min(maxHealth, (long) health + amount);
    }

    public boolean tick(BattleActionLog log, int round) {
        // Clear stale flag if this personage was queued last round but never moved.
        readyToAct = false;
        cumulativeSpeed += speed;
        if (cumulativeSpeed >= CombatRules.INITIATIVE_THRESHOLD) {
            cumulativeSpeed -= CombatRules.INITIATIVE_THRESHOLD;
            readyToAct = true;
            log.add(new BattleEvent.InitiativeAfterTick(id, cumulativeSpeed, true, round));
            return true;
        }
        log.add(new BattleEvent.InitiativeAfterTick(id, cumulativeSpeed, false, round));
        return false;
    }

    /**
     * @return true if the mover phase should stop (no alive enemies left)
     */
    public boolean move(BattleContext context, BattleActionLog log, int round) {
        if (context.usesScalingSkillOrder()) {
            return VersionedBattleTurn.process(this, context, log, round);
        }
        return moveLegacy(context, log, round);
    }

    private boolean moveLegacy(BattleContext context, BattleActionLog log, int round) {
        readyToAct = false;
        turnsCount++;
        combatEffects.onOwnTurnBegin(this, log, round);
        if (!isAlive()) {
            return false;
        }
        log.addAll(applyTurnStartSkills(context, round));
        if (!isAlive()) {
            return false;
        }
        final var enemyAliveTeam = context.enemyAliveTeam(this);
        // поддержка списка сразу на будущее
        final var targets = randomAlivePersonage(this, enemyAliveTeam);
        if (targets.isEmpty()) {
            stepOneLineTowardEnemy();
            log.add(new BattleEvent.MovedTowardEnemy(id, currentPosition, round));
            return enemyAliveTeam.values().stream().noneMatch(BattlePersonage::isAlive);
        }
        final var target = targets.getFirst();
        final var personage = target.personage;
        final boolean hit = personage.receiveDamageFrom(this, rollDamage(target.range), log, round, context);
        if (!personage.isAlive()) {
            log.add(new BattleEvent.PersonageDefeated(personage.id(), id, round));
            bonusThreat += THREAT_FROM_KILL;
            enemyAliveTeam.remove(personage.id());
        } else if (hit) {
            bonusThreat += THREAT_FROM_DAMAGE;
        }
        if (!isAlive()) {
            log.add(new BattleEvent.PersonageDefeated(id, personage.id(), round));
            return false;
        }
        log.addAll(applyTurnEndSkills(context, round));
        return false;
    }

    void beginVersionedMove() {
        readyToAct = false;
        turnsCount++;
    }

    void applyLegacyTimedEffects(BattleActionLog log, int round) {
        combatEffects.onOwnTurnBegin(this, log, round);
    }

    void expireLegacyRangeBonusesForVersionedTurn() {
        combatEffects.expireRangeBonusesOnOwnTurnBegin();
    }

    List<PeriodicDamageEffect> legacyPeriodicDamages() {
        return combatEffects.periodicDamages();
    }

    void removeLegacyPeriodicDamage(PeriodicDamageEffect effect) {
        combatEffects.removePeriodicDamage(effect);
    }

    <T> T withoutAutomaticThreatLoss(Supplier<T> action) {
        final boolean previous = suppressAutomaticThreatLoss;
        suppressAutomaticThreatLoss = true;
        try {
            return action.get();
        } finally {
            suppressAutomaticThreatLoss = previous;
        }
    }

    private List<Target> randomAlivePersonage(BattlePersonage attacker, Map<UUID, BattlePersonage> enemyAliveTeam) {
        if (enemyAliveTeam.isEmpty()) {
            return List.of();
        }

        boolean hasAlive = false;
        for (final var personage : enemyAliveTeam.values()) {
            if (personage.isAlive()) {
                hasAlive = true;
                break;
            }
        }
        if (!hasAlive) {
            return List.of();
        }

        final var candidates = new ArrayList<BattlePersonage>();
        for (final var personage : enemyAliveTeam.values()) {
            if (!personage.isAlive()) {
                continue;
            }
            if (!attacker.inStrikeRange(personage)) {
                continue;
            }
            candidates.add(personage);
        }
        if (candidates.isEmpty()) {
            return List.of();
        }
        final var weightMap = attacker.targetingWeights(candidates);
        final var target = new ProbabilityPicker<>(weightMap).pick(RandomUtils::getWithMax);
        return List.of(new Target(attacker.calcRange(target), target));
    }

    /**
     * Local targeting weights for the given already-filtered candidates.
     * Does not mutate target threat. Package-visible for tests.
     */
    Map<BattlePersonage, Integer> targetingWeights(List<BattlePersonage> candidates) {
        var referenceThreat = 1;
        for (final var candidate : candidates) {
            referenceThreat = Math.max(referenceThreat, candidate.totalThreat());
        }
        final var weightMap = new LinkedHashMap<BattlePersonage, Integer>();
        for (final var candidate : candidates) {
            weightMap.put(
                candidate,
                targetingTactic.localWeight(this, candidate, candidates, referenceThreat)
            );
        }
        return weightMap;
    }

    private boolean inStrikeRange(BattlePersonage target) {
        return calcRange(target) <= range();
    }

    private int calcRange(BattlePersonage target) {
        return Math.abs(currentPosition - target.currentPosition());
    }

    private void stepOneLineTowardEnemy() {
        currentPosition += advanceDirection.indexDelta();
    }

    private List<BattleEvent> applyTurnStartSkills(BattleContext context, int round) {
        return applySkills(turnStartSkills, context, round);
    }

    private List<BattleEvent> applyTurnEndSkills(BattleContext context, int round) {
        return applySkills(turnEndSkills, context, round);
    }

    private List<BattleEvent> applyOnHitSkills(BattleContext context, BattlePersonage target, int round) {
        return applySkills(onHitSkills, context, target, round);
    }

    private List<BattleEvent> applyOnCritSkills(BattleContext context, BattlePersonage target, int round) {
        return applySkills(onCritSkills, context, target, round);
    }

    private List<BattleEvent> applyOnMissSkills(BattleContext context, BattlePersonage target, int round) {
        return applySkills(onMissSkills, context, target, round);
    }

    private List<BattleEvent> applyOnDamageReceiveSkills(BattleContext context, BattlePersonage target, int round) {
        return applySkills(onDamageReceiveSkills, context, target, round);
    }

    private List<BattleEvent> applyOnCritReceiveSkills(BattleContext context, BattlePersonage target, int round) {
        return applySkills(onCritReceiveSkills, context, target, round);
    }

    private List<BattleEvent> applyOnDodgeSkills(BattleContext context, BattlePersonage target, int round) {
        return applySkills(onDodgeSkills, context, target, round);
    }

    private List<BattleEvent> applySkills(List<? extends TurnSkill> skills, BattleContext context, int round) {
        final var events = new ArrayList<BattleEvent>();
        for (final var skill : skills) {
            events.addAll(skill.apply(context, this, round));
        }
        return events;
    }

    private List<BattleEvent> applySkills(
        List<? extends DamageDealSkill> skills,
        BattleContext context,
        BattlePersonage target,
        int round
    ) {
        final var events = new ArrayList<BattleEvent>();
        for (final var skill : skills) {
            events.addAll(skill.apply(context, this, target, round));
        }
        return events;
    }

    public int percentHp() {
        return MathUtils.calcPercent(maxHealth, health);
    }

    public void increaseAttack(int percent) {
        for (int i = 1; i <= baseMaxRange; i++) {
            for (var entry : rangeAttack[i].entrySet()) {
                rangeAttack[i].put(entry.getKey(), MathUtils.addPercent(entry.getValue(), percent));
            }
            for (var entry : rangeAttack[i].entrySet()) {
                rangeAttackCrit[i].put(entry.getKey(), (int) (entry.getValue() * critMultiplier));
            }
        }
        legacyAttackPercentChanges.add(percent);
    }

    public void decreaseDefense(int percent) {
        for (var entry : defense.entrySet()) {
            entry.setValue(Math.max(0, MathUtils.removePercent(entry.getValue(), percent)));
        }
        refreshDefenseReduce();
    }

    private void refreshDefenseReduce() {
        for (AttackType attackType : AttackType.values()) {
            defenseReduce.put(attackType, CombatRules.damageTakenMultiplier(defense, attackType));
        }
    }

    public Position startPosition() {
        return startPosition;
    }

    public int currentPosition() {
        return currentPosition;
    }

    public int range() {
        return baseMaxRange + combatEffects.maxRangeBonus();
    }

    public void increaseMaxRange(int delta, int ownMovesDuration) {
        combatEffects.addTemporaryMaxRange(new TemporaryMaxRangeBonus(delta, ownMovesDuration));
    }

    public void addPeriodicDamageEffect(PeriodicDamageEffect effect) {
        combatEffects.addPeriodicDamage(effect);
    }

    public BattleAdvanceDirection advanceDirection() {
        return advanceDirection;
    }

    void placeOnBattlefield(int currentPosition, BattleAdvanceDirection advanceDirection) {
        this.currentPosition = currentPosition;
        this.advanceDirection = advanceDirection;
    }

    public UUID id() {
        return id;
    }

    public Optional<String> name() {
        return name;
    }

    public int health() {
        return health;
    }

    public int maxHealth() {
        return maxHealth;
    }

    /**
     * Health actually lost after mitigation, variance and overkill clamping.
     * This intentionally differs from the legacy {@link BattlePersonageStats#damageTaken()} metric.
     */
    public long actualDamageTaken() {
        return actualDamageTaken;
    }

    public int critChance() {
        return critChance;
    }

    public int dodgeChance() {
        return dodgeChance;
    }

    public double critMultiplier() {
        return critMultiplier;
    }

    public Map<DefenseType, Integer> defenses() {
        return Map.copyOf(defense);
    }

    public Map<AttackType, Integer> attackAtRange(int distance) {
        final int slot = Math.min(Math.max(1, distance), baseMaxRange);
        return Map.copyOf(rangeAttack[slot]);
    }

    public List<BattleRangeAttackInitSnapshot> attacksByRange() {
        final var attacks = new ArrayList<BattleRangeAttackInitSnapshot>();
        for (int i = 1; i < rangeAttack.length; i++) {
            attacks.add(new BattleRangeAttackInitSnapshot(i, Map.copyOf(rangeAttack[i])));
        }
        return List.copyOf(attacks);
    }

    public Map<AttackType, Double> defenseReductions() {
        return Map.copyOf(defenseReduce);
    }

    public List<BattleItemInitSnapshot> itemSnapshots() {
        return itemSnapshots;
    }

    public List<BattleSkillInitSnapshot> skillSnapshots() {
        return skillSnapshots;
    }

    public int initiative() {
        return speed;
    }

    /**
     * Current initiative / turn gauge value (accumulates each tick until a turn is granted, then wraps).
     */
    public int initiativeGauge() {
        return cumulativeSpeed;
    }

    /**
     * Expected ticks until this personage's next turn using the current initiative gauge.
     * Ignores {@link #readyToAct()} — callers that care about the current movers queue
     * must check that flag separately.
     */
    public double ticksUntilNextTurn() {
        return (double) (CombatRules.INITIATIVE_THRESHOLD - cumulativeSpeed) / Math.max(1, speed);
    }

    /**
     * Whether this personage is already queued to act in the current round
     * (reached initiative threshold this tick, {@link #move} not yet finished).
     */
    public boolean readyToAct() {
        return readyToAct;
    }

    /**
     * Deterministic expected damage of a normal attack against {@code target} at current distance:
     * type mitigation, crit expectation, hit chance. Excludes ±10% damage variance.
     * Crit/hit probabilities are clamped to {@code [0, 1]} to match roll mechanics
     * ({@code processChance} treats {@code >= 100} as certain).
     */
    public double expectedDamageAgainst(BattlePersonage target) {
        final int distance = Math.max(1, calcRange(target));
        final int mapSlot = Math.min(distance, baseMaxRange);
        double mitigated = 0;
        for (final var entry : rangeAttack[mapSlot].entrySet()) {
            mitigated += entry.getValue() * target.defenseReductions().get(entry.getKey());
        }
        final double critProbability = TargetingMath.clamp(critChance / 100.0, 0.0, 1.0);
        final double withCrit = mitigated * (1.0 + critProbability * (critMultiplier - 1.0));
        final double hitProbability = TargetingMath.clamp(
            1.0 - target.dodgeChance() / 100.0,
            0.0,
            1.0
        );
        return withCrit * hitProbability;
    }

    public TargetingTactic targetingTactic() {
        return targetingTactic;
    }

    public void setTargetingTactic(TargetingTactic targetingTactic) {
        this.targetingTactic = targetingTactic == null ? TargetingTactic.THREAT : targetingTactic;
    }

    /**
     * Package-visible for initiative-based targeting tests.
     */
    void setInitiativeGaugeForTest(int gauge) {
        this.cumulativeSpeed = Math.max(0, Math.min(CombatRules.INITIATIVE_THRESHOLD - 1, gauge));
    }

    public int totalThreat() {
        return baseThreat + bonusThreat;
    }

    public int impactStrength() {
        return impactStrength;
    }

    public DamageRoll rollDamage(int strikeDistance) {
        final int clampedDistance = Math.min(Math.max(1, strikeDistance), range());
        final int mapSlot = Math.min(clampedDistance, baseMaxRange);
        if (RandomUtils.processChance(critChance)) {
            return new DamageRoll(rangeAttackCrit[mapSlot], true);
        }
        return new DamageRoll(rangeAttack[mapSlot], false);
    }

    boolean usesScalingCombatRules() {
        return scalingCombatRules;
    }

    boolean hasScalingSkills() {
        return !scalingSkills.isEmpty();
    }

    ScalingSkillBook scalingSkills() {
        return scalingSkills;
    }

    boolean hasLegacySkill(ActiveEnum skill) {
        return legacySkillsByCode.containsKey(skill);
    }

    List<BattleEvent> applyLegacyDamageSkill(
        ActiveEnum skill,
        BattleContext context,
        BattlePersonage target,
        int round
    ) {
        final var mapped = legacySkillsByCode.get(skill);
        if (mapped instanceof DamageDealSkill damageDealSkill) {
            return damageDealSkill.apply(context, this, target, round);
        }
        return List.of();
    }

    List<BattleEvent> applyLegacyTurnStartSkills(BattleContext context, int round) {
        return applyTurnStartSkills(context, round);
    }

    List<BattleEvent> applyLegacyTurnStartSkill(
        ActiveEnum skill,
        BattleContext context,
        int round
    ) {
        final var mapped = legacySkillsByCode.get(skill);
        if (mapped instanceof TurnSkill.TurnStartSkill turnStartSkill) {
            return turnStartSkill.apply(context, this, round);
        }
        return List.of();
    }

    List<BattleEvent> applyLegacyTurnEndSkills(BattleContext context, int round) {
        return applyTurnEndSkills(context, round);
    }

    List<BattleEvent> applyLegacyTurnEndSkill(
        ActiveEnum skill,
        BattleContext context,
        int round
    ) {
        final var mapped = legacySkillsByCode.get(skill);
        if (mapped instanceof TurnSkill.TurnEndSkill turnEndSkill) {
            return turnEndSkill.apply(context, this, round);
        }
        return List.of();
    }

    int distanceTo(BattlePersonage target) {
        return calcRange(target);
    }

    int ordinaryMaxRange() {
        return baseMaxRange;
    }

    Map<AttackType, Integer> scalingAttackAt(int distance, AttackAccess access) {
        if (distance < 1) {
            throw new IllegalArgumentException("distance must be positive");
        }
        final var result = scalingAttackAt(scalingBaseAttackParts, distance, access);
        for (final var entry : result.entrySet()) {
            entry.setValue(Math.max(0, (int) (entry.getValue() * preBattleAttackScale)));
        }
        for (final int percent : legacyAttackPercentChanges) {
            for (final var entry : result.entrySet()) {
                entry.setValue(MathUtils.addPercent(entry.getValue(), percent));
            }
        }
        if (scalingSkills.berserkActivated()) {
            final var baseAttack = scalingAttackAt(scalingBaseAttackParts, distance, access);
            final int multiplier = ScalingSkillMath.multiplierNumerator(
                scalingSkills.points(ActiveEnum.BERSERK)
            );
            for (final var entry : baseAttack.entrySet()) {
                final int bonus = ScalingSkillMath.roundHalfUpToInt(
                    NonNegativeRational.of(entry.getValue()).multiply(
                        NonNegativeRational.of(multiplier, 80)
                    )
                );
                result.merge(entry.getKey(), bonus, Math::addExact);
            }
        }
        return Map.copyOf(result);
    }

    private static EnumMap<AttackType, Integer> scalingAttackAt(
        List<ItemAttack> parts,
        int distance,
        AttackAccess access
    ) {
        final var result = new EnumMap<AttackType, Integer>(AttackType.class);
        for (final var part : parts) {
            final boolean available = switch (access) {
                case NORMAL -> part.isAvailableAt(distance);
                case HIT_AND_RUN -> distance >= part.minRange() && distance <= part.maxRange() + 1;
                case PENETRATION -> distance >= part.minRange();
            };
            if (available) {
                result.merge(part.attackType(), part.attack(), Math::addExact);
            }
        }
        return result;
    }

    Map<AttackType, Integer> attackForVersionedAttempt(int distance, AttackAccess access) {
        if (access == AttackAccess.NORMAL && distance > baseMaxRange && distance <= range()) {
            return scalingAttackAt(baseMaxRange, AttackAccess.NORMAL);
        }
        return scalingAttackAt(distance, access);
    }

    Optional<AttackType> primaryAttackType() {
        return primaryAttackType;
    }

    private static Optional<AttackType> calculatePrimaryAttackType(List<ItemAttack> attacks) {
        final var totals = new EnumMap<AttackType, Integer>(AttackType.class);
        for (final var part : attacks) {
            totals.merge(part.attackType(), part.attack(), Math::addExact);
        }
        AttackType selected = null;
        var selectedAttack = 0;
        for (final var type : AttackType.values()) {
            final int attack = totals.getOrDefault(type, 0);
            if (attack > selectedAttack) {
                selected = type;
                selectedAttack = attack;
            }
        }
        return Optional.ofNullable(selected);
    }

    boolean exactBerserkThresholdReached() {
        return Math.multiplyExact(100L, health) <= Math.multiplyExact(30L, maxHealth);
    }

    boolean versionedDodgeSucceeds(BattleRandom random, BattlePersonage attacker) {
        return random.chance(
            "normal-dodge:" + attacker.id() + ":" + id,
            Math.max(0, Math.min(100, dodgeChance)) * 100
        );
    }

    boolean versionedCriticalSucceeds(BattleRandom random) {
        return random.chance("normal-critical:" + id, Math.max(0, Math.min(100, critChance)) * 100);
    }

    Map<AttackType, Integer> applyCriticalMultiplier(Map<AttackType, Integer> attack) {
        final var result = new EnumMap<AttackType, Integer>(AttackType.class);
        for (final var entry : attack.entrySet()) {
            result.put(entry.getKey(), (int) (entry.getValue() * critMultiplier));
        }
        return Map.copyOf(result);
    }

    void recordVersionedDodge(
        BattlePersonage attacker,
        Map<AttackType, Integer> rolledAttack,
        BattleActionLog log,
        int round
    ) {
        final int amount = rolledAttack.values().stream().mapToInt(Integer::intValue).sum();
        dodgesCount++;
        damageDodged += amount;
        attacker.recordMiss();
        log.add(new BattleEvent.AttackDodged(attacker.id(), id, round));
    }

    int applyVersionedNormalDamage(
        BattlePersonage attacker,
        Map<AttackType, Integer> rolledAttack,
        boolean critical,
        BattleRandom random,
        BattleActionLog log,
        int round
    ) {
        var mitigated = 0;
        for (final var entry : rolledAttack.entrySet()) {
            mitigated = Math.addExact(mitigated, (int) (entry.getValue() * defenseReduce.get(entry.getKey())));
        }
        final int minimum = (int) Math.round(mitigated * 0.9);
        final int maximum = (int) Math.round(mitigated * 1.1);
        final int damage = random.nextInt(
            "normal-damage:" + attacker.id() + ":" + id,
            minimum,
            maximum
        );
        final int raw = rolledAttack.values().stream().mapToInt(Integer::intValue).sum();
        final int damageTaken = applyVersionedHealthDamage(raw, damage);
        attacker.recordDamageDealt(damageTaken, critical);
        log.add(new BattleEvent.DamageReceived(
            id,
            attacker.id(),
            new DamageRoll(rolledAttack, critical),
            damageTaken,
            health,
            round
        ));
        return damageTaken;
    }

    int applyVersionedSkillDamage(int rawDamage, int damage, BattlePersonage source) {
        final int damageTaken = applyVersionedHealthDamage(rawDamage, damage);
        source.recordSkillDamageDealt(damageTaken);
        return damageTaken;
    }

    private int applyVersionedHealthDamage(int rawDamage, int damage) {
        if (!isAlive() || damage <= 0) {
            return 0;
        }
        damageBlocked += Math.max(0, rawDamage);
        blockCount++;
        final int healthBefore = health;
        health = Math.max(0, health - damage);
        final int damageTaken = healthBefore - health;
        actualDamageTaken += damageTaken;
        return damageTaken;
    }

    int healAndGetActual(int amount) {
        final int before = health;
        heal(amount);
        return health - before;
    }

    int changeBonusThreat(int delta) {
        final int before = totalThreat();
        if (delta < 0) {
            bonusThreat = Math.max(0, bonusThreat + delta);
        } else {
            bonusThreat = Math.addExact(bonusThreat, delta);
        }
        return totalThreat() - before;
    }

    int loseThreatAfterDamage(int actualDamage) {
        if (actualDamage <= 0) {
            return 0;
        }
        return changeBonusThreat(-THREAT_LOSE_FROM_DAMAGE);
    }

    int gainThreatAfterHit() {
        return changeBonusThreat(THREAT_FROM_DAMAGE);
    }

    int gainThreatAfterKill() {
        return changeBonusThreat(THREAT_FROM_KILL);
    }

    int reduceInitiativeGauge(int amount) {
        if (amount <= 0) {
            return 0;
        }
        final int removed = Math.min(amount, cumulativeSpeed);
        cumulativeSpeed -= removed;
        return removed;
    }

    void addOrReplaceScalingBleeding(ScalingBleedingEffect effect) {
        scalingBleedings.put(effect.source().id(), effect);
    }

    List<ScalingBleedingEffect> scalingBleedings() {
        return List.copyOf(scalingBleedings.values());
    }

    void removeScalingBleeding(UUID sourceId) {
        scalingBleedings.remove(sourceId);
    }

    public BattlePersonageStats battlePersonageStats() {
        return new BattlePersonageStats(
            maxHealth,
            health,
            totalAttackAtMinRange(),
            totalDefense(),
            normalDamageDealt,
            normalAttackCount,
            critDamageDealt,
            critsCount,
            damageBlocked,
            blockCount,
            damageDodged,
            dodgesCount,
            missesCount,
            turnsCount,
            skillDamageDealt,
            skillDamageCount,
            displayedPower
        );
    }

    private int totalAttackAtMinRange() {
        return rangeAttack[1].values().stream().mapToInt(Integer::intValue).sum();
    }

    private int totalDefense() {
        return defense.values().stream().mapToInt(Integer::intValue).sum();
    }

    private void recordMiss() {
        missesCount++;
    }

    private void recordDamageDealt(int amount, boolean crit) {
        if (crit) {
            critDamageDealt += amount;
            critsCount++;
        } else {
            normalDamageDealt += amount;
            normalAttackCount++;
        }
    }

    private void recordSkillDamageDealt(int amount) {
        skillDamageDealt += amount;
        skillDamageCount++;
    }

    public double legacyPower() {
        final var slotOneAttackSum = Math.max(1, legacyPowerSlotOneAttackSum);
        final var avgDamageTakenMultiplier = defenseReduce.values().stream()
            .mapToDouble(Double::doubleValue)
            .average()
            .orElse(1.0);
        final var critProbability = critChance / 100.0;
        final var effectiveDamage = Math.max(1, slotOneAttackSum * (1 + critProbability * (critMultiplier - 1)));
        final var dodgeProbability = dodgeChance / 100.0;
        final var hitChanceMultiplier = Math.max(1, 1 - dodgeProbability);

        final double expectedDamagePerTurn = effectiveDamage
            * avgDamageTakenMultiplier
            * hitChanceMultiplier;
        final var skillInputs = new SkillPowerInputs(
            dodgeChance,
            critChance,
            slotOneAttackSum,
            maxHealth,
            expectedDamagePerTurn
        );
        double offensiveDps = 0;
        double hpBonus = 0;
        for (var skill : itemSkills) {
            if (skill instanceof HealthPowerSkill) {
                hpBonus += skill.skillPowerRating(skillInputs);
            } else if (skill instanceof AttackPowerSkill) {
                offensiveDps += skill.skillPowerRating(skillInputs);
            }
        }

        final var healthFactor = Math.max(1, legacyPowerMaxHealth + hpBonus);
        final var damageFactor = Math.max(1, effectiveDamage + offensiveDps);
        final var speedFactor = Math.max(1, speed);

        return healthFactor * damageFactor / avgDamageTakenMultiplier / hitChanceMultiplier
            * ((double) speedFactor / CombatRules.INITIATIVE_THRESHOLD);
    }

    private record Target(
        int range,
        BattlePersonage personage
    ) {
    }
}
