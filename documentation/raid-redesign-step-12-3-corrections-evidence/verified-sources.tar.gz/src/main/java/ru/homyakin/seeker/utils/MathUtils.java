package ru.homyakin.seeker.utils;

import java.util.Optional;

public class MathUtils {
    public static int doubleToIntWithMinMaxValues(double d) {
        if (d > Integer.MAX_VALUE) {
            return Integer.MAX_VALUE;
        } else if (d < Integer.MIN_VALUE) {
            return Integer.MIN_VALUE;
        } else {
            return (int) d;
        }
    }

    public static double log(double base, double value) {
        return Math.log(value) / Math.log(base);
    }

    /**
     * Описывает функцию вида 1/x => MAX(multiplier / (x + offset) + max, 0)
     * @param x - переменная функции
     * @param multiplier - влияет на растянутость графика
     * @param offset - смещение графика по оси переменной
     * @param max - число к которому стремится функция
     */
    public static double calcOneDivideXFunc(double x, double multiplier, double offset, double max) {
        if (x > offset) {
            return Math.max(multiplier / (x - offset) + max, 0);
        }
        return 0;
    }

    public static Optional<Integer> multiply(int a, int b) {
        try {
            return Optional.of(Math.multiplyExact(a, b));
        } catch (ArithmeticException e) {
            return Optional.empty();
        }
    }

    public static int addPercent(int value, int percent) {
        return Math.round(value * (1 + percent / 100.0f));
    }

    public static double addPercent(double value, int percent) {
        return value * (1 + percent / 100.0);
    }

    public static int removePercent(int value, int percent) {
        return addPercent(value, -percent);
    }

    public static double removePercent(double value, int percent) {
        return addPercent(value, -percent);
    }

    public static int calcPercent(int max, int current) {
        if (current >= max) {
            return 100;
        }
        return (int) ((double) current / max * 100);
    }
}
