package ru.homyakin.seeker.game.personage;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import io.vavr.control.Either;
import ru.homyakin.seeker.common.models.GroupId;
import ru.homyakin.seeker.game.battle.BattlePersonage;
import ru.homyakin.seeker.game.battle.Position;
import ru.homyakin.seeker.game.battle.targeting.TargetingTactic;
import ru.homyakin.seeker.game.badge.action.PersonageBadgeService;
import ru.homyakin.seeker.game.event.anomaly.entity.AnomalyPersonageResult;
import ru.homyakin.seeker.game.event.launched.CurrentEvents;
import ru.homyakin.seeker.game.event.launched.LaunchedEvent;
import ru.homyakin.seeker.game.group.passive.GroupPassiveEffect;
import ru.homyakin.seeker.game.item.ItemService;
import ru.homyakin.seeker.game.event.raid.models.RaidItem;
import ru.homyakin.seeker.game.event.world_raid.entity.battle.PersonageWorldRaidBattleResult;
import ru.homyakin.seeker.game.models.Money;
import ru.homyakin.seeker.game.models.StormShards;
import ru.homyakin.seeker.game.personage.models.BattleType;
import ru.homyakin.seeker.game.personage.models.Characteristics;
import ru.homyakin.seeker.game.personage.models.Personage;
import ru.homyakin.seeker.game.personage.models.PersonageBattleResult;
import ru.homyakin.seeker.game.personage.models.PersonageId;
import ru.homyakin.seeker.game.personage.models.PersonageRaidResult;
import ru.homyakin.seeker.game.personage.models.effect.PersonageEffect;
import ru.homyakin.seeker.game.personage.models.effect.PersonageEffectType;
import ru.homyakin.seeker.game.personage.models.errors.NotEnoughEnergy;
import ru.homyakin.seeker.game.personage.models.errors.NotEnoughMoney;
import ru.homyakin.seeker.game.personage.models.errors.NotEnoughStormShards;
import ru.homyakin.seeker.game.personage.power.PowerDisplayService;
import ru.homyakin.seeker.game.utils.NameError;
import ru.homyakin.seeker.game.utils.NameValidator;
import ru.homyakin.seeker.locale.Language;
import ru.homyakin.seeker.locale.LocaleUtils;
import ru.homyakin.seeker.locale.common.CommonLocalization;
import ru.homyakin.seeker.utils.TimeUtils;
import ru.homyakin.seeker.utils.models.Success;

@Service
public class PersonageService {
    private static final Logger logger = LoggerFactory.getLogger(PersonageService.class);
    private final PersonageDao personageDao;
    private final PersonageBattleResultDao personageBattleResultDao;
    private final PersonageBadgeService personageBadgeService;
    private final ItemService itemService;
    private final PowerDisplayService powerDisplayService;

    public PersonageService(
        PersonageDao personageDao,
        PersonageBattleResultDao personageBattleResultDao,
        PersonageBadgeService personageBadgeService,
        ItemService itemService,
        PowerDisplayService powerDisplayService
    ) {
        this.personageDao = personageDao;
        this.personageBattleResultDao = personageBattleResultDao;
        this.personageBadgeService = personageBadgeService;
        this.itemService = itemService;
        this.powerDisplayService = powerDisplayService;
    }

    public Characteristics getEquippedCharacteristics(PersonageId personageId) {
        return getEquippedCharacteristicsByPersonageIds(Set.of(personageId))
            .get(personageId);
    }

    public Map<PersonageId, Characteristics> getEquippedCharacteristicsByPersonageIds(Set<PersonageId> personageIds) {
        return itemService.getEquippedCharacteristicsByPersonageIds(personageIds);
    }

    public Map<PersonageId, BattlePersonage> toBattlePersonagesById(List<Personage> personages) {
        if (personages.isEmpty()) {
            return Map.of();
        }
        final var equippedItemsByPersonageId = itemService.getEquippedItemsByPersonageIds(
            personages.stream().map(Personage::id).collect(Collectors.toSet())
        );
        return personages.stream()
            .collect(Collectors.toMap(
                Personage::id,
                personage -> {
                    final var battlePersonage = new BattlePersonage(
                        equippedItemsByPersonageId.getOrDefault(personage.id(), List.of()),
                        personage.position(),
                        Optional.of(LocaleUtils.personageNameWithBadge(personage))
                    );
                    battlePersonage.setTargetingTactic(personage.targetingTactic());
                    return battlePersonage;
                }
            ));
    }

    public List<BattlePersonage> toBattlePersonages(List<Personage> personages) {
        final var battlePersonagesById = toBattlePersonagesById(personages);
        return personages.stream()
            .map(personage -> battlePersonagesById.get(personage.id()))
            .toList();
    }

    public Map<PersonageId, Integer> displayedPowerByPersonageIds(Set<PersonageId> personageIds) {
        final var items = itemService.getEquippedItemsByPersonageIds(personageIds);
        return personageIds.stream().collect(Collectors.toMap(
            id -> id,
            id -> powerDisplayService.value(items.getOrDefault(id, List.of()))
        ));
    }

    public String shortProfile(Language language, Personage personage) {
        return CommonLocalization.shortProfile(language, personage, getEquippedCharacteristics(personage.id()));
    }

    public String fullProfile(
        Language language,
        Personage personage,
        CurrentEvents currentEvents,
        List<GroupPassiveEffect> groupPassiveEffects
    ) {
        return CommonLocalization.fullProfile(
            language,
            personage,
            currentEvents,
            groupPassiveEffects,
            getEquippedCharacteristics(personage.id()),
            Integer.toString(displayedPowerByPersonageIds(Set.of(personage.id())).get(personage.id()))
        );
    }

    public Personage createPersonage() {
        final var id = personageDao.createDefault();
        personageBadgeService.createDefaultPersonageBadge(id);
        return personageDao.getById(id)
            .orElseThrow(() -> new IllegalStateException("Personage must be present after create"));
    }

    public Either<NameError, Personage> createPersonage(String name) {
        return NameValidator.validateName(name)
            .map(personageDao::createDefault)
            .peek(personageBadgeService::createDefaultPersonageBadge)
            .map(id -> personageDao.getById(id).orElseThrow(() -> new IllegalStateException("Personage must be present after create")))
            .peekLeft(_ -> logger.warn("Can't create personage with name " + name));
    }

    public Optional<Personage> getById(PersonageId personageId) {
        return personageDao.getById(personageId)
            .map(personage ->
                personage.updateStateIfNeed(TimeUtils.moscowTime())
                    .peek(personageDao::update)
                    .getOrElse(personage)
            );
    }

    public Personage getByIdForce(PersonageId personageId) {
        return getById(personageId)
            .orElseThrow(() -> new IllegalStateException("Personage must be present with id " + personageId));
    }

    public List<Personage> getByIds(Set<PersonageId> ids) {
        final var now = TimeUtils.moscowTime();
        return personageDao.getByIds(ids)
            .stream()
            .map(personage -> personage.updateStateIfNeed(now)
                .peek(personageDao::update)
                .getOrElse(personage))
            .toList();
    }

    public List<Personage> getByIdsWithoutEnergyRegen(Set<PersonageId> ids) {
        final var now = TimeUtils.moscowTime();
        return personageDao.getByIds(ids)
            .stream()
            .map(
                personage -> personage.updateStateIfNeed(now, false)
                    .peek(personageDao::update)
                    .getOrElse(personage)
            )
            .toList();
    }

    public Personage addMoney(Personage personage, Money money) {
        final var updatedPersonage = personage.addMoney(money);
        personageDao.update(updatedPersonage);
        return updatedPersonage;
    }

    public void addMoney(PersonageId personageId, Money money) {
        addMoney(getByIdForce(personageId), money);
    }

    public void addMoneyBatch(Map<PersonageId, Money> moneyMap) {
        personageDao.addMoney(moneyMap);
    }

    public Personage addStormShards(Personage personage, StormShards stormShards) {
        personageDao.addStormShards(personage.id(), stormShards);
        return getByIdForce(personage.id());
    }

    public void addStormShards(PersonageId personageId, StormShards stormShards) {
        personageDao.addStormShards(personageId, stormShards);
    }

    public void addStormShardsBatch(Map<PersonageId, StormShards> shardsMap) {
        personageDao.addStormShards(shardsMap);
    }

    public void saveRaidResults(List<PersonageRaidResult> results, LaunchedEvent launchedEvent) {
        personageBattleResultDao.saveBatch(
            results.stream()
                .map(result -> mapToBattleResult(result, launchedEvent.id()))
                .toList()
        );
    }

    private static PersonageBattleResult mapToBattleResult(PersonageRaidResult result, long launchedEventId) {
        return new PersonageBattleResult(
            result.participant().personage().id(),
            launchedEventId,
            result.stats(),
            result.reward(),
            StormShards.ZERO,
            generatedItemId(result.generatedItem()),
            generatedContrabandId(result.generatedItem())
        );
    }

    private static Optional<Long> generatedItemId(Optional<RaidItem> generatedItem) {
        return generatedItem.flatMap(item -> switch (item) {
            case RaidItem.ItemDrop i -> Optional.of(i.item().id());
            case RaidItem.ContrabandDrop _ -> Optional.empty();
        });
    }

    private static Optional<Long> generatedContrabandId(Optional<RaidItem> generatedItem) {
        return generatedItem.flatMap(item -> switch (item) {
            case RaidItem.ContrabandDrop c -> Optional.of(c.contraband().id());
            case RaidItem.ItemDrop _ -> Optional.empty();
        });
    }

    public void saveWorldRaidResults(List<PersonageWorldRaidBattleResult> results, LaunchedEvent launchedEvent) {
        personageDao.addMoney(
            results.stream()
                .collect(
                    Collectors.toMap(
                        PersonageWorldRaidBattleResult::personageId,
                        PersonageWorldRaidBattleResult::reward
                    )
                )
        );
        final var stormShardsRewards = results.stream()
            .filter(result -> !result.stormShards().isZero())
            .collect(
                Collectors.toMap(
                    PersonageWorldRaidBattleResult::personageId,
                    PersonageWorldRaidBattleResult::stormShards
                )
            );
        if (!stormShardsRewards.isEmpty()) {
            addStormShardsBatch(stormShardsRewards);
        }
        personageBattleResultDao.saveBatch(
            results.stream()
                .map(result -> new PersonageBattleResult(
                    result.personage().id(),
                    launchedEvent.id(),
                    result.stats(),
                    result.reward(),
                    result.stormShards(),
                    generatedItemId(result.generatedItem()),
                    generatedContrabandId(result.generatedItem())
                ))
                .toList()
        );
    }

    public Optional<PersonageBattleResult> getLastRaidResult(PersonageId personageId) {
        return personageBattleResultDao.getLastByPersonage(personageId, BattleType.RAID);
    }

    public Optional<PersonageBattleResult> getLastAnomalyResult(PersonageId personageId) {
        return personageBattleResultDao.getLastByPersonage(personageId, BattleType.ANOMALY);
    }

    public Optional<PersonageBattleResult> getLastAnomalyResultInGroup(
        PersonageId personageId,
        GroupId groupId
    ) {
        return personageBattleResultDao.getLastByPersonageAndGroup(
            personageId,
            groupId,
            BattleType.ANOMALY
        );
    }

    public Optional<PersonageBattleResult> getBattleResult(PersonageId personageId, long launchedEventId) {
        return personageBattleResultDao.getByPersonageAndEvent(personageId, launchedEventId);
    }

    public void saveAnomalyResults(List<AnomalyPersonageResult> results, long launchedEventId) {
        personageBattleResultDao.saveBatch(
            results.stream()
                .map(result -> new PersonageBattleResult(
                    result.personage().id(),
                    launchedEventId,
                    result.stats(),
                    result.reward().money(),
                    result.reward().stormShards(),
                    Optional.empty(),
                    Optional.empty()
                ))
                .toList()
        );
    }

    public Either<NotEnoughMoney, Success> tryTakeMoney(PersonageId personageId, Money money) {
        final var personage = getByIdForce(personageId);
        if (personage.money().lessThan(money)) {
            return Either.left(new NotEnoughMoney(money));
        }
        addMoney(personage, money.negative());
        return Either.right(Success.INSTANCE);
    }

    public Either<NotEnoughStormShards, Success> tryTakeStormShards(PersonageId personageId, StormShards stormShards) {
        if (stormShards.value() < 0) {
            throw new IllegalArgumentException("Storm shard amount must be non-negative: " + stormShards.value());
        }
        return personageDao.trySubtractStormShards(personageId, stormShards)
            ? Either.right(Success.INSTANCE)
            : Either.left(new NotEnoughStormShards(stormShards));
    }

    public void lockForItemChange(PersonageId personageId) {
        if (!personageDao.lockForItemChange(personageId)) {
            throw new IllegalStateException("Personage not found: " + personageId.value());
        }
    }

    public Personage takeMoney(Personage personage, Money money) {
        return addMoney(personage, money.negative());
    }

    public Either<NameError, Personage> changeName(Personage personage, String name) {
        return personage.changeName(name).peek(personageDao::update);
    }

    public int countSuccessRaidsFromLastItem(PersonageId personageId) {
        return personageBattleResultDao.countSuccessRaidsFromLastItem(personageId);
    }

    public int countWorldRaidsFromLastItem(PersonageId personageId) {
        return personageBattleResultDao.countWorldRaidsFromLastItem(personageId);
    }

    public int countSuccessRaidsFromLastContraband(PersonageId personageId) {
        return personageBattleResultDao.countSuccessRaidsFromLastContraband(personageId);
    }

    /**
     * @return Either.Left если денег недостаточно, Either.Right - количество успешно списанных денег
     */
    public Either<NotEnoughMoney, Money> initChangeName(PersonageId id) {
        return getByIdForce(id).initChangeName().peek(personageDao::update).map(_ -> Personage.CHANGE_NAME_COST);
    }

    public void cancelChangeName(PersonageId id) {
        getByIdForce(id).cancelChangeName().peek(personageDao::update);
    }

    public Personage addEffect(Personage personage, PersonageEffectType type, PersonageEffect effect) {
        final var updatedPersonage = personage.addEffect(type, effect);
        personageDao.update(updatedPersonage);
        return updatedPersonage;
    }

    public Personage addEffect(PersonageId personageId, PersonageEffectType type, PersonageEffect effect) {
        return addEffect(getByIdForce(personageId), type, effect);
    }

    public Either<NotEnoughEnergy, Personage> checkPersonageEnergy(PersonageId personageId, int requiredEnergy) {
        final var personage = getByIdForce(personageId);
        if (!personage.hasEnoughEnergy(requiredEnergy)) {
            return Either.left(NotEnoughEnergy.INSTANCE);
        }
        return Either.right(personage);
    }

    public Either<NotEnoughEnergy, Personage> reduceEnergy(Personage personage, int requiredEnergy, LocalDateTime time) {
        return personage.reduceEnergy(time, requiredEnergy).peek(personageDao::update);
    }

    public boolean toggleIsHidden(PersonageId personageId) {
        return personageDao.toggleIsHidden(personageId);
    }

    public Personage setBattlePosition(PersonageId personageId, Position position) {
        final var personage = getByIdForce(personageId);
        personageDao.setBattlePosition(personageId, position);
        return personage.withPosition(position);
    }

    public Personage setTargetingTactic(PersonageId personageId, TargetingTactic targetingTactic) {
        final var personage = getByIdForce(personageId);
        personageDao.setTargetingTactic(personageId, targetingTactic);
        return personage.withTargetingTactic(targetingTactic);
    }

    public long getActivePersonagesCount(LocalDateTime start) {
        return personageDao.getActivePersonagesCount(start);
    }

    /**
     * @return Возвращает добавленную энергию
     */
    public int addEnergy(PersonageId personageId, int energy) {
        if (energy == 0) {
            return 0;
        }
        final var personage = getByIdForce(personageId);
        final var updated = personage.addEnergy(TimeUtils.moscowTime(), energy);
        personageDao.update(updated);
        return updated.energy().value() - personage.energy().value();
    }
}
