package ru.homyakin.seeker.game.event.raid.generator;

import ru.homyakin.seeker.game.battle.BattlePersonage;
import ru.homyakin.seeker.game.battle.Position;
import ru.homyakin.seeker.game.battle.skill.active_impl.ActiveEnum;
import ru.homyakin.seeker.game.battle.skill.scaling.SkillFormulaVersion;
import ru.homyakin.seeker.game.event.pve.GeneratedPveEnemies;
import ru.homyakin.seeker.game.event.pve.PveCharacteristicScaling;
import ru.homyakin.seeker.game.item.models.AttackType;
import ru.homyakin.seeker.game.item.models.DefenseType;
import ru.homyakin.seeker.game.item.models.Item;
import ru.homyakin.seeker.game.item.models.ItemAttack;
import ru.homyakin.seeker.game.item.models.ItemDefense;
import ru.homyakin.seeker.game.item.models.ItemObject;
import ru.homyakin.seeker.game.item.models.ItemRarity;
import ru.homyakin.seeker.game.item.models.Modifier;
import ru.homyakin.seeker.game.personage.models.PersonageSlot;
import ru.homyakin.seeker.game.personage.models.effect.PersonageEffects;
import ru.homyakin.seeker.utils.MathUtils;
import ru.homyakin.seeker.utils.RandomUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Zombie Horde raid: slow, heavily PLATE-armoured undead.
 * Each zombie carries a single randomly chosen BLUNT or SLASH attack —
 * the 50/50 mix in practice matches the {@code power()} formula's averaged
 * damage-reduction assumption, keeping the difficulty calibration accurate.
 * Regular zombies carry {@link ActiveEnum#THORNS}; the boss carries
 * {@link ActiveEnum#SELF_HEAL}.
 */
public class ZombieHordeGenerator implements RaidBattlePersonageGenerator {

    // --- regular zombie base stats ---
    private static final int BASE_ATTACK = 80;
    private static final int BASE_DEFENSE = 200;
    private static final int BASE_HEALTH = 500;
    private static final int BASE_CRIT_CHANCE = 3;
    private static final int BASE_DODGE_CHANCE = 2;
    private static final double BASE_CRIT_MULTI = 0.3;
    private static final int BASE_SPEED = 200;
    private static final int BASE_THREAT = 25;

    // --- boss zombie base stats ---
    private static final int BASE_BOSS_ATTACK = 180;
    private static final int BASE_BOSS_DEFENSE = 350;
    private static final int BASE_BOSS_HEALTH = 2000;
    private static final int BASE_BOSS_CRIT_CHANCE = 8;
    private static final int BASE_BOSS_DODGE_CHANCE = 3;
    private static final double BASE_BOSS_CRIT_MULTI = 0.5;
    private static final int BASE_BOSS_SPEED = 150;
    private static final int BASE_BOSS_THREAT = 50;

    /** Each extra group member forces the raid to scale up by this log factor. */
    private static final double GROUP_SCALE_COEF = 0.05;

    @Override
    public GeneratedPveEnemies generateCalibrated(
        List<BattlePersonage> personages,
        double powerBonus,
        SkillFormulaVersion formulaVersion
    ) {
        RaidBattlePersonageGenerator.validateInputs(personages, powerBonus, formulaVersion);
        final int zombieCount = personages.size();
        final double groupSizeScaling;
        if (personages.size() <= 10) {
            groupSizeScaling = 1.0 + MathUtils.log(2.2, zombieCount) * GROUP_SCALE_COEF;
        } else if (personages.size() <= 13) {
            groupSizeScaling = 1.0 + MathUtils.log(4, zombieCount) * GROUP_SCALE_COEF;
        } else {
            groupSizeScaling = 1.0 + MathUtils.log(8, zombieCount) * GROUP_SCALE_COEF;
        }
        final var targetPower = personages.stream()
            .mapToDouble(BattlePersonage::legacyPower)
            .sum() * powerBonus * groupSizeScaling;
        final var calibration = PveCharacteristicScaling.search(
            targetPower,
            PveCharacteristicScaling.maxMultiplier(
                BASE_ATTACK, BASE_DEFENSE, BASE_HEALTH,
                BASE_BOSS_ATTACK, BASE_BOSS_DEFENSE, BASE_BOSS_HEALTH
            ),
            multiplier -> totalRaidPower(zombieCount, multiplier, formulaVersion)
        );
        final var multiplier = calibration.multiplier();

        final var horde = new ArrayList<BattlePersonage>();
        horde.add(boss(multiplier, randomAttack(), formulaVersion));
        for (int i = 0; i < zombieCount; i++) {
            horde.add(zombie(multiplier, randomAttack(), formulaVersion));
        }
        return new GeneratedPveEnemies(horde, calibration);
    }

    // -------------------------------------------------------------------------
    // Unit factories
    // -------------------------------------------------------------------------

    private BattlePersonage zombie(double m, AttackType attackType, SkillFormulaVersion formulaVersion) {
        return BattlePersonage.forCombat(
            List.of(
                new Item(
                    new ItemObject(
                        null,
                        Set.of(PersonageSlot.MAIN_HAND),
                        Optional.of(new ItemAttack(attackType, 1, multiply(BASE_ATTACK, m))),
                        Optional.of(new ItemDefense(DefenseType.PLATE, multiply(BASE_DEFENSE, m))),
                        multiply(BASE_HEALTH, m),
                        BASE_CRIT_CHANCE, BASE_DODGE_CHANCE, BASE_CRIT_MULTI,
                        BASE_SPEED, BASE_THREAT, null
                    ),
                    Optional.of(new Modifier(ActiveEnum.THORNS)),
                    ItemRarity.LEGENDARY
                )
            ),
            Position.FRONT,
            PersonageEffects.EMPTY,
            Optional.empty(),
            formulaVersion
        );
    }

    private BattlePersonage boss(double m, AttackType attackType, SkillFormulaVersion formulaVersion) {
        return BattlePersonage.forCombat(
            List.of(
                new Item(
                    new ItemObject(
                        null,
                        Set.of(PersonageSlot.MAIN_HAND),
                        Optional.of(new ItemAttack(attackType, 1, multiply(BASE_BOSS_ATTACK, m))),
                        Optional.of(new ItemDefense(DefenseType.PLATE, multiply(BASE_BOSS_DEFENSE, m))),
                        multiply(BASE_BOSS_HEALTH, m),
                        BASE_BOSS_CRIT_CHANCE, BASE_BOSS_DODGE_CHANCE, BASE_BOSS_CRIT_MULTI,
                        BASE_BOSS_SPEED, BASE_BOSS_THREAT, null
                    ),
                    Optional.of(new Modifier(ActiveEnum.SELF_HEAL)),
                    ItemRarity.LEGENDARY
                )
            ),
            Position.FRONT,
            PersonageEffects.EMPTY,
            Optional.empty(),
            formulaVersion
        );
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /** Returns BLUNT or SLASH with equal probability. */
    private static AttackType randomAttack() {
        return RandomUtils.processChance(50) ? AttackType.BLUNT : AttackType.SLASH;
    }

    // -------------------------------------------------------------------------
    // Power calibration (binary search — attack type fixed to SLASH for
    // determinism; power() is independent of the unit's own attack type)
    // -------------------------------------------------------------------------

    private double totalRaidPower(int zombieCount, double m, SkillFormulaVersion formulaVersion) {
        return boss(m, AttackType.SLASH, formulaVersion).legacyPower()
            + zombie(m, AttackType.SLASH, formulaVersion).legacyPower() * zombieCount;
    }

    private int multiply(int value, double multiplier) {
        return PveCharacteristicScaling.multiply(value, multiplier);
    }
}
