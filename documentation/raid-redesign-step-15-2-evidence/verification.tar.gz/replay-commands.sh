#!/bin/zsh
# Repeats 24 seeded actual battles twice in separate JVMs; not a balance study.
set -eu
replay_source_root=/tmp/seeker-step15-2-structural.fFaIee
replay_output_root=${1:?Specify a new output directory}
if [[ -e "$replay_output_root" ]]; then
    print -u2 "Output directory already exists; choose a new one"
    exit 1
fi
mkdir -p "$replay_output_root/classes"
replay_dependencies=$(< /tmp/seeker-step15.N6LMen/classpath.txt)
cd /home/user/projects/project-seeker/game
/home/user/.jdks/axiomjdk-25.0.1/bin/javac --release 24 \
    -cp "target/classes:target/test-classes:$replay_dependencies" \
    -d "$replay_output_root/classes" "$replay_source_root/Step152ReplayProbe.java"
for replay_name in replay-a replay-b; do
    /home/user/.jdks/axiomjdk-25.0.1/bin/java -Xmx768m \
        -cp "$replay_output_root/classes:target/classes:target/test-classes:$replay_dependencies" \
        ru.homyakin.seeker.game.battle.Step152ReplayProbe "$replay_output_root/$replay_name" \
        > "$replay_output_root/$replay_name.log" 2>&1
done
/home/user/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node \
    "$replay_source_root/compare-replay.cjs" "$replay_output_root" > "$replay_output_root/replay-receipt.json"
