const fs = require('node:fs');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const path = require('node:path');
const root = process.argv[2];
assert(root);
const a = path.join(root, 'replay-a');
const b = path.join(root, 'replay-b');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const rawA = fs.readFileSync(path.join(a, 'raw-rows.jsonl'));
const rawB = fs.readFileSync(path.join(b, 'raw-rows.jsonl'));
const canonicalA = fs.readFileSync(path.join(a, 'canonical-rows.jsonl'));
const canonicalB = fs.readFileSync(path.join(b, 'canonical-rows.jsonl'));
assert(canonicalA.equals(canonicalB), 'Complete canonical replay rows differ');
const rowsA = rawA.toString().trim().split('\n').map(JSON.parse);
const rowsB = rawB.toString().trim().split('\n').map(JSON.parse);
const canonical = node => {
  if (Array.isArray(node)) return node.map(canonical);
  if (node && typeof node === 'object') return Object.fromEntries(Object.entries(node).map(([key, value]) =>
    [key, ['slots', 'availableOnSlots'].includes(key) && Array.isArray(value) ? [...value].sort() : canonical(value)]));
  return node;
};
assert.equal(rowsA.length, 24);
assert.equal(rowsB.length, 24);
assert.deepEqual(canonical(rowsA), canonical(rowsB));
const seen = new Set();
const cases = new Set();
for (const row of rowsA) {
  const key = `${row.caseId}/${row.reverse}`;
  assert(!seen.has(key)); seen.add(key); cases.add(row.caseId);
  assert.equal(row.calibrationMetric, 'NEUTRAL_TEAM_V1');
  assert.equal(row.generationDiagnostics.assessmentVersion, 'NEUTRAL_TEAM_V1');
  assert.equal(typeof row.actionSha256, 'string');
  assert.equal(typeof row.traceSha256, 'string');
  assert(row.rounds > 0 && row.rounds <= row.roundLimit);
  assert.notEqual(row.outcome, 'TIMEOUT');
}
assert.equal(cases.size, 12);
for (const id of cases) assert(seen.has(`${id}/false`) && seen.has(`${id}/true`));
const diagnosticEffects = rowsA.filter(row => row.cell.effects);
assert.equal(diagnosticEffects.length, 2);
assert(diagnosticEffects.every(row => Object.keys(row.sourceEffects).length && Object.keys(row.combatEffects).length));
console.log(JSON.stringify({
  status: 'SEPARATE_JVM_COMBAT_REPLAY_EXACT_NOT_BALANCE_ACCEPTANCE',
  conditions: 12,
  battlesInOriginalRun: 24,
  battlesInVerificationRun: 24,
  independentObservationPolicy: 'Verification repeats original seeded observations; do not count as 48 independent fights or a winrate sample',
  rawByteExact: rawA.equals(rawB),
  canonicalByteExact: true,
  semanticChangesAllowed: 'None; canonicalization orders only slots/availableOnSlots schema sets',
  rawA: hash(rawA), rawB: hash(rawB), canonical: hash(canonicalA),
  timeouts: 0,
}, null, 2));
