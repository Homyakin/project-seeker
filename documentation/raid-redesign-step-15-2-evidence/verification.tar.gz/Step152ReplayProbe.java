package ru.homyakin.seeker.game.battle;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import ru.homyakin.seeker.game.battle.PveAdaptationStudy.Cell;
import ru.homyakin.seeker.game.battle.PveAdaptationStudy.Mode;
import ru.homyakin.seeker.game.battle.Step123ReferenceTeams.Tier;
import ru.homyakin.seeker.game.event.pve.PveTeamAssessment;

/** One mirrored pair per fixed input, for separate-process repeatability only. */
public final class Step152ReplayProbe {
    private static final long GENERATION_ROOT=8_026_110_815_200L;
    private static final long BATTLE_ROOT=9_026_110_815_200L;
    private static final Set<String> SET_FIELDS=Set.of("slots","availableOnSlots");

    public static void main(String[] args)throws Exception {
        if(args.length!=1)throw new IllegalArgumentException("Specify one new output directory");
        final var output=Path.of(args[0]);Files.createDirectory(output);
        final var cells=cells();
        final var summaries=new ArrayList<Map<String,Object>>();
        try(var raw=Files.newBufferedWriter(output.resolve("raw-rows.jsonl"),StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
            var canonical=Files.newBufferedWriter(output.resolve("canonical-rows.jsonl"),StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW)) {
            int caseId=0;
            for(final var cell:cells) {
                ++caseId;
                final long generationSeed=GENERATION_ROOT+caseId*1000L;
                final long battleSeed=BATTLE_ROOT+caseId*1000L;
                final var summary=new LinkedHashMap<String,Object>();
                summary.put("caseId",caseId);summary.put("cell",cell);summary.put("generationSeed",generationSeed);summary.put("battleSeed",battleSeed);
                final var orders=new ArrayList<Map<String,Object>>();
                for(final boolean reverse:List.of(false,true)) {
                    final var row=PveAdaptationStudy.run(cell,generationSeed,battleSeed,reverse);
                    row.put("caseId",caseId);row.put("pair",0);row.put("purpose","SEPARATE_PROCESS_REPLAY_NOT_BALANCE_SAMPLE");
                    final JsonNode tree=PveAdaptationStudy.JSON.valueToTree(row);
                    if(tree.path("outcome").asText().equals("TIMEOUT")||!tree.has("actionSha256")||!tree.has("traceSha256"))
                        throw new IllegalStateException("Replay did not complete: case "+caseId);
                    if(!tree.path("generationDiagnostics").path("assessmentVersion").asText().equals(PveTeamAssessment.VERSION))
                        throw new IllegalStateException("Wrong generation metric: case "+caseId);
                    raw.write(PveAdaptationStudy.JSON.writeValueAsString(tree));raw.newLine();
                    canonicalizeSets(tree);
                    canonical.write(PveAdaptationStudy.JSON.writeValueAsString(tree));canonical.newLine();
                    orders.add(Map.of("reverse",reverse,"outcome",row.get("outcome"),"rounds",row.get("rounds"),
                        "actionSha256",row.get("actionSha256"),"traceSha256",row.get("traceSha256")));
                }
                summary.put("orders",orders);summaries.add(summary);
            }
        }
        final var manifest=new LinkedHashMap<String,Object>();
        manifest.put("purpose","SEPARATE_PROCESS_REPLAY_NOT_BALANCE_ACCEPTANCE");
        manifest.put("conditions",cells.size());manifest.put("battles",cells.size()*2);manifest.put("independentPairs",cells.size());
        manifest.put("generationRoot",GENERATION_ROOT);manifest.put("battleRoot",BATTLE_ROOT);
        manifest.put("seedPolicy","ROOT + one-based caseId * 1000; one mirrored pair per condition; each mirror reconstructs fresh participants");
        manifest.put("canonicalization","Only schema Set arrays slots and availableOnSlots are lexically ordered; no fields removed and no other arrays reordered");
        manifest.put("rawSha256",hash(output.resolve("raw-rows.jsonl")));
        manifest.put("canonicalSha256",hash(output.resolve("canonical-rows.jsonl")));
        manifest.put("cases",summaries);
        Files.writeString(output.resolve("manifest.json"),PveAdaptationStudy.JSON.writerWithDefaultPrettyPrinter()
            .writeValueAsString(manifest),StandardOpenOption.CREATE_NEW);
    }

    private static List<Cell> cells() {
        final var cells=new ArrayList<Cell>();
        for(final var tier:List.of(Tier.MID,Tier.STRONG))for(final int size:List.of(3,4))for(final int level:List.of(20,25))
            cells.add(new Cell(Mode.RAID,"MYCONID_COLONY","MAIN",tier,size,level,false));
        cells.add(new Cell(Mode.RAID,"MYCONID_COLONY","PIERCE_ARCANE",Tier.BEGINNER,1,1,false));
        cells.add(new Cell(Mode.RAID,"MYCONID_COLONY","RAPIER_ARCANE",Tier.MID,3,10,false));
        cells.add(new Cell(Mode.RAID,"MYCONID_COLONY","MAIN",Tier.MID,3,25,true));
        cells.add(new Cell(Mode.RAID,"MYCONID_COLONY","MAIN",Tier.MID,30,50,false));
        return cells;
    }

    private static void canonicalizeSets(JsonNode node) {
        if(node instanceof ObjectNode object) {
            final var replacements=new TreeMap<String,ArrayNode>();
            object.fields().forEachRemaining(field->{
                if(SET_FIELDS.contains(field.getKey())&&field.getValue() instanceof ArrayNode array) {
                    final var values=new ArrayList<JsonNode>();array.forEach(values::add);values.sort(Comparator.comparing(JsonNode::asText));
                    final var sorted=PveAdaptationStudy.JSON.createArrayNode();values.forEach(sorted::add);replacements.put(field.getKey(),sorted);
                } else canonicalizeSets(field.getValue());
            });
            replacements.forEach(object::set);
        } else if(node instanceof ArrayNode array) array.forEach(Step152ReplayProbe::canonicalizeSets);
    }

    private static String hash(Path path)throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(path)));
    }
}
