package ru.homyakin.seeker.game.battle;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.zip.GZIPInputStream;
import ru.homyakin.seeker.game.battle.skill.scaling.SkillFormulaVersion;
import ru.homyakin.seeker.game.battle.targeting.TargetingTactic;
import ru.homyakin.seeker.game.event.launched.RaidParams;
import ru.homyakin.seeker.game.event.models.EventStatus;
import ru.homyakin.seeker.game.event.pve.GeneratedPveEnemies;
import ru.homyakin.seeker.game.event.pve.PveTeamAssessment;
import ru.homyakin.seeker.game.event.raid.generator.MyconidColonyGenerator;
import ru.homyakin.seeker.game.event.raid.generator.RaidGenerator;
import ru.homyakin.seeker.game.event.raid.models.LaunchedRaidEvent;
import ru.homyakin.seeker.game.event.raid.models.RaidType;
import ru.homyakin.seeker.game.item.models.Item;
import ru.homyakin.seeker.game.personage.models.effect.PersonageEffects;
import ru.homyakin.seeker.utils.RandomUtils;

/** Read-only structural export; no battle processing, application startup or database access. */
public final class Step152StructuralProbe {
    private static final JsonMapper JSON=JsonMapper.builder().addModule(new Jdk8Module())
        .addModule(new JavaTimeModule()).enable(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS).build();
    private static final long HISTORICAL_ROOT=7_026_110_815_200L;
    public record Member(String build,Position position,TargetingTactic tactic,List<Item> items) { }

    public static void main(String[] args)throws Exception {
        if(args.length!=3)throw new IllegalArgumentException("modern|historical ARCHIVED_BOUNDED_DIRECTORY NEW_JSON_PATH");
        final var archive=Path.of(args[1]);
        final Map<String,List<Member>> inputs=JSON.readValue(Files.readString(archive.resolve("inputs.json")),
            new TypeReference<Map<String,List<Member>>>() { });
        final Object result=switch(args[0]) {
            case "modern" -> modern(archive,inputs);
            case "historical" -> historical(inputs);
            default -> throw new IllegalArgumentException("Unknown mode "+args[0]);
        };
        Files.writeString(Path.of(args[2]),JSON.writerWithDefaultPrettyPrinter().writeValueAsString(result),
            StandardOpenOption.CREATE_NEW);
    }

    private static Object modern(Path archive,Map<String,List<Member>> inputs)throws Exception {
        final var summary=JSON.readTree(Files.readString(archive.resolve("summary.json")));
        final Map<Integer,JsonNode> firstRows=new TreeMap<>();
        try(var reader=new BufferedReader(new InputStreamReader(new GZIPInputStream(Files.newInputStream(
            archive.resolve("battles.jsonl.gz"))),StandardCharsets.UTF_8))) {
            String line;
            while((line=reader.readLine())!=null) {
                final var row=JSON.readTree(line);
                if(row.path("pair").asInt()==0&&!row.path("reverse").asBoolean())firstRows.put(row.path("caseId").asInt(),row);
            }
        }
        final var rows=new ArrayList<Map<String,Object>>();
        for(final var cell:summary.path("cases")) {
            final int id=cell.path("caseId").asInt(),size=cell.path("size").asInt(),level=cell.path("level").asInt();
            final String tier=cell.path("tier").asText(),style=cell.path("style").asText();
            final var saved=firstRows.get(id);
            if(saved==null)throw new IllegalStateException("Missing saved row "+id);
            final long generationSeed=saved.path("generationSeed").asLong();
            final var members=inputs.get(style+"/"+tier+"/"+size);
            if(members==null||members.size()!=size)throw new IllegalStateException("Missing full input "+id);
            final var ps=RandomUtils.withSeed(generationSeed,()->players(members,SkillFormulaVersion.SCALING_SKILLS_V3));
            final double archivedBonus=0.54+0.06*level;
            final double runtimeBonus=1+((level-10)*0.06+0.14);
            final var direct=RandomUtils.withSeed(generationSeed+200_000_000,()->new MyconidColonyGenerator().generateCalibrated(
                ps,archivedBonus,SkillFormulaVersion.SCALING_SKILLS_V3));
            final var runtime=RandomUtils.withSeed(generationSeed+200_000_000,()->new RaidGenerator().generateCalibrated(
                RaidType.MYCONID_COLONY,event(level),ps,SkillFormulaVersion.SCALING_SKILLS_V3));
            final var savedInit=JSON.readTree(Files.readString(archive.resolve("init-case"+id+".json")));
            final var expected=archivedTraits(savedInit);
            final var actualDirect=traits(direct.enemies());
            final var actualRuntime=traits(runtime.enemies());
            final var row=new LinkedHashMap<String,Object>();
            row.put("caseId",id);row.put("tier",tier);row.put("style",style);row.put("size",size);row.put("level",level);
            row.put("generationSeed",generationSeed);row.put("archivedPowerBonus",archivedBonus);row.put("runtimePowerBonus",runtimeBonus);
            row.put("archivedPlayerQ",saved.path("playerQ"));row.put("currentPlayerQ",PveTeamAssessment.assess(ps));
            row.put("archivedCalibration",saved.path("calibration"));row.put("archivedNpcQ",saved.path("npcQ"));
            row.put("directCalibration",direct.calibration());row.put("runtimeCalibration",runtime.calibration());
            row.put("directNpcQ",PveTeamAssessment.assess(direct.enemies()));row.put("runtimeNpcQ",PveTeamAssessment.assess(runtime.enemies()));
            row.put("directDiagnostics",direct.diagnostics());row.put("runtimeDiagnostics",runtime.diagnostics());
            row.put("directCharacteristicExact",JSON.valueToTree(actualDirect).equals(JSON.valueToTree(expected)));
            row.put("runtimeCharacteristicExact",JSON.valueToTree(actualRuntime).equals(JSON.valueToTree(expected)));
            row.put("expectedTraits",expected);row.put("directTraits",actualDirect);row.put("runtimeTraits",actualRuntime);
            rows.add(row);
        }
        return Map.of("purpose","STRUCTURAL_COMPARISON_NOT_BALANCE_ACCEPTANCE","cases",rows,
            "version",PveTeamAssessment.VERSION,"compared","HP, attack profiles, defenses, mitigation, skills, speed, crit/dodge, threat, range and start position",
            "excluded","UUID and initial random initiative gauge: archived final NPC use a separate generationSeed+400000000 stream",
            "qPolicy","Record floating point deltas; no change to C and no outcome-based calibration");
    }

    private static Object historical(Map<String,List<Member>> inputs) {
        final var rows=new ArrayList<Map<String,Object>>();int id=0;
        for(final var version:List.of(SkillFormulaVersion.LEGACY_SKILLS_V1,SkillFormulaVersion.SCALING_SKILLS_V1,
            SkillFormulaVersion.SCALING_SKILLS_V2)) {
            for(final int size:List.of(1,2,3,4,7,8,15,30))for(final int level:List.of(1,25,50)) {
                final int caseId=++id;final long seed=HISTORICAL_ROOT+caseId*1000L;
                final var members=inputs.get("MAIN/MID/"+size);
                if(members==null)throw new IllegalStateException("Missing historical members N"+size);
                final var row=RandomUtils.withSeed(seed,()->{
                    final var ps=players(members,version);
                    final double bonus=1+((level-10)*0.06+0.14);
                    final double legacySum=ps.stream().mapToDouble(BattlePersonage::legacyPower).sum();
                    final var result=new MyconidColonyGenerator().generateCalibrated(ps,bonus,version);
                    final var r=new LinkedHashMap<String,Object>();
                    r.put("caseId",caseId);r.put("version",version);r.put("size",size);r.put("level",level);r.put("generationSeed",seed);
                    r.put("powerBonus",bonus);r.put("playerLegacySum",legacySum);r.put("calibration",result.calibration());
                    r.put("enemies",result.enemies().stream().map(Step152StructuralProbe::historicalState).toList());
                    return r;
                });
                rows.add(row);
            }
        }
        return Map.of("purpose","HISTORICAL_BRANCH_BIT_EXACT_EXPORT_NOT_BALANCE_ACCEPTANCE","generationRoot",HISTORICAL_ROOT,
            "cases",rows,"casePolicy","3 versions x 8 sizes x 3 levels; one identical scoped stream constructs players and NPC");
    }

    private static List<BattlePersonage> players(List<Member> members,SkillFormulaVersion version) {
        return members.stream().map(member->{
            final var p=BattlePersonage.forCombat(member.items(),member.position(),PersonageEffects.EMPTY,
                Optional.of(member.build()),version);p.setTargetingTactic(member.tactic());return p;
        }).toList();
    }

    private static List<Map<String,Object>> traits(List<BattlePersonage> enemies) {
        final var result=new ArrayList<Map<String,Object>>();
        for(final var p:enemies) {
            final var row=new LinkedHashMap<String,Object>();
            row.put("health",p.maxHealth());row.put("position",p.startPosition());row.put("range",p.range());
            row.put("skills",p.skillSnapshots());row.put("items",p.itemSnapshots());row.put("initiative",p.initiative());
            row.put("totalThreat",p.totalThreat());row.put("impactStrength",p.impactStrength());row.put("targetingTactic",p.targetingTactic());
            row.put("critChance",p.critChance());row.put("dodgeChance",p.dodgeChance());row.put("critMultiplier",p.critMultiplier());
            row.put("attacksByRange",p.attacksByRange());row.put("defenses",p.defenses());row.put("damageTakenMultipliers",p.defenseReductions());
            result.add(row);
        }
        result.sort(Comparator.comparing(row->row.get("position").toString()));return result;
    }

    private static List<Map<String,Object>> archivedTraits(JsonNode init) {
        final var rows=new ArrayList<Map<String,Object>>();
        for(final var p:init.path("personagesById")) {
            if(!p.path("firstTeam").asBoolean())continue;
            final var row=new LinkedHashMap<String,Object>();
            for(final var key:List.of("health","range","skills","items","initiative","totalThreat","impactStrength",
                "targetingTactic","critChance","dodgeChance","critMultiplier","attacksByRange","defenses","damageTakenMultipliers")) {
                row.put(key,p.path(key));
            }
            row.put("position",init.path("lines").get(p.path("lineIndex").asInt()).path("position").asText());rows.add(row);
        }
        rows.sort(Comparator.comparing(row->row.get("position").toString()));return rows;
    }

    private static Map<String,Object> historicalState(BattlePersonage p) {
        final var row=new LinkedHashMap<>(traits(List.of(p)).getFirst());
        row.put("id",p.id());row.put("initialGauge",p.initiativeGauge());row.put("stats",p.battlePersonageStats());
        row.put("legacyPower",p.legacyPower());return row;
    }

    private static LaunchedRaidEvent event(int level) {
        final var now=LocalDateTime.of(2026,11,8,0,0);
        return new LaunchedRaidEvent(152,1,now,now.plusHours(1),EventStatus.LAUNCHED,new RaidParams(level,0));
    }
}
