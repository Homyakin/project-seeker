#!/bin/zsh
# Reproduces structural exports only. No Maven, application startup, database or battle runs.
set -eu
probe_source_root=/tmp/seeker-step15-2-structural.fFaIee
probe_output_root=${1:?Specify a new output directory}
if [[ -e "$probe_output_root" ]]; then
    print -u2 "Output directory already exists; choose a new one"
    exit 1
fi
mkdir -p "$probe_output_root/classes" "$probe_output_root/baseline-classes"
probe_dependencies=$(< /tmp/seeker-step15.N6LMen/classpath.txt)
probe_java=/home/user/.jdks/axiomjdk-25.0.1/bin/java
probe_javac=/home/user/.jdks/axiomjdk-25.0.1/bin/javac
probe_archive="$probe_source_root/archive/bounded-tail-results"
cd /home/user/projects/project-seeker/game
"$probe_javac" --release 24 -cp "target/classes:target/test-classes:$probe_dependencies" \
    -d "$probe_output_root/classes" "$probe_source_root/Step152StructuralProbe.java"
"$probe_javac" --release 24 -cp "target/classes:target/test-classes:$probe_dependencies" \
    -d "$probe_output_root/baseline-classes" "$probe_source_root/baseline-source/MyconidColonyGenerator.java"
"$probe_java" -Xmx768m -cp "$probe_output_root/classes:target/classes:target/test-classes:$probe_dependencies" \
    ru.homyakin.seeker.game.battle.Step152StructuralProbe modern "$probe_archive" "$probe_output_root/modern.json" \
    > "$probe_output_root/modern.log" 2>&1
"$probe_java" -Xmx768m -cp "$probe_output_root/classes:target/classes:target/test-classes:$probe_dependencies" \
    ru.homyakin.seeker.game.battle.Step152StructuralProbe historical "$probe_archive" "$probe_output_root/historical-current.json" \
    > "$probe_output_root/historical-current.log" 2>&1
"$probe_java" -Xmx768m \
    -cp "$probe_output_root/baseline-classes:$probe_output_root/classes:target/classes:target/test-classes:$probe_dependencies" \
    ru.homyakin.seeker.game.battle.Step152StructuralProbe historical "$probe_archive" "$probe_output_root/historical-baseline.json" \
    > "$probe_output_root/historical-baseline.log" 2>&1
/home/user/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node \
    "$probe_source_root/compare.cjs" "$probe_output_root" > "$probe_output_root/comparison.json"
