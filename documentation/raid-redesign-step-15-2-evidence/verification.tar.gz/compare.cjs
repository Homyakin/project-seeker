const fs = require('node:fs');
const assert = require('node:assert/strict');
const path = require('node:path');
const root = process.argv[2];
assert(root, 'Specify structural output directory');
const historicalCurrent = JSON.parse(fs.readFileSync(path.join(root, 'historical-current.json')));
const historicalBaseline = JSON.parse(fs.readFileSync(path.join(root, 'historical-baseline.json')));
assert.deepEqual(historicalCurrent, historicalBaseline, 'Historical factory/target/random state changed');
assert.equal(historicalCurrent.cases.length, 72);
const modern = JSON.parse(fs.readFileSync(path.join(root, 'modern.json')));
assert.equal(modern.cases.length, 90);
const relative = (actual, expected) => expected === 0 ? Math.abs(actual - expected) : Math.abs(actual / expected - 1);
const rows = modern.cases.map(row => ({
  caseId: row.caseId, tier: row.tier, style: row.style, size: row.size, level: row.level,
  directCharacteristicExact: row.directCharacteristicExact,
  runtimeCharacteristicExact: row.runtimeCharacteristicExact,
  playerQRelativeDelta: relative(row.currentPlayerQ, row.archivedPlayerQ),
  directTargetRelativeDelta: relative(row.directCalibration.targetPower, row.archivedCalibration.targetPower),
  runtimeTargetRelativeDelta: relative(row.runtimeCalibration.targetPower, row.archivedCalibration.targetPower),
  directNpcQRelativeDelta: relative(row.directNpcQ, row.archivedNpcQ),
  runtimeNpcQRelativeDelta: relative(row.runtimeNpcQ, row.archivedNpcQ),
  directMultiplierDelta: row.directCalibration.multiplier - row.archivedCalibration.multiplier,
  runtimeMultiplierDelta: row.runtimeCalibration.multiplier - row.archivedCalibration.multiplier,
}));
for (const row of rows) {
  for (const [key, value] of Object.entries(row)) {
    if (key.endsWith('Delta')) assert(Number.isFinite(value), `Nonfinite ${row.caseId}/${key}`);
  }
}
const maxima = {};
for (const key of ['playerQRelativeDelta', 'directTargetRelativeDelta', 'runtimeTargetRelativeDelta',
  'directNpcQRelativeDelta', 'runtimeNpcQRelativeDelta', 'directMultiplierDelta', 'runtimeMultiplierDelta']) {
  maxima[key] = Math.max(...rows.map(row => Math.abs(row[key])));
}
console.log(JSON.stringify({
  status: 'STRUCTURAL_RESULTS_NOT_BALANCE_ACCEPTANCE',
  historicalCases: historicalCurrent.cases.length,
  historicalBitExact: true,
  modernCases: modern.cases.length,
  directCharacteristicExact: rows.filter(row => row.directCharacteristicExact).length,
  runtimeCharacteristicExact: rows.filter(row => row.runtimeCharacteristicExact).length,
  maxima,
  nonexactCases: rows.filter(row => !row.directCharacteristicExact || !row.runtimeCharacteristicExact),
  rows,
}, null, 2));
