# Structural check after step 15.2 build

Preparation only until the main agent gives GO after Maven has finished. No application, DB, battle recalibration or target edits.

`Step152StructuralProbe modern` reconstructs full archived inputs for all 90 bounded-tail conditions, uses fixed player seeds, and exports both direct Myconid generation with the archived bonus and actual RaidGenerator dispatch. It compares complete initial NPC traits against saved initial states. UUID and random initial gauge are deliberately excluded for V3: the prototype used a separate final-NPC construction stream. Target/Q/multiplier deltas are recorded without assuming double-bit equality or changing C.

`historical` exports 72 conditions (three old versions, N1/2/3/4/7/8/15/30, levels1/25/50). One scoped generation stream constructs players then NPC. The same helper is run once against current production classes and once with only archived MyconidColonyGenerator overriding that class on the classpath. Comparison includes exact calibration, UUID, initial gauge, stats, skills, all characteristics and legacyPower.

Prepared players in this historical branch comparison explicitly retain V3, while NPC formula selections are LEGACY/V1/V2. This isolates compatibility of the generator for identical supplied combat copies. The first helper attempt incorrectly requested legacy player formulas for an archived GUARD player, which correctly failed because GUARD is unavailable in legacy formulas. That attempt produced no historical JSON; its source and logs remain separate. It is a harness input error, not a production failure.

The archived baseline source is `documentation/raid-redesign-step-15-evidence/source/range-source.java`; copy it under its actual public class filename in a new baseline source directory before compilation. No other class should be overridden.

After GO, compile this helper against the new target into this temporary directory. Compile baseline Myconid into a separate temporary class directory, with current target classes as dependencies. Never compile either into target. Save modern.json, historical-current.json and historical-baseline.json, then run compare.cjs and capture its JSON output. Failed/nonexact modern cases must be investigated and reported, not retuned or hidden.

## Completed result, 2026-11-08

The main agent reported the completed stable production build: 1733 tests, 1704 passed, 29 skipped, no failures/errors, Checkstyle0. Only after GO was this helper compiled using JDK25.0.1 with --release24, into this temporary directory. No Maven/app/database or battles were run by this structural check.

All 90 modern conditions match archived NPC characteristics exactly in both direct generation and actual RaidGenerator dispatch. The selected multiplier also equals its archived double exactly in all conditions. Maximum relative floating differences: playerQ4.440892098500626e-16, target7.771561172376096e-16, NPCQ9.992007221626409e-16. These are reported, not compensated with C changes.

All 72 historical conditions are byte-exact between current code and the process overriding only archived MyconidColonyGenerator: calibration, UUID, initial initiative gauge, statistics, traits and legacyPower. Both files have SHA256 5cc39203e252e06828c6f4fbe9593f55fe36887d08ccdcf549176ab4b0726658.

This establishes structural preservation on saved inputs, not current balance acceptance. It performs no Battle.process calls and does not add independent observations to the archived 4880 battles. The independent main-agent repeated archived battle experiment remains separate.

commands.sh contains the exact compile/export/compare sequence, parameterized by a new output directory; it expects the same stable target, dependency classpath and explicitly extracted evidence. It does not modify target. Initial harness input failure and correction are recorded in failed-attempt.json; no JSON from that invalid attempt is included in successful comparisons.

## Separate-process actual combat replay

Step152ReplayProbe.java calls the current PveAdaptationStudy.run, which constructs participants through the actual generators and invokes Battle.process. Twelve fixed conditions: MAIN MID/STRONG N3/N4 levels20/25; PIERCE_ARCANE BEGINNER N1 level1; RAPIER_ARCANE MID N3 level10; MAIN MID N3 level25 with effects; MAIN MID N30 level50. One fresh mirrored pair per condition, 24 fights. Generation root8026110815200 and battle root9026110815200 plus caseId×1000 are explicit and distinct from prior studies.

Two separate JVMs completed the same 24 seeded fights without timeouts. Both complete streams are saved under replay-a/ and replay-b/, with full source/combat inputs, calibration metadata, initial states, action hashes and trace hashes. The full canonical streams are byte-exact: SHA256299c33d6ca6cd62f0a071fb403af5fcd654020f15483e06080dbc2c3d61de5d4.

The original raw streams are NOT byte-exact because Java Set serialization order for ItemObject.slots and Modifier.availableOnSlots varies between JVMs. Both original streams are preserved. Canonicalization sorts only those two schema-defined Set arrays; it removes no fields and changes no other array order, seed, identifier, combat state, outcome or action/trace digest. The independent compare-replay.cjs also parses and checks equality under precisely this normalization. This distinction is explicit in replay-receipt.json and must not be reported as unqualified raw-byte equality.

The verification run repeats the original seeded observations; it is neither 48 independent fights nor an estimate of balance. replay-commands.sh contains the exact separate-process sequence for a new output directory. No production source, target classes or configuration were edited, no Maven/bot/database used. The temporary helper compiler reported only the existing deprecated JsonNode.fields API; compilation succeeded.
