package ru.homyakin.seeker.game.battle;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.zip.GZIPOutputStream;
import ru.homyakin.seeker.game.battle.Step123ReferenceTeams.Tier;
import ru.homyakin.seeker.game.battle.skill.active_impl.ActiveEnum;
import ru.homyakin.seeker.game.battle.skill.scaling.SkillFormulaVersion;
import ru.homyakin.seeker.game.event.launched.RaidParams;
import ru.homyakin.seeker.game.event.models.EventStatus;
import ru.homyakin.seeker.game.event.pve.PveCharacteristicScaling;
import ru.homyakin.seeker.game.event.raid.generator.RaidGenerator;
import ru.homyakin.seeker.game.event.raid.models.LaunchedRaidEvent;
import ru.homyakin.seeker.game.event.raid.models.RaidType;
import ru.homyakin.seeker.game.item.models.AttackType;
import ru.homyakin.seeker.game.item.models.DefenseType;
import ru.homyakin.seeker.game.item.models.Item;
import ru.homyakin.seeker.game.item.models.ItemAttack;
import ru.homyakin.seeker.game.item.models.ItemDefense;
import ru.homyakin.seeker.game.item.models.ItemObject;
import ru.homyakin.seeker.game.item.models.ItemRarity;
import ru.homyakin.seeker.game.item.models.Modifier;
import ru.homyakin.seeker.game.personage.models.PersonageSlot;
import ru.homyakin.seeker.game.personage.models.effect.PersonageEffects;
import ru.homyakin.seeker.utils.RandomUtils;

public final class ScalingQPrototype {
    private static final SkillFormulaVersion VERSION = SkillFormulaVersion.SCALING_SKILLS_V3;
    private static final BattleTempoVersion TEMPO = BattleTempoVersion.ACCELERATED_V1;
    private static final long GENERATION_ROOT = 4_026_110_816_000L;
    private static final long BATTLE_ROOT = 5_026_110_816_000L;
    private static final double MAX_M = PveCharacteristicScaling.maxMultiplier(420, 280, 195, 160, 130, 70);
    private static double correction;
    private static int caseId;

    private enum Model { OLD, Q_MAX, Q_MAX_ROLE }

    public static void main(String[] args) throws Exception {
        final var output = Path.of(args[0]);
        Files.createDirectory(output);
        final var anchorPlayers = RandomUtils.withSeed(GENERATION_ROOT, () -> players(Tier.MID, 3));
        final var anchor = RandomUtils.withSeed(GENERATION_ROOT, () -> old(anchorPlayers, 25));
        final double anchorQ = q(anchor.enemies());
        correction = anchorQ / (q(anchorPlayers) * levelBonus(25) * groupBonus(3));
        final var manifest = new LinkedHashMap<String, Object>();
        manifest.put("purpose", "EXPLORATORY_NOT_ACCEPTANCE_NO_PRODUCTION_CHANGE");
        manifest.put("models", List.of(Model.values()));
        manifest.put("qFormula", "sum_i(HP_i/mean_over_all_AttackType(mu_i)) * sum_i(max_r(sum_attack_types(attack_i(r))) * (1+clamp(crit_i,0,100)/100*(critMultiplier_i-1)) * min(speed_i/1000,1))");
        manifest.put("ignored", List.of("dodge", "skills", "target positions and tactics", "opponent attack/defense matchup"));
        manifest.put("generationRoot", GENERATION_ROOT);
        manifest.put("battleRoot", BATTLE_ROOT);
        manifest.put("correction", correction);
        manifest.put("anchor", Map.of("tier", "MID", "size", 3, "raidLevel", 25,
            "oldMultiplier", anchor.calibration().multiplier(), "oldNpcQ", anchorQ,
            "playerQ", q(anchorPlayers), "oldTarget", anchor.calibration().targetPower()));
        manifest.put("roleWeights", "M/(2F) for guardian; M/(2S) for slinger; HP and attack weighted, defense unweighted; ceil at final scaling");
        manifest.put("roleAnchorPolicy", "Same targetQ as original OLD anchor NPC; role redistribution changes exact anchor multiplier and NPC stats");
        manifest.put("commonRandomPolicy", "Same generation/battle seeds across models and adjacent-size comparisons; stable construction seed separately for final players and NPC, no search RNG leakage; mirrors fresh");
        manifest.put("oldPolicy", "Real production RaidGenerator calibration; custom exact-copy NPC factory at selected production m, final construction RNG reset so old/new scalar comparisons do not include search-RNG leakage");
        manifest.put("normalAppend", "MAIN N4 is exact MAIN N3 plus final Bruiser; complete item equality asserted at both tiers");
        manifest.put("tempo", TEMPO);
        manifest.put("skillFormula", VERSION);
        manifest.put("baseNpc", Map.of("guardian", List.of(420,70,160,4,3,0.3,190,35,"FRONT","KNOCKBACK","MAGICAL1..1","ARCANE"),
            "slinger", List.of(280,130,70,8,5,0.5,160,15,"BACK","PRECISE_STRIKE","MAGICAL1..3","ARCANE")));
        final var inputs = new ArrayList<Map<String, Object>>();
        for (final var tier : List.of(Tier.MID, Tier.STRONG)) {
            final var three = Step123ReferenceTeams.mainTeam(tier, 3).members();
            final var four = Step123ReferenceTeams.mainTeam(tier, 4).members();
            for (int i = 0; i < 3; ++i) {
                if (!three.get(i).items(tier.level()).equals(four.get(i).items(tier.level()))
                    || three.get(i).build().position() != four.get(i).build().position()
                    || three.get(i).build().tactic() != four.get(i).build().tactic()) {
                    throw new IllegalStateException("Non-nested main input");
                }
            }
            for (final int size : List.of(2,3,4,7,8)) {
                final var members = Step123ReferenceTeams.mainTeam(tier,size).members().stream().map(member ->
                    Map.of("build", member.build().code(), "position", member.build().position(),
                        "tactic", member.build().tactic(), "items", member.items(tier.level()))).toList();
                inputs.add(Map.of("tier",tier,"size",size,"members",members));
            }
        }
        Files.writeString(output.resolve("manifest.json"), json(manifest));
        Files.writeString(output.resolve("inputs.json"), json(inputs));
        final var summaries = new ArrayList<Map<String,Object>>();
        try (var raw = new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(Files.newOutputStream(
            output.resolve("battles.jsonl.gz"), StandardOpenOption.CREATE_NEW)), StandardCharsets.UTF_8))) {
            for (final var tier : List.of(Tier.MID, Tier.STRONG)) {
                for (final int size : List.of(2,3,4,7,8)) {
                    for (final int level : List.of(15,25)) {
                        for (final var model : Model.values()) {
                            summaries.add(runCell(tier,size,level,model,raw,output));
                            System.out.println("done=" + caseId + " " + tier + " N" + size + " L" + level + " " + model);
                        }
                    }
                }
            }
        }
        Files.writeString(output.resolve("summary.json"), json(Map.of("cases",summaries,
            "confidence", "Pair-unit Hoeffding 95%, pointwise not simultaneous", "manifest", manifest)));
        System.out.println("FINISHED cases=" + summaries.size());
    }

    private static Map<String,Object> runCell(Tier tier,int size,int level,Model model,
        BufferedWriter raw,Path output) throws Exception {
        final int id = ++caseId;
        final int pairs = level == 25 && (size == 3 || size == 4) ? 100 : 50;
        int wins=0,losses=0,draws=0,timeouts=0;
        long totalRounds=0;
        final var scores = new ArrayList<Double>();
        final var powers = new ArrayList<Double>();
        final var multipliers = new ArrayList<Double>();
        double firstTarget=0,firstAchieved=0;
        for (int pair=0;pair<pairs;++pair) {
            double pairScore=0;
            boolean complete=true;
            // N is deliberately absent, so N3/N4 are paired additions; model is absent too.
            final long seedKey = (tier == Tier.MID ? 0 : 100_000L) + level * 1000L + pair;
            final long generationSeed=GENERATION_ROOT+seedKey;
            final long battleSeed=BATTLE_ROOT+seedKey;
            for (final boolean reverse : List.of(false,true)) {
                final var playerTeam=RandomUtils.withSeed(generationSeed,()->players(tier,size));
                final double playerQ=q(playerTeam);
                final int count=Math.max(2,size);
                final PveCharacteristicScaling.Result calibration;
                if (model==Model.OLD) {
                    calibration=RandomUtils.withSeed(generationSeed+200_000_000,
                        ()->old(playerTeam,level).calibration());
                } else {
                    final double target=playerQ*levelBonus(level)*groupBonus(count)*correction;
                    calibration=PveCharacteristicScaling.search(target,MAX_M,
                        m->q(npc(count,m,model==Model.Q_MAX_ROLE)));
                }
                final var enemies=RandomUtils.withSeed(generationSeed+400_000_000,
                    ()->npc(count,calibration.multiplier(),model==Model.Q_MAX_ROLE));
                firstTarget=calibration.targetPower();
                firstAchieved=calibration.achievedPower();
                powers.add(q(enemies));
                multipliers.add(calibration.multiplier());
                final var row=new LinkedHashMap<String,Object>();
                row.put("caseId",id);row.put("tier",tier);row.put("size",size);row.put("level",level);
                row.put("model",model);row.put("pair",pair);row.put("reverse",reverse);
                row.put("generationSeed",generationSeed);row.put("battleSeed",battleSeed);
                row.put("calibration",calibration);row.put("playerQ",playerQ);row.put("npcQ",q(enemies));
                row.put("playerParts",playerTeam.stream().map(ScalingQPrototype::qParts).toList());
                row.put("enemyParts",enemies.stream().map(ScalingQPrototype::qParts).toList());
                try {
                    final var result=RandomUtils.withSeed(battleSeed,()->new Battle(battleSeed).process(
                        reverse?playerTeam:enemies,reverse?enemies:playerTeam,2000,TEMPO));
                    final boolean pa=playerTeam.stream().anyMatch(BattlePersonage::isAlive);
                    final boolean ea=enemies.stream().anyMatch(BattlePersonage::isAlive);
                    final String outcome=pa?"WIN":ea?"LOSS":"DRAW";
                    if (pa) {++wins;pairScore+=0.5;} else if(ea){++losses;} else {++draws;pairScore+=0.25;}
                    row.put("outcome",outcome);row.put("rounds",result.rounds());
                    totalRounds+=result.rounds();
                    row.put("events",result.actionLog().events().size());
                    row.put("playerStats",playerTeam.stream().map(BattlePersonage::battlePersonageStats).toList());
                    row.put("enemyStats",enemies.stream().map(BattlePersonage::battlePersonageStats).toList());
                    row.put("actualEnemyPositions",enemies.stream().map(e->result.initState().lines()
                        .get(result.initState().personagesById().get(e.id()).lineIndex()).position()).toList());
                    if (pair==0 && !reverse) {
                        Files.writeString(output.resolve("init-case"+id+".json"),json(result.initState()));
                    }
                } catch(IllegalStateException ex) {
                    if(ex.getMessage()==null || !ex.getMessage().startsWith("Battle did not finish within")) throw ex;
                    ++timeouts;complete=false;row.put("outcome","TIMEOUT");row.put("rounds",2000);
                }
                raw.write(PveAdaptationStudy.JSON.writeValueAsString(row));raw.newLine();
            }
            if(complete)scores.add(pairScore);
        }
        final double mean=scores.stream().mapToDouble(Double::doubleValue).average().orElseThrow();
        final double half=Math.sqrt(Math.log(40)/(2*scores.size()));
        final var result=new LinkedHashMap<String,Object>();
        result.put("caseId",id);result.put("tier",tier);result.put("size",size);result.put("level",level);
        result.put("model",model);result.put("pairs",pairs);result.put("wins",wins);result.put("losses",losses);
        result.put("draws",draws);result.put("timeouts",timeouts);result.put("pairScores",scores);
        result.put("winrate",wins/(2.0*pairs));result.put("pairMean",mean);
        result.put("pairHoeffding95",List.of(Math.max(0,mean-half),Math.min(1,mean+half)));
        result.put("meanRounds",totalRounds/(double)(wins+losses+draws));
        result.put("multiplier",multipliers.getFirst());result.put("npcQ",powers.getFirst());
        result.put("target",firstTarget);result.put("achieved",firstAchieved);
        return result;
    }

    private static List<BattlePersonage> players(Tier tier,int size) {
        return Step123ReferenceTeams.mainTeam(tier,size).members().stream().map(member->{
            final var p=BattlePersonage.forCombat(member.items(tier.level()),member.build().position(),
                PersonageEffects.EMPTY,Optional.of(member.build().code()),VERSION);
            p.setTargetingTactic(member.build().tactic());return p;
        }).toList();
    }

    private static ru.homyakin.seeker.game.event.pve.GeneratedPveEnemies old(List<BattlePersonage> ps,int level) {
        final var event=new LaunchedRaidEvent(1,1,LocalDateTime.of(2026,11,8,0,0),
            LocalDateTime.of(2026,11,8,1,0),EventStatus.LAUNCHED,new RaidParams(level,0));
        return new RaidGenerator().generateCalibrated(RaidType.MYCONID_COLONY,event,ps,VERSION);
    }

    private static List<BattlePersonage> npc(int count,double m,boolean role) {
        final int fronts=count/2,backs=count-fronts;
        final var result=new ArrayList<BattlePersonage>();
        for(int i=0;i<fronts;++i)result.add(unit(true,m,role?count/(2.0*fronts):1));
        for(int i=0;i<backs;++i)result.add(unit(false,m,role?count/(2.0*backs):1));
        return result;
    }

    private static BattlePersonage unit(boolean guardian,double m,double weight) {
        final var object=new ItemObject(null,Set.of(PersonageSlot.MAIN_HAND),
            Optional.of(new ItemAttack(AttackType.MAGICAL,1,guardian?1:3,multiply(guardian?70:130,m*weight))),
            Optional.of(new ItemDefense(DefenseType.ARCANE,multiply(guardian?160:70,m))),
            multiply(guardian?420:280,m*weight),guardian?4:8,guardian?3:5,guardian?0.3:0.5,
            guardian?190:160,guardian?35:15,null);
        final var item=new Item(object,Optional.of(new Modifier(guardian?ActiveEnum.KNOCKBACK:ActiveEnum.PRECISE_STRIKE)),
            ItemRarity.LEGENDARY);
        return BattlePersonage.forCombat(List.of(item),guardian?Position.FRONT:Position.BACK,
            PersonageEffects.EMPTY,Optional.empty(),VERSION);
    }

    private static int multiply(int base,double multiplier){return PveCharacteristicScaling.multiply(base,multiplier);}
    private static double levelBonus(int level){return 0.54+0.06*level;}
    private static double groupBonus(int count){return 1+0.05*Math.log(count)/Math.log(4);}

    private static Map<String,Object> qParts(BattlePersonage p) {
        final double mu=java.util.Arrays.stream(AttackType.values()).mapToDouble(type->p.defenseReductions().get(type)).average().orElseThrow();
        final double ehp=p.maxHealth()/mu;
        final int attack=p.attacksByRange().stream().mapToInt(row->row.attack().values().stream().mapToInt(Integer::intValue).sum()).max().orElse(0);
        final double crit=1+Math.max(0,Math.min(100,p.critChance()))/100.0*(p.critMultiplier()-1);
        final double frequency=Math.max(0,Math.min(1,p.initiative()/1000.0));
        return Map.of("hp",p.maxHealth(),"mu",mu,"ehp",ehp,"maxAttack",attack,"critFactor",crit,
            "frequency",frequency,"offense",attack*crit*frequency,"attacks",p.attacksByRange(),"skills",p.skillSnapshots());
    }

    private static double q(List<BattlePersonage> ps) {
        double ehp=0,offense=0;
        for(final var p:ps){final var parts=qParts(p);ehp+=(double)parts.get("ehp");offense+=(double)parts.get("offense");}
        return ehp*offense;
    }

    private static String json(Object value) throws Exception {
        return PveAdaptationStudy.JSON.writerWithDefaultPrettyPrinter().writeValueAsString(value);
    }
}
