package ru.homyakin.seeker.game.battle;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import java.util.zip.GZIPOutputStream;
import ru.homyakin.seeker.game.battle.Step123ReferenceTeams.Tier;
import ru.homyakin.seeker.game.battle.skill.active_impl.ActiveEnum;
import ru.homyakin.seeker.game.battle.skill.scaling.SkillFormulaVersion;
import ru.homyakin.seeker.game.event.pve.PveCharacteristicScaling;
import ru.homyakin.seeker.game.item.models.AttackType;
import ru.homyakin.seeker.game.item.models.DefenseType;
import ru.homyakin.seeker.game.item.models.Item;
import ru.homyakin.seeker.game.item.models.ItemAttack;
import ru.homyakin.seeker.game.item.models.ItemDefense;
import ru.homyakin.seeker.game.item.models.ItemObject;
import ru.homyakin.seeker.game.item.models.ItemRarity;
import ru.homyakin.seeker.game.item.models.Modifier;
import ru.homyakin.seeker.game.personage.models.PersonageSlot;
import ru.homyakin.seeker.game.personage.models.effect.PersonageEffects;
import ru.homyakin.seeker.utils.RandomUtils;

public final class ScalingQStructureProbe {
    private static final double C=0.5900075417594784;
    private static final long GENERATION_ROOT=4_026_110_816_000L;
    private static final long BATTLE_ROOT=5_026_110_816_000L;
    private static final long STRUCTURE_ROOT=6_026_110_816_000L;
    private static final int GUARD_HP=Integer.getInteger("probe.guardHp",420);
    private static final int GUARD_DEF=Integer.getInteger("probe.guardDefense",160);
    private static final double MAX_M=PveCharacteristicScaling.maxMultiplier(630,195,160,420,280,130,70);
    private static final Method PLAYERS=method("players",Tier.class,int.class);
    private static final Method Q=method("q",List.class);
    private static final Method PARTS=method("qParts",BattlePersonage.class);
    private static int nextCaseId;
    private enum Mode { STANDARD_ROLE, FORCED_COUNT3, RANDOM_ODD_ROLE }

    public static void main(String[] args) throws Exception {
        final var output=Path.of(args[0]);Files.createDirectory(output);
        final var manifest=new LinkedHashMap<String,Object>(Map.of("purpose","EXPLORATORY_STRUCTURAL_COUNTERFACTUAL_NOT_APPROVED_BALANCE",
            "C",C,"generationRoot",GENERATION_ROOT,"battleRoot",BATTLE_ROOT,"structureRoot",STRUCTURE_ROOT,
            "forcedPolicy","N4 generates M3 but playerQ and g(N4) unchanged; violates current count rule intentionally",
            "randomPolicy","Odd M F=floor(M/2) or ceil(M/2), each probability 1/2 using separate structure seed; S=M-F; HP/Atk role weights M/(2F),M/(2S); defense only m; even unchanged",
            "inputs","Same unchanged input items/positions/tactics as ../results/inputs.json",
            "pairPolicy","Mirrors share generation, structure and battle seeds but are one independent pair; cross-sizes/model use common random seed; pointwise Hoeffding only"));
        manifest.put("guardianHpBase",GUARD_HP);manifest.put("guardianDefenseBase",GUARD_DEF);
        manifest.put("onlyThin",Boolean.getBoolean("probe.onlyThin"));
        manifest.put("structureSeedMix","SplitMix64 finalizer before java.util.Random first boolean; do not use unmixed adjacent seeds");
        manifest.put("onlyRandom",Boolean.getBoolean("probe.onlyRandom"));
        Files.writeString(output.resolve("manifest.json"),json(manifest));
        final var summaries=new ArrayList<Map<String,Object>>();
        try(var raw=writer(output.resolve("battles.jsonl.gz"));var actors=writer(output.resolve("actors.jsonl.gz"))) {
            if(Boolean.getBoolean("probe.onlyThin")) {
                for(final var tier:List.of(Tier.MID,Tier.STRONG))for(final int level:List.of(15,20,25,30))for(final int size:List.of(3,4))
                    summaries.add(run(tier,size,level,Mode.STANDARD_ROLE,50,raw,actors,output));
            } else {
            if(!Boolean.getBoolean("probe.onlyRandom")) {
            for(final var tier:List.of(Tier.MID,Tier.STRONG)) {
                summaries.add(run(tier,3,25,Mode.STANDARD_ROLE,100,raw,actors,output));
                summaries.add(run(tier,4,25,Mode.STANDARD_ROLE,100,raw,actors,output));
                summaries.add(run(tier,4,25,Mode.FORCED_COUNT3,100,raw,actors,output));
            }
            }
            for(final var tier:List.of(Tier.MID,Tier.STRONG)) {
                for(final int level:List.of(15,20,25,30)) {
                    for(final int size:List.of(2,3,4,7,8)) {
                        summaries.add(run(tier,size,level,Mode.RANDOM_ODD_ROLE,50,raw,actors,output));
                    }
                }
            }
            }
        }
        Files.writeString(output.resolve("summary.json"),json(Map.of("manifest",manifest,"cases",summaries)));
        System.out.println("COMPLETE cases="+summaries.size());
    }

    private static Map<String,Object> run(Tier tier,int size,int level,Mode mode,int pairs,
        BufferedWriter raw,BufferedWriter actors,Path output) throws Exception {
        final int caseId=++nextCaseId;
        int wins=0,losses=0,draws=0,timeouts=0;long rounds=0;
        final var scores=new ArrayList<Double>();
        final var branch=new TreeMap<String,List<Double>>();
        final var branchCounts=new TreeMap<String,Integer>();
        for(int pair=0;pair<pairs;++pair) {
            final long seedKey=(tier==Tier.MID?0:100_000L)+level*1000L+pair;
            final long generationSeed=GENERATION_ROOT+seedKey,battleSeed=BATTLE_ROOT+seedKey;
            final long structureSeed=STRUCTURE_ROOT+seedKey+size*1_000_000L;
            final int count=mode==Mode.FORCED_COUNT3?3:Math.max(2,size);
            final boolean ceil=mode==Mode.RANDOM_ODD_ROLE && count%2==1
                && RandomUtils.withSeed(mix(structureSeed),RandomUtils::bool);
            final int front=count/2+(ceil?1:0),back=count-front;
            final String branchName=count%2==0?"EVEN":ceil?"CEIL_FRONT":"FLOOR_FRONT";
            branchCounts.merge(branchName,1,Integer::sum);
            double pairScore=0;boolean completed=true;
            for(final boolean reverse:List.of(false,true)) {
                final var players=RandomUtils.withSeed(generationSeed,()->players(tier,size));
                // The forced-count experiment deliberately retains participant-count g(N4).
                final double target=q(players)*(0.54+0.06*level)*(1+0.05*Math.log(Math.max(2,size))/Math.log(4))*C;
                final var calibration=RandomUtils.withSeed(generationSeed+200_000_000,()->PveCharacteristicScaling.search(
                    target,MAX_M,m->q(npc(count,front,m))));
                final var enemies=RandomUtils.withSeed(generationSeed+400_000_000,()->npc(count,front,calibration.multiplier()));
                final var row=new LinkedHashMap<String,Object>();
                row.put("caseId",caseId);row.put("tier",tier);row.put("size",size);row.put("level",level);row.put("mode",mode);
                row.put("pair",pair);row.put("reverse",reverse);row.put("generationSeed",generationSeed);row.put("battleSeed",battleSeed);
                row.put("structureSeed",structureSeed);row.put("count",count);row.put("front",front);row.put("back",back);
                row.put("mixedStructureSeed",mix(structureSeed));
                row.put("branch",branchName);row.put("playerQ",q(players));row.put("npcQ",q(enemies));row.put("calibration",calibration);
                row.put("enemyParts",enemies.stream().map(ScalingQStructureProbe::parts).toList());
                try {
                    final var result=RandomUtils.withSeed(battleSeed,()->new Battle(battleSeed).process(
                        reverse?players:enemies,reverse?enemies:players,2000,BattleTempoVersion.ACCELERATED_V1));
                    final boolean pa=players.stream().anyMatch(BattlePersonage::isAlive),ea=enemies.stream().anyMatch(BattlePersonage::isAlive);
                    final String outcome=pa?"WIN":ea?"LOSS":"DRAW";
                    if(pa){++wins;pairScore+=0.5;}else if(ea){++losses;}else{++draws;pairScore+=0.25;}
                    rounds+=result.rounds();row.put("outcome",outcome);row.put("rounds",result.rounds());
                    if(mode!=Mode.RANDOM_ODD_ROLE && pair<20) {
                        final var detail=new LinkedHashMap<>(row);
                        final var stats=new ArrayList<Map<String,Object>>();
                        for(int i=0;i<players.size();++i)stats.add(actor("PLAYER_"+i,players.get(i),result));
                        for(int i=0;i<enemies.size();++i)stats.add(actor((i<front?"GUARDIAN_":"SLINGER_")+i,enemies.get(i),result));
                        detail.put("actors",stats);actors.write(PveAdaptationStudy.JSON.writeValueAsString(detail));actors.newLine();
                    }
                    if(pair==0&&!reverse)Files.writeString(output.resolve("init-case"+caseId+".json"),json(result.initState()));
                } catch(IllegalStateException ex) {
                    if(ex.getMessage()==null||!ex.getMessage().startsWith("Battle did not finish within"))throw ex;
                    ++timeouts;completed=false;row.put("outcome","TIMEOUT");row.put("rounds",2000);
                }
                raw.write(PveAdaptationStudy.JSON.writeValueAsString(row));raw.newLine();
            }
            if(completed){scores.add(pairScore);branch.computeIfAbsent(branchName,k->new ArrayList<>()).add(pairScore);}
        }
        final double mean=scores.stream().mapToDouble(Double::doubleValue).average().orElseThrow();
        final double half=Math.sqrt(Math.log(40)/(2*scores.size()));
        final var result=new LinkedHashMap<String,Object>();
        result.put("caseId",caseId);result.put("tier",tier);result.put("size",size);result.put("level",level);result.put("mode",mode);
        result.put("pairs",pairs);result.put("wins",wins);result.put("losses",losses);result.put("draws",draws);result.put("timeouts",timeouts);
        result.put("winrate",wins/(2.0*pairs));result.put("pairScores",scores);result.put("pairMean",mean);
        result.put("pairHoeffding95",List.of(Math.max(0,mean-half),Math.min(1,mean+half)));
        result.put("meanRounds",rounds/(double)(wins+losses+draws));result.put("branchPairCounts",branchCounts);
        final var branches=new TreeMap<String,Object>();
        branch.forEach((key,values)->branches.put(key,Map.of("pairs",values.size(),"scoreMean",
            values.stream().mapToDouble(Double::doubleValue).average().orElseThrow(),"pairScores",values)));
        result.put("branchScores",branches);
        System.out.println("case="+caseId+" "+tier+" N"+size+" L"+level+" "+mode+" win="+wins+"/"+(pairs*2));
        return result;
    }

    private static Map<String,Object> actor(String label,BattlePersonage p,BattleResult result) {
        final UUID id=p.id();long attempts=0,moves=0,knockbackDealt=0,knockbackTaken=0,forcedTaken=0;
        for(final var event:result.actionLog().traceEvents())if(event instanceof BattleTraceEvent.NormalAttackAttempt a&&a.attackerId().equals(id))++attempts;
        for(final var event:result.actionLog().events()) {
            if(event instanceof BattleEvent.MovedTowardEnemy a&&a.personageId().equals(id))++moves;
            if(event instanceof BattleEvent.PersonageForcedMove a) {
                if(a.personageId().equals(id))++forcedTaken;
                if(a.skill()==ActiveEnum.KNOCKBACK&&a.personageId().equals(id))++knockbackTaken;
                if(a.skill()==ActiveEnum.KNOCKBACK&&a.sourceId().equals(id))++knockbackDealt;
            }
        }
        final var resultRow=new LinkedHashMap<String,Object>();
        resultRow.put("label",label);resultRow.put("stats",p.battlePersonageStats());resultRow.put("actualDamageTaken",p.actualDamageTaken());
        resultRow.put("normalAttempts",attempts);resultRow.put("forwardMoves",moves);resultRow.put("knockbackDealt",knockbackDealt);
        resultRow.put("knockbackTaken",knockbackTaken);resultRow.put("forcedMovesTaken",forcedTaken);resultRow.put("basis",parts(p));
        return resultRow;
    }

    private static List<BattlePersonage> npc(int count,int front,double m) {
        final var result=new ArrayList<BattlePersonage>();
        for(int i=0;i<front;++i)result.add(unit(true,m,count/(2.0*front)));
        for(int i=front;i<count;++i)result.add(unit(false,m,count/(2.0*(count-front))));
        return result;
    }

    private static BattlePersonage unit(boolean g,double m,double w) {
        final var object=new ItemObject(null,Set.of(PersonageSlot.MAIN_HAND),
            Optional.of(new ItemAttack(AttackType.MAGICAL,1,g?1:3,PveCharacteristicScaling.multiply(g?70:130,m*w))),
            Optional.of(new ItemDefense(DefenseType.ARCANE,PveCharacteristicScaling.multiply(g?GUARD_DEF:70,m))),
            PveCharacteristicScaling.multiply(g?GUARD_HP:280,m*w),g?4:8,g?3:5,g?0.3:0.5,g?190:160,g?35:15,null);
        return BattlePersonage.forCombat(List.of(new Item(object,Optional.of(new Modifier(g?ActiveEnum.KNOCKBACK:ActiveEnum.PRECISE_STRIKE)),
            ItemRarity.LEGENDARY)),g?Position.FRONT:Position.BACK,PersonageEffects.EMPTY,Optional.empty(),SkillFormulaVersion.SCALING_SKILLS_V3);
    }

    private static Method method(String name,Class<?>... types){try{final var m=ScalingQPrototype.class.getDeclaredMethod(name,types);m.setAccessible(true);return m;}catch(Exception e){throw new RuntimeException(e);}}
    private static long mix(long value){long x=value;x=(x^(x>>>30))*0xbf58476d1ce4e5b9L;x=(x^(x>>>27))*0x94d049bb133111ebL;return x^(x>>>31);}
    @SuppressWarnings("unchecked") private static List<BattlePersonage> players(Tier tier,int size){try{return (List<BattlePersonage>)PLAYERS.invoke(null,tier,size);}catch(Exception e){throw new RuntimeException(e);}}
    private static double q(List<BattlePersonage> ps){try{return (double)Q.invoke(null,ps);}catch(Exception e){throw new RuntimeException(e);}}
    @SuppressWarnings("unchecked") private static Map<String,Object> parts(BattlePersonage p){try{return (Map<String,Object>)PARTS.invoke(null,p);}catch(Exception e){throw new RuntimeException(e);}}
    private static BufferedWriter writer(Path p)throws Exception{return new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(Files.newOutputStream(p,StandardOpenOption.CREATE_NEW)),StandardCharsets.UTF_8));}
    private static String json(Object value)throws Exception{return PveAdaptationStudy.JSON.writerWithDefaultPrettyPrinter().writeValueAsString(value);}
}
