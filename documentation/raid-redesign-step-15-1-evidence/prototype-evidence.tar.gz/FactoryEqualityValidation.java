package ru.homyakin.seeker.game.battle;

import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.List;
import ru.homyakin.seeker.game.battle.Step123ReferenceTeams.Tier;
import ru.homyakin.seeker.game.battle.skill.scaling.SkillFormulaVersion;
import ru.homyakin.seeker.game.event.launched.RaidParams;
import ru.homyakin.seeker.game.event.models.EventStatus;
import ru.homyakin.seeker.game.event.raid.generator.RaidGenerator;
import ru.homyakin.seeker.game.event.raid.models.LaunchedRaidEvent;
import ru.homyakin.seeker.game.event.raid.models.RaidType;
import ru.homyakin.seeker.utils.RandomUtils;

public final class FactoryEqualityValidation {
    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        final Method players=ScalingQPrototype.class.getDeclaredMethod("players",Tier.class,int.class);
        final Method npc=ScalingQPrototype.class.getDeclaredMethod("npc",int.class,double.class,boolean.class);
        players.setAccessible(true);npc.setAccessible(true);
        int cells=0,units=0;
        for(final var tier:List.of(Tier.MID,Tier.STRONG))for(final int size:List.of(2,3,4,7,8))for(final int level:List.of(15,25)) {
            final var ps=(List<BattlePersonage>)players.invoke(null,tier,size);
            final var event=new LaunchedRaidEvent(1,1,LocalDateTime.of(2026,11,8,0,0),LocalDateTime.of(2026,11,8,1,0),
                EventStatus.LAUNCHED,new RaidParams(level,0));
            final var actual=RandomUtils.withSeed(912_000L+cells,()->new RaidGenerator().generateCalibrated(
                RaidType.MYCONID_COLONY,event,ps,SkillFormulaVersion.SCALING_SKILLS_V3));
            final var copy=(List<BattlePersonage>)npc.invoke(null,size,actual.calibration().multiplier(),false);
            if(actual.enemies().size()!=copy.size())throw new IllegalStateException("Count mismatch");
            for(int i=0;i<copy.size();++i) {
                if(!state(actual.enemies().get(i)).equals(state(copy.get(i))))throw new IllegalStateException("NPC mismatch at "+tier+" N"+size+" L"+level+" i"+i);
                ++units;
            }
            ++cells;
        }
        System.out.printf("{\"status\":\"EXACT_FACTORY_CHARACTERISTICS_MATCH_PRODUCTION\",\"cells\":%d,\"units\":%d,\"excluded\":[\"UUID\",\"initial random gauge\"]}%n",cells,units);
    }
    private static List<Object> state(BattlePersonage p) {
        return List.of(p.maxHealth(),p.attacksByRange(),p.defenses(),p.defenseReductions(),p.critChance(),p.dodgeChance(),
            p.critMultiplier(),p.initiative(),p.totalThreat(),p.impactStrength(),p.range(),p.startPosition(),p.skillSnapshots(),p.usesScalingCombatRules());
    }
}
