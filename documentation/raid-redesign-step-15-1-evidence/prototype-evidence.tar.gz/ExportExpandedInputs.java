package ru.homyakin.seeker.game.battle;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import ru.homyakin.seeker.game.battle.Step123ReferenceTeams.Tier;

public final class ExportExpandedInputs {
    public static void main(String[] args) throws Exception {
        final var inputs=new ArrayList<Map<String,Object>>();
        for(final var tier:List.of(Tier.MID,Tier.STRONG))for(final int size:List.of(1,2,3,4,7,8,15,30)) {
            final var members=Step123ReferenceTeams.mainTeam(tier,size).members().stream().map(member->
                Map.of("build",member.build().code(),"position",member.build().position(),"tactic",member.build().tactic(),
                    "items",member.items(tier.level()))).toList();
            inputs.add(Map.of("tier",tier,"size",size,"members",members));
        }
        Files.writeString(Path.of(args[0]),PveAdaptationStudy.JSON.writerWithDefaultPrettyPrinter().writeValueAsString(inputs),StandardOpenOption.CREATE_NEW);
    }
}
