package ru.homyakin.seeker.game.battle;

import java.util.List;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.homyakin.seeker.game.battle.skill.active_impl.ActiveEnum;

class Step123BattleStudyTest {
    @Test
    void casesAreUniqueAndUseCompleteLegalEquipment() {
        final var cases = Step123BattleStudy.cases();
        Assertions.assertThat(cases).hasSize(1077);
        Assertions.assertThat(cases.stream().map(Step123BattleStudy.StudyCase::code).distinct().count())
            .isEqualTo(cases.size());
        for (final var value : cases) {
            for (final var team : List.of(value.left(), value.right())) {
                for (final var gear : team) {
                    Assertions.assertThat(gear.items(value.level()).stream()
                        .mapToInt(item -> item.object().slots().size()).sum()).isEqualTo(7);
                }
            }
        }
    }

    @Test
    void mobileAlternativesKeepFourPointsAndAnExactOffComparison() {
        for (final var build : Step123BattleStudy.mobileBuilds()) {
            Assertions.assertThat(build.items(0).stream().mapToInt(item -> item.skillPoints()).sum()).isEqualTo(4);
            Assertions.assertThat(build.assignments().values()).allMatch(value -> value.skill() == ActiveEnum.HIT_AND_RUN);
        }
        final var cases = Step123BattleStudy.cases();
        for (final var value : cases.stream().filter(value -> value.family().equals("MOBILE")
            && value.disabledLeft().isEmpty()).toList()) {
            final var off = cases.stream().filter(candidate -> candidate.code().equals(value.code() + "_OFF"))
                .findFirst().orElseThrow();
            Assertions.assertThat(off.left()).isEqualTo(value.left());
            Assertions.assertThat(off.right()).isEqualTo(value.right());
            Assertions.assertThat(off.seedGroup()).isEqualTo(value.seedGroup());
            Assertions.assertThat(off.disabledLeft()).containsExactly(ActiveEnum.HIT_AND_RUN);
        }
    }

    @Test
    void clothComparisonsHaveTheSameKnownGoldCost() throws Exception {
        final var selected = Step123BattleStudy.cases().stream().filter(value -> value.family().equals("CLOTH")).toList();
        for (final var value : selected) {
            Assertions.assertThat(Step123BattleStudy.knownGold(value.left(), value.level())).isEqualTo(2550);
            Assertions.assertThat(Step123BattleStudy.knownGold(value.right(), value.level())).isEqualTo(2100);
        }
    }
}
