package ru.homyakin.seeker.game.battle;

import ru.homyakin.seeker.utils.RandomUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Battle {
    private record Mover(BattlePersonage personage, Map<UUID, BattlePersonage> enemyAliveTeam) { }

    private final BattleRandom random;

    public Battle() {
        this(new DefaultBattleRandom());
    }

    public Battle(long seed) {
        this(new SeededBattleRandom(seed));
    }

    Battle(BattleRandom random) {
        this.random = random;
    }

    public BattleResult process(List<BattlePersonage> firstTeam, List<BattlePersonage> secondTeam) {
        return process(firstTeam, secondTeam, Integer.MAX_VALUE, BattleTempoVersion.BASELINE_V1);
    }

    public BattleResult process(
        List<BattlePersonage> firstTeam,
        List<BattlePersonage> secondTeam,
        BattleTempoVersion tempoVersion
    ) {
        return process(firstTeam, secondTeam, Integer.MAX_VALUE, tempoVersion);
    }

    public BattleResult process(
        List<BattlePersonage> firstTeam,
        List<BattlePersonage> secondTeam,
        int maxRounds
    ) {
        return process(firstTeam, secondTeam, maxRounds, BattleTempoVersion.BASELINE_V1);
    }

    public BattleResult process(
        List<BattlePersonage> firstTeam,
        List<BattlePersonage> secondTeam,
        int maxRounds,
        BattleTempoVersion tempoVersion
    ) {
        if (maxRounds <= 0) {
            throw new IllegalArgumentException("maxRounds must be positive");
        }
        final var battleMap = new BattleContext(firstTeam, secondTeam, random, tempoVersion);
        final var initState = captureInitState(battleMap, firstTeam, secondTeam);
        final var actionLog = new BattleActionLog();

        final var firstAliveTeam = battleMap.firstAliveTeam();
        final var secondAliveTeam = battleMap.secondAliveTeam();

        int rounds = 0;
        while (!firstAliveTeam.isEmpty() && !secondAliveTeam.isEmpty()) {
            if (rounds >= maxRounds) {
                throw new IllegalStateException("Battle did not finish within %d rounds".formatted(maxRounds));
            }
            ++rounds;
            actionLog.add(new BattleEvent.RoundStarted(rounds));
            final var movers = new ArrayList<Mover>();

            for (final var p : firstAliveTeam.values()) {
                if (p.tick(actionLog, rounds)) {
                    movers.add(new Mover(p, secondAliveTeam));
                }
            }
            for (final var p : secondAliveTeam.values()) {
                if (p.tick(actionLog, rounds)) {
                    movers.add(new Mover(p, firstAliveTeam));
                }
            }

            final var orderedMovers = battleMap.usesScalingSkillOrder()
                ? random.shuffle("turn-order:" + rounds, movers)
                : RandomUtils.shuffle(movers);
            for (final var mover : orderedMovers) {
                if (mover.enemyAliveTeam().isEmpty()) {
                    break;
                }
                if (mover.personage().move(battleMap, actionLog, rounds)) {
                    break;
                }
                battleMap.pruneDefeated();
            }
        }
        final var personageStats = new HashMap<UUID, BattlePersonageStats>();
        Stream.concat(firstTeam.stream(), secondTeam.stream())
            .forEach(p -> personageStats.put(p.id(), p.battlePersonageStats()));

        return new BattleResult(
            initState,
            actionLog,
            rounds,
            firstAliveTeam.values().stream().anyMatch(BattlePersonage::isAlive),
            personageStats
        );
    }

    private static BattleInitState captureInitState(
        BattleContext battleContext,
        List<BattlePersonage> firstTeam,
        List<BattlePersonage> secondTeam
    ) {
        final Set<UUID> firstTeamIds = firstTeam.stream().map(BattlePersonage::id).collect(Collectors.toSet());
        final var lines = battleContext.lines();
        final var lineSnapshots = new ArrayList<BattleLineInitSnapshot>();
        for (int i = 0; i < lines.size(); i++) {
            final var line = lines.get(i);
            final var ids = line.battlePersonages().keySet().stream().sorted().toList();
            lineSnapshots.add(new BattleLineInitSnapshot(i, line.firstTeam(), line.position(), ids));
        }
        final var personagesById = new HashMap<UUID, BattlePersonageInitSnapshot>();
        Stream.concat(firstTeam.stream(), secondTeam.stream()).forEach(p ->
            personagesById.put(
                p.id(),
                new BattlePersonageInitSnapshot(
                    p.id(),
                    p.name(),
                    firstTeamIds.contains(p.id()),
                    p.health(),
                    p.currentPosition(),
                    p.advanceDirection(),
                    p.initiative(),
                    p.initiativeGauge(),
                    p.range(),
                    p.totalThreat(),
                    p.impactStrength(),
                    p.targetingTactic(),
                    p.itemSnapshots(),
                    p.skillSnapshots(),
                    p.critChance(),
                    p.dodgeChance(),
                    p.critMultiplier(),
                    p.attacksByRange(),
                    p.defenses(),
                    p.defenseReductions()
                )
            )
        );
        return new BattleInitState(List.copyOf(lineSnapshots), Map.copyOf(personagesById), battleContext.tempoVersion());
    }
}
