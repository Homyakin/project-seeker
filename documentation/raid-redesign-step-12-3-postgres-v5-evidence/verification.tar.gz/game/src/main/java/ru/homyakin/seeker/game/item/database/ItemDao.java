package ru.homyakin.seeker.game.item.database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import javax.sql.DataSource;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.homyakin.seeker.game.item.models.CatalogModifier;
import ru.homyakin.seeker.game.item.models.Inventory;
import ru.homyakin.seeker.game.item.models.ItemRarity;
import ru.homyakin.seeker.game.item.models.PersonageItem;
import ru.homyakin.seeker.game.personage.models.PersonageId;

@Component
public class ItemDao {
    private final JdbcClient jdbcClient;
    private final ItemObjectDao itemObjectDao;
    private final ItemModifierDao itemModifierDao;

    public ItemDao(DataSource dataSource, ItemObjectDao itemObjectDao, ItemModifierDao itemModifierDao) {
        this.jdbcClient = JdbcClient.create(dataSource);
        this.itemObjectDao = itemObjectDao;
        this.itemModifierDao = itemModifierDao;
    }

    @Transactional
    public long save(PersonageItem item) {
        return jdbcClient.sql(SAVE_SQL)
            .param("item_object_id", item.objectId())
            .param("item_modifier_id", item.modifierId().orElse(null))
            .param("rarity", item.rarity().ordinal())
            .param("personage_id", item.personageId().map(PersonageId::value).orElse(null))
            .param("is_equipped", item.isEquipped())
            .param("enhance_level", item.enhanceLevel())
            .param("enhance_revision", item.enhanceRevision())
            .query((rs, _) -> rs.getLong("id"))
            .single();
    }

    public Optional<PersonageItem> getById(long id) {
        return jdbcClient.sql(SELECT_SQL + " WHERE i.id = :id")
            .param("id", id)
            .query(this::mapRow)
            .optional();
    }

    public Optional<PersonageItem> getOwnedByIdForUpdate(long id, PersonageId personageId) {
        return jdbcClient.sql(SELECT_SQL + """
                WHERE i.id = :id AND i.personage_id = :personage_id
                FOR UPDATE OF i
                """)
            .param("id", id)
            .param("personage_id", personageId.value())
            .query(this::mapRow)
            .optional();
    }

    public Inventory getByPersonageId(PersonageId personageId) {
        final var items = jdbcClient.sql(SELECT_SQL + " WHERE i.personage_id = :personage_id")
            .param("personage_id", personageId.value())
            .query(this::mapRow)
            .list();
        return new Inventory(items);
    }

    public Map<PersonageId, List<PersonageItem>> getEquippedByPersonageIds(Set<PersonageId> personageIds) {
        if (personageIds.isEmpty()) {
            return Map.of();
        }
        return jdbcClient.sql(SELECT_SQL + " WHERE i.personage_id IN (:personage_ids) AND i.is_equipped = true")
            .param("personage_ids", personageIds.stream().map(PersonageId::value).toList())
            .query(this::mapRow)
            .list()
            .stream()
            .collect(Collectors.groupingBy(
                item -> item.personageId().orElseThrow(),
                Collectors.toList()
            ));
    }

    public void invertEquip(long id) {
        jdbcClient.sql("UPDATE item SET is_equipped = NOT is_equipped WHERE id = :id")
            .param("id", id)
            .update();
    }

    public void setEquippedForPersonage(PersonageId personageId, List<Long> equippedItemIds) {
        if (equippedItemIds.isEmpty()) {
            jdbcClient.sql("UPDATE item SET is_equipped = false WHERE personage_id = :personage_id")
                .param("personage_id", personageId.value())
                .update();
            return;
        }
        jdbcClient.sql("""
                UPDATE item
                SET is_equipped = (id IN (:equipped_item_ids))
                WHERE personage_id = :personage_id
                """)
            .param("personage_id", personageId.value())
            .param("equipped_item_ids", equippedItemIds)
            .update();
    }

    public void updateEnhancement(long id, Integer modifierId, ItemRarity rarity) {
        jdbcClient.sql("""
                UPDATE item SET item_modifier_id = :item_modifier_id, rarity = :rarity WHERE id = :id
                """)
            .param("id", id)
            .param("item_modifier_id", modifierId)
            .param("rarity", rarity.ordinal())
            .update();
    }

    public boolean applyStormEnhance(
        long id,
        PersonageId personageId,
        int expectedLevel,
        long expectedRevision,
        int nextLevel
    ) {
        return jdbcClient.sql("""
                UPDATE item
                SET enhance_level = :next_level, enhance_revision = enhance_revision + 1
                WHERE id = :id
                  AND personage_id = :personage_id
                  AND enhance_level = :expected_level
                  AND enhance_revision = :expected_revision
                """)
            .param("id", id)
            .param("personage_id", personageId.value())
            .param("expected_level", expectedLevel)
            .param("expected_revision", expectedRevision)
            .param("next_level", nextLevel)
            .update() == 1;
    }

    public void deletePersonageAndMakeEquipFalse(long id) {
        jdbcClient.sql("UPDATE item SET personage_id = null, is_equipped = false WHERE id = :id")
            .param("id", id)
            .update();
    }

    private PersonageItem mapRow(ResultSet rs, int rowNum) throws SQLException {
        final var objectId = rs.getInt("item_object_id");
        final var object = itemObjectDao.getById(objectId).orElseThrow();
        final var modifierId = (Integer) rs.getObject("item_modifier_id");
        final var modifier = modifierId == null
            ? Optional.<ru.homyakin.seeker.game.item.models.Modifier>empty()
            : itemModifierDao.getById(modifierId).map(CatalogModifier::modifier);
        return new PersonageItem(
            rs.getLong("id"),
            objectId,
            object.object(),
            Optional.ofNullable(modifierId),
            modifier,
            ItemRarity.values()[rs.getInt("rarity")],
            Optional.ofNullable((Long) rs.getObject("personage_id")).map(PersonageId::from),
            rs.getBoolean("is_equipped"),
            rs.getInt("enhance_level"),
            rs.getLong("enhance_revision")
        );
    }

    private static final String SAVE_SQL = """
        INSERT INTO item (
            item_object_id, item_modifier_id, rarity, personage_id, is_equipped, enhance_level, enhance_revision
        )
        VALUES (
            :item_object_id, :item_modifier_id, :rarity, :personage_id, :is_equipped, :enhance_level, :enhance_revision
        )
        RETURNING id
        """;

    private static final String SELECT_SQL = """
        SELECT i.id, i.item_object_id, i.item_modifier_id, i.rarity, i.personage_id, i.is_equipped,
               i.enhance_level, i.enhance_revision
        FROM item i
        """;
}
