package ru.homyakin.seeker.game.item.database;

import java.sql.Array;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import javax.sql.DataSource;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.homyakin.seeker.game.item.catalog.ItemObjectRevisionPolicy;
import ru.homyakin.seeker.game.item.models.AttackType;
import ru.homyakin.seeker.game.item.models.DefenseType;
import ru.homyakin.seeker.game.item.models.ItemAttack;
import ru.homyakin.seeker.game.item.models.ItemDefense;
import ru.homyakin.seeker.game.item.models.CatalogItemObject;
import ru.homyakin.seeker.game.item.models.ItemObject;
import ru.homyakin.seeker.game.personage.models.PersonageSlot;
import ru.homyakin.seeker.utils.JsonUtils;

@Component
public class ItemObjectDao {
    private final JdbcClient jdbcClient;
    private final JsonUtils jsonUtils;
    private final DataSource dataSource;

    public ItemObjectDao(DataSource dataSource, JsonUtils jsonUtils) {
        this.jdbcClient = JdbcClient.create(dataSource);
        this.jsonUtils = jsonUtils;
        this.dataSource = dataSource;
    }

    public CatalogItemObject getRandomObject(PersonageSlot slot) {
        return jdbcClient.sql(RANDOM_OBJECT_SQL)
            .param("slot_id", slot.id)
            .query(this::mapRow)
            .optional()
            .orElseThrow();
    }

    public Optional<CatalogItemObject> getById(int id) {
        return jdbcClient.sql(GET_BY_ID_SQL)
            .param("id", id)
            .query(this::mapRow)
            .optional();
    }

    public Optional<CatalogItemObject> getAvailableById(int id) {
        return jdbcClient.sql(GET_AVAILABLE_BY_ID_SQL)
            .param("id", id)
            .query(this::mapRow)
            .optional();
    }

    public List<CatalogItemObject> listBySlot(PersonageSlot slot) {
        return jdbcClient.sql(LIST_BY_SLOT_SQL)
            .param("slot_id", slot.id)
            .query(this::mapRow)
            .list();
    }

    public List<CatalogItemObject> listAvailableBySlot(PersonageSlot slot) {
        return jdbcClient.sql(LIST_AVAILABLE_BY_SLOT_SQL)
            .param("slot_id", slot.id)
            .query(this::mapRow)
            .list();
    }

    @Transactional
    public void save(ItemObject itemObject, boolean acquisitionEnabledWhenInserted) {
        getByCodeForUpdate(itemObject.code())
            .filter(existing -> ItemObjectRevisionPolicy.invalidatesEnhancement(existing.object(), itemObject))
            .ifPresent(existing -> bumpEnhanceRevision(existing.id()));
        final var legacyAttack = itemObject.attacks().stream().findFirst();
        jdbcClient.sql(SAVE_SQL)
            .param("code", itemObject.code())
            .param("health", itemObject.health())
            .param("crit_chance", itemObject.critChance())
            .param("dodge_chance", itemObject.dodgeChance())
            .param("crit_multiplier", itemObject.critMultiplier())
            .param("speed", itemObject.speed())
            .param("base_threat", itemObject.baseThreat())
            .param("impact", itemObject.impact())
            .param("progression_version", itemObject.progressionVersion().name())
            .param("attack_parts", jsonUtils.mapToPostgresJson(itemObject.attacks()))
            .param("attack_type", legacyAttack.map(a -> a.attackType().name()).orElse(null))
            .param("attack_range", legacyAttack.map(ItemAttack::maxRange).orElse(null))
            .param("attack", legacyAttack.map(ItemAttack::attack).orElse(null))
            .param("defense_type", itemObject.defense().map(d -> d.defenseType().name()).orElse(null))
            .param("defense", itemObject.defense().map(ItemDefense::defense).orElse(null))
            .param("locale", jsonUtils.mapToPostgresJson(itemObject.locales()))
            .param("personage_slot_ids", personageSlotIdsArray(itemObject.slots()))
            .param("acquisition_enabled", acquisitionEnabledWhenInserted)
            .update();
    }

    public void setAcquisitionEnabledOnly(Set<String> codes) {
        if (codes.isEmpty()) {
            throw new IllegalArgumentException("At least one obtainable item object code must be specified");
        }
        jdbcClient.sql(SET_ACQUISITION_ENABLED_ONLY_SQL)
            .param("codes", codes)
            .update();
    }

    private Optional<CatalogItemObject> getByCodeForUpdate(String code) {
        return jdbcClient.sql(GET_BY_CODE_FOR_UPDATE_SQL)
            .param("code", code)
            .query(this::mapRow)
            .optional();
    }

    private void bumpEnhanceRevision(int itemObjectId) {
        final long maxRevision = jdbcClient.sql(MAX_ENHANCE_REVISION_SQL)
            .param("item_object_id", itemObjectId)
            .query((rs, _) -> rs.getLong("max_revision"))
            .single();
        if (maxRevision == Long.MAX_VALUE) {
            throw new IllegalStateException(
                "Cannot replace item object with exhausted enhance revision: " + itemObjectId
            );
        }
        jdbcClient.sql(BUMP_ENHANCE_REVISION_SQL)
            .param("item_object_id", itemObjectId)
            .update();
    }

    private Array personageSlotIdsArray(Set<PersonageSlot> slots) {
        final var ids = slots.stream().map(slot -> slot.id).toArray(Integer[]::new);
        try (Connection connection = dataSource.getConnection()) {
            return connection.createArrayOf("integer", ids);
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to create personage_slot_ids array", e);
        }
    }

    private CatalogItemObject mapRow(ResultSet rs, int rowNum) throws SQLException {
        final var attackType = rs.getString("attack_type");
        final var defenseType = rs.getString("defense_type");
        final var attackPartsJson = rs.getString("attack_parts");
        final List<ItemAttack> persistedParts = attackPartsJson == null
            ? List.of()
            : jsonUtils.fromString(attackPartsJson, JsonUtils.ITEM_ATTACKS);
        final List<ItemAttack> attacks = persistedParts.isEmpty() && attackType != null
            ? List.of(new ItemAttack(
                AttackType.valueOf(attackType),
                rs.getInt("attack_range"),
                rs.getInt("attack")
            ))
            : persistedParts;
        return new CatalogItemObject(
            rs.getInt("id"),
            new ItemObject(
                rs.getString("code"),
                extractSlots(rs.getArray("personage_slot_ids")),
                attacks,
                defenseType == null
                    ? Optional.empty()
                    : Optional.of(new ItemDefense(
                        DefenseType.valueOf(defenseType),
                        rs.getInt("defense")
                    )),
                rs.getInt("health"),
                rs.getInt("crit_chance"),
                rs.getInt("dodge_chance"),
                rs.getDouble("crit_multiplier"),
                rs.getInt("speed"),
                rs.getInt("base_threat"),
                rs.getInt("impact"),
                ru.homyakin.seeker.game.item.models.ItemProgressionVersion.valueOf(
                    rs.getString("progression_version")
                ),
                jsonUtils.fromString(rs.getString("locale"), JsonUtils.ITEM_OBJECT_LOCALE)
            ),
            rs.getBoolean("acquisition_enabled")
        );
    }

    private Set<PersonageSlot> extractSlots(Array array) throws SQLException {
        if (array == null) {
            return Set.of();
        }
        final var ids = (Integer[]) array.getArray();
        final var slots = new HashSet<PersonageSlot>();
        for (final var id : ids) {
            slots.add(PersonageSlot.findById(id));
        }
        return slots;
    }

    private static final String RANDOM_OBJECT_SQL = """
        SELECT * FROM item_object
        WHERE :slot_id = ANY(personage_slot_ids)
          AND acquisition_enabled
        ORDER BY random() LIMIT 1
        FOR SHARE
        """;

    private static final String GET_BY_ID_SQL = """
        SELECT * FROM item_object WHERE id = :id
        """;

    private static final String GET_AVAILABLE_BY_ID_SQL = """
        SELECT * FROM item_object WHERE id = :id AND acquisition_enabled FOR SHARE
        """;

    private static final String GET_BY_CODE_FOR_UPDATE_SQL = """
        SELECT * FROM item_object WHERE code = :code FOR UPDATE
        """;

    private static final String LIST_BY_SLOT_SQL = """
        SELECT * FROM item_object
        WHERE :slot_id = ANY(personage_slot_ids)
        ORDER BY id
        """;

    private static final String LIST_AVAILABLE_BY_SLOT_SQL = """
        SELECT * FROM item_object
        WHERE :slot_id = ANY(personage_slot_ids)
          AND acquisition_enabled
        ORDER BY id
        """;

    private static final String SAVE_SQL = """
        INSERT INTO item_object (
            code, health, crit_chance, dodge_chance, crit_multiplier, speed, base_threat,
            impact, progression_version, attack_parts,
            attack_type, attack_range, attack, defense_type, defense, locale, personage_slot_ids,
            acquisition_enabled
        ) VALUES (
            :code, :health, :crit_chance, :dodge_chance, :crit_multiplier, :speed, :base_threat,
            :impact, :progression_version, CAST(:attack_parts AS JSONB),
            :attack_type, :attack_range, :attack, :defense_type, :defense,
            CAST(:locale AS JSONB), :personage_slot_ids, :acquisition_enabled
        )
        ON CONFLICT (code) DO UPDATE SET
            health = EXCLUDED.health,
            crit_chance = EXCLUDED.crit_chance,
            dodge_chance = EXCLUDED.dodge_chance,
            crit_multiplier = EXCLUDED.crit_multiplier,
            speed = EXCLUDED.speed,
            base_threat = EXCLUDED.base_threat,
            impact = EXCLUDED.impact,
            progression_version = EXCLUDED.progression_version,
            attack_parts = EXCLUDED.attack_parts,
            attack_type = EXCLUDED.attack_type,
            attack_range = EXCLUDED.attack_range,
            attack = EXCLUDED.attack,
            defense_type = EXCLUDED.defense_type,
            defense = EXCLUDED.defense,
            locale = EXCLUDED.locale,
            personage_slot_ids = EXCLUDED.personage_slot_ids
        """;

    private static final String MAX_ENHANCE_REVISION_SQL = """
        SELECT COALESCE(MAX(enhance_revision), 0) AS max_revision
        FROM item
        WHERE item_object_id = :item_object_id
        """;

    private static final String BUMP_ENHANCE_REVISION_SQL = """
        UPDATE item
        SET enhance_revision = enhance_revision + 1
        WHERE item_object_id = :item_object_id
        """;

    private static final String SET_ACQUISITION_ENABLED_ONLY_SQL = """
        UPDATE item_object
        SET acquisition_enabled = code IN (:codes)
        """;
}
