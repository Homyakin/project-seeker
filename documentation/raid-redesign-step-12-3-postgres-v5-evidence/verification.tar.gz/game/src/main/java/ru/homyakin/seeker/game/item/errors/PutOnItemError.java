package ru.homyakin.seeker.game.item.errors;

import java.util.List;
import ru.homyakin.seeker.game.personage.models.PersonageSlot;

public sealed interface PutOnItemError {
    enum PersonageMissingItem implements PutOnItemError { INSTANCE }

    enum AlreadyEquipped implements PutOnItemError { INSTANCE }

    record NotEnoughSpaceOnPutOnItem(List<PersonageSlot> slots) implements PutOnItemError {
    }
}
