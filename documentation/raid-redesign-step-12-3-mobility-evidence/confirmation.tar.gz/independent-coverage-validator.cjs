const fs = require('fs');
const z = require('zlib');
const crypto = require('crypto');
const assert = require('assert/strict');
const path = require('path');
const root = process.argv[2] || '/tmp/seeker-mobility-fix.wba82w';
const repository = process.argv[3] || '/home/user/projects/project-seeker';
const runPrefix = process.argv[4] || '';
const mainSeed = Number(process.argv[5] || (runPrefix === 'final-' ? '2026110210' : '2026110207'));
const extraSeed = Number(process.argv[6] || (runPrefix === 'final-' ? '2026110211' : '2026110208'));
assert(Number.isSafeInteger(mainSeed) && Number.isSafeInteger(extraSeed));
const originFile = process.argv[7] || `${root}/class-origins.json`;
const layers = [{name:'main', conditions:79, seed:mainSeed}, {name:'equal', conditions:9, seed:mainSeed},
  {name:'extra', conditions:69, seed:extraSeed}];
const read = f => JSON.parse(fs.readFileSync(f, 'utf8'));
const unzip = f => z.gunzipSync(fs.readFileSync(f)).toString('utf8');
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const hash = s => { let value=0; for (let i=0; i<s.length; i++) value = (Math.imul(value,31)+s.charCodeAt(i))|0; return value; };
const u64 = x => BigInt.asUintN(64,x);
const seedFor = (rootSeed,group,pair) => {
  let x=u64(BigInt(rootSeed)+BigInt(hash(group))+0x9e3779b97f4a7c15n*BigInt(pair+1));
  x=u64((x^(x>>30n))*0xbf58476d1ce4e5b9n);
  x=u64((x^(x>>27n))*0x94d049bb133111ebn);
  return BigInt.asIntN(64,x^(x>>31n));
};
const expectedFiles = layers.flatMap(l => ['before','after'].flatMap(p => [
  `${root}/${runPrefix}${p}-${l.name}-summary.json`, `${root}/${runPrefix}${p}-${l.name}-cases.json.gz`,
  `${root}/${runPrefix}${p}-${l.name}-raw.jsonl.gz`]));
const missing=expectedFiles.filter(f=>!fs.existsSync(f));
if(missing.length) { console.log(JSON.stringify({status:'waiting', missing},null,2)); process.exit(0); }
const origin=read(originFile);
const originChecks=[];
for(const [name,metadata] of Object.entries(origin)) {
  if(name==='classpath') continue;
  assert(metadata.origin.startsWith('file:'),name);
  const directory=new URL(metadata.origin).pathname;
  const file=path.join(directory, name.replaceAll('.','/')+'.class');
  assert.equal(sha(file), metadata.sha256, `${name} actual class bytes`);
  if(!name.endsWith('Step123BattleRunner')) assert.equal(directory,`${repository}/game/target/classes/`,name);
  originChecks.push({name, origin:metadata.origin, sha256:metadata.sha256});
}
const allowedHelpers=new Set(['DurationDamageScale','EqualBudgetBalanceStudy','IndependentBalanceStudy',
  'MobilityBalanceStudy','MobilityStudyOrigin','Step123BattleRunner']);
const walk=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]);
const helperClasses=walk(`${root}/classes`).filter(f=>f.endsWith('.class'));
for(const file of helperClasses) assert(allowedHelpers.has(path.basename(file).split('$')[0].replace('.class','')),file);
const runner=fs.readFileSync(`${root}/source/ru/homyakin/seeker/game/battle/Step123BattleRunner.java`,'utf8');
assert(runner.includes('if (!Boolean.getBoolean("mobility.audit.old")) return equipment.personage(level, disabled);'));
assert(runner.includes('BattlePersonage.forScalingSkillsV2Combat('));
assert(runner.includes('new BattleContext(firstTeam, secondTeam, random, BattleTempoVersion.ACCELERATED_V1)'));
assert(runner.includes('case SCALING_SKILLS_V3 -> BattlePersonage.forScalingSkillsV3Combat('));
const runnerClass=fs.readFileSync(`${root}/classes/ru/homyakin/seeker/game/battle/Step123BattleRunner.class`);
const gearClass=fs.readFileSync(`${root}/classes/ru/homyakin/seeker/game/battle/Step123BattleRunner$Gear.class`);
for(const token of ['mobility.audit.old','forScalingSkillsV2Combat','ACCELERATED_V1']) {
  assert(runnerClass.includes(Buffer.from(token)),`compiled runner references ${token}`);
}
for(const token of ['forScalingSkillsV3Combat','EquipmentCatalogRelease','skillFormulaVersion']) {
  assert(gearClass.includes(Buffer.from(token)),`compiled gear references ${token}`);
}
const release=fs.readFileSync(`${repository}/game/src/main/java/ru/homyakin/seeker/game/item/catalog/EquipmentCatalogRelease.java`,'utf8');
assert(/SCALING_V5 = new EquipmentCatalogRelease\([\s\S]*?SkillFormulaVersion\.SCALING_SKILLS_V3/.test(release));
const objectText=fs.readFileSync(`${repository}/game/src/main/resources/game-data/catalog/scaling_v5/item_objects.toml`,'utf8');
const slots=new Map();
for(const block of objectText.split('[[item]]').slice(1)) {
  const code=block.match(/^\s*code\s*=\s*"([^"]+)"/m)?.[1];
  const slotLine=block.match(/^slots\s*=\s*\[([^\]]+)\]/m)?.[1];
  assert(code&&slotLine);
  slots.set(code,[...slotLine.matchAll(/"([^"]+)"/g)].map(x=>x[1]));
}
const rarityCost={COMMON:0,UNCOMMON:150,RARE:450,EPIC:975,LEGENDARY:1725};
const rarityPoints={COMMON:0,UNCOMMON:1,RARE:2,EPIC:3,LEGENDARY:4};
const fields=['rounds','actions','attempts','movementTurns','firstDeathRound','healing','reactionDamage','accumulationDischarges','hitAndRunWindows'];
let observations=0, numbers=0, manifestMembers=0, pairedVersionSeeds=0, equalCosts=0;
const details=[];
const phaseFacts=[];
for(const layer of layers) {
  let beforeCases;
  let beforeSeedDigest;
  for(const phase of ['before','after']) {
    const prefix=`${root}/${runPrefix}${phase}-${layer.name}`;
    const data=read(`${prefix}-summary.json`);
    const cases=JSON.parse(unzip(`${prefix}-cases.json.gz`));
    // Java Set iteration order is not an input difference; preserve every other exported field.
    for(const definition of cases) definition.case.disabledLeft.sort();
    assert.equal(data.catalog,'SCALING_V5');
    assert.equal(data.combat,phase==='before'?'SCALING_SKILLS_V2':'SCALING_SKILLS_V3');
    assert.equal(data.numerator,7); assert.equal(data.denominator,4); assert.equal(data.factor,1.75);
    assert.equal(data.rootSeed,layer.seed); assert.equal(data.conditions,layer.conditions);
    assert.equal(data.pairsPerCondition,500); assert.equal(data.battles,layer.conditions*1000);
    assert.equal(cases.length,layer.conditions); assert.equal(data.summaries.length,layer.conditions);
    assert.equal(data.timeouts,0); assert.equal(data.forcedMoveViolations,0);
    if(phase==='before') beforeCases=cases;
    else assert.deepEqual(cases,beforeCases,`${layer.name} identical complete manifests`);
    const definitions=new Map(cases.map(x=>[x.case.code,x]));
    assert.equal(definitions.size,cases.length);
    for(const definition of cases) {
      for(const side of ['left','right']) {
        let gold=0;
        assert.equal(definition[`${side}Equipment`].length,definition.case[side].length);
        for(const member of definition[`${side}Equipment`]) {
          manifestMembers++;
          assert.equal(member.catalog,'SCALING_V5');
          let points=0;
          const occupied=[];
          for(const item of member.items) {
            assert.equal(item.level,definition.case.level);
            const itemSlots=slots.get(item.code); assert(itemSlots,item.code);
            occupied.push(...itemSlots);
            gold+=100*itemSlots.length+rarityCost[item.rarity];
            const expectedPoints=item.skill==='NONE'?0:rarityPoints[item.rarity]*itemSlots.length;
            assert.equal(item.points,expectedPoints);
            points+=expectedPoints;
          }
          assert.equal(occupied.length,7); assert.equal(new Set(occupied).size,7);
          assert.equal(member.actualSkillPoints,points);
        }
        assert.equal(definition[`${side}NominalGold`],gold,`${definition.case.code} ${side} nominal gold`);
      }
      if(layer.name==='equal'||definition.case.family==='HEAVY_EQUAL_GOLD_RESPONSE') {
        assert.equal(definition.leftNominalGold,definition.rightNominalGold,definition.case.code);
        equalCosts++;
      }
    }
    const groups=new Map();
    const seedDigest=crypto.createHash('sha256');
    for(const line of unzip(`${prefix}-raw.jsonl.gz`).trim().split('\n')) {
      const r=JSON.parse(line,(k,v,context)=>k==='seed'?BigInt(context.source):v);
      const s=r.sample;
      const d=definitions.get(r.case); assert(d,r.case);
      assert.equal(r.numerator,7);
      assert(Number.isInteger(s.pair)&&s.pair>=0&&s.pair<500); assert.equal(typeof s.reverse,'boolean');
      assert.equal(s.seed,seedFor(layer.seed,d.case.seedGroup,s.pair));
      seedDigest.update(`${r.case}:${s.pair}:${s.reverse}:${s.seed}\n`);
      assert.equal(s.actions,s.left.actions+s.right.actions);
      assert.equal(s.attempts,s.left.attempts+s.right.attempts);
      assert.equal(s.movementTurns,s.left.movementTurns+s.right.movementTurns);
      assert.equal(s.healing,s.left.healing+s.right.healing);
      assert.equal(s.forcedMoveViolations,0); assert(s.maxForcedDistance<=1); assert(s.rounds<=data.maxRounds);
      if(!groups.has(r.case)) groups.set(r.case,[]);
      groups.get(r.case).push(s);
      observations++;
    }
    assert.equal(groups.size,layer.conditions);
    assert.equal([...groups.values()].reduce((a,v)=>a+v.length,0),data.battles);
    for(const summary of data.summaries) {
      const values=groups.get(summary.case); assert(values);
      assert.equal(values.length,1000); assert.equal(summary.battles,1000); assert.equal(summary.pairs,500);
      assert.equal(values.filter(s=>s.reverse).length,500);
      assert.equal(new Set(values.map(s=>`${s.pair}:${s.reverse}`)).size,1000);
      for(const [field,outcome] of [['wins','WIN'],['losses','LOSS'],['draws','DRAW'],['timeouts','TIMEOUT']]) {
        assert.equal(summary[field],values.filter(s=>s.outcome===outcome).length); numbers++;
      }
      for(const field of fields) {
        const a=values.map(s=>s[field]).sort((x,y)=>x-y);
        const expected={mean:a.reduce((x,y)=>x+y,0)/1000,median:(a[499]+a[500])/2,p95:a[949],min:a[0],max:a[999]};
        for(const [stat,value] of Object.entries(expected)) { assert(Math.abs(summary[field][stat]-value)<=1e-9,`${prefix}:${summary.case}:${field}:${stat}`); numbers++; }
      }
      if(phase==='after'&&layer.name==='extra') details.push({case:summary.case, wins:summary.wins,
        battles:summary.battles, medianRounds:summary.rounds.median, hitAndRunWindows:summary.hitAndRunWindows.mean});
    }
    const digest=seedDigest.digest('hex');
    if(phase==='before') beforeSeedDigest=digest;
    else {assert.equal(digest,beforeSeedDigest); pairedVersionSeeds+=data.battles;}
    phaseFacts.push({phase, layer:layer.name, formula:data.combat, battles:data.battles, seedDigest:digest});
  }
}
assert.equal(observations,314000);
console.log(JSON.stringify({status:'PASS',runPrefix,mainSeed,extraSeed,originFile,
  observations,numericChecks:numbers,manifestMembers,pairedVersionSeeds,
  equalCostDefinitionsAcrossPhases:equalCosts,allNominalPricesIndependentlyRecomputed:true,
  completeManifestsIdenticalAcrossVersions:true,onlyCanonicalizedSetField:'case.disabledLeft order',
  noTimeoutsOrMovementViolations:true,
  productionEngineClassesVerified:originChecks,helperClassCount:helperClasses.length,noProductionClassOverlay:true,
  phaseFacts,afterExtra:details},null,2));
