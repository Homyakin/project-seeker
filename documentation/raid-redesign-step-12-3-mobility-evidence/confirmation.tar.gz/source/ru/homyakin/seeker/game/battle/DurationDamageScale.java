package ru.homyakin.seeker.game.battle;

import java.util.Map;

/** Metadata only. Damage is calculated exclusively by production BattleTempoVersion. */
final class DurationDamageScale {
    static final int NUMERATOR = 7;
    private DurationDamageScale() { }
    static double factor() { return NUMERATOR / 4.0; }
    static Map<String, Object> audit() {
        return Map.of("kind", "metadata-only", "damageSinkInstrumentation", false,
            "actualTempo", "ACCELERATED_V1", "engine", "game/target/classes");
    }
}
