package ru.homyakin.seeker.game.battle;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.ToLongFunction;
import java.util.regex.Pattern;
import java.util.zip.GZIPOutputStream;
import ru.homyakin.seeker.game.battle.Step123BattleRunner.Gear;
import ru.homyakin.seeker.game.battle.Step123ReferenceTeams.Specialization;
import ru.homyakin.seeker.game.battle.Step123ReferenceTeams.Tier;
import ru.homyakin.seeker.game.battle.Step12RepresentativeBuilds.Assignment;
import ru.homyakin.seeker.game.battle.Step12RepresentativeBuilds.Build;
import ru.homyakin.seeker.game.battle.simulation.Step12SimulationFixtures.MixedBuild;
import ru.homyakin.seeker.game.battle.simulation.Step12SimulationFixtures.RoleBuild;
import ru.homyakin.seeker.game.battle.simulation.Step12SimulationFixtures.V3Build;
import ru.homyakin.seeker.game.battle.skill.active_impl.ActiveEnum;
import ru.homyakin.seeker.game.battle.targeting.TargetingTactic;
import ru.homyakin.seeker.game.item.catalog.EquipmentCatalogVersion;
import ru.homyakin.seeker.game.item.models.Item;
import ru.homyakin.seeker.game.item.models.ItemRarity;

/** Standalone diagnostic only: compiled into a temporary class overlay, not the game. */
public final class MobilityBalanceStudy {
    private static final ObjectMapper JSON = new ObjectMapper();
    private static final int MAX_ROUNDS = 10000;
    private static final List<Tier> TIERS = List.of(Tier.BEGINNER, Tier.MID, Tier.STRONG);

    private MobilityBalanceStudy() { }

    public static void main(String[] args) throws Exception {
        if (args.length != 1) throw new IllegalArgumentException("Specify unused output prefix");
        final Path prefix = Path.of(args[0]).toAbsolutePath();
        final int pairs = Integer.getInteger("tempo.pairs", 100);
        final long root = Long.getLong("tempo.seed", 2026110204L);
        final var economy = Step123ReferenceEconomy.configured();
        final var filter = Pattern.compile(System.getProperty("tempo.filter", ".*"));
        final var selected = cases().stream().filter(c -> filter.matcher(c.code()).find()).toList();
        if (pairs < 2 || selected.isEmpty()) throw new IllegalArgumentException("Invalid run");
        final var summaries = new ArrayList<Map<String, Object>>();
        final var definitions = new ArrayList<Map<String, Object>>();
        long battles = 0;
        long violations = 0;
        long timeouts = 0;
        try (final var raw = new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(
            Files.newOutputStream(Path.of(prefix + "-raw.jsonl.gz"), StandardOpenOption.CREATE_NEW)), StandardCharsets.UTF_8))) {
            for (final var c : selected) {
                final var observations = new ArrayList<Sample>();
                for (int pair = 0; pair < pairs; pair++) {
                    final long seed = iterationSeed(root + c.seedGroup().hashCode(), pair);
                    for (final boolean reverse : List.of(false, true)) {
                        final var o = Step123BattleRunner.observe(c.left(), c.right(), c.level(), seed,
                            reverse, MAX_ROUNDS, c.disabledLeft(), Set.of());
                        final var audit = Step123CorrectionsStudy.audit(o.initialPositions(), o.events(), reverse);
                        final long firstDeath = o.events().stream().filter(e -> e instanceof BattleEvent.PersonageDefeated)
                            .mapToLong(BattleEvent::round).min().orElse(-1);
                        final long reaction = o.events().stream().mapToLong(e -> reactionDamage(e)).sum();
                        final long discharges = o.events().stream().filter(e -> e instanceof BattleEvent.SkillChargeChanged charge
                            && charge.discharged()).count();
                        final var s = new Sample(pair, reverse, seed, o.outcome(), o.rounds(),
                            o.left().actions() + o.right().actions(), o.left().attempts() + o.right().attempts(),
                            o.left().movementTurns() + o.right().movementTurns(), firstDeath,
                            o.left().healing() + o.right().healing(), reaction, discharges,
                            o.events().stream().filter(e -> e instanceof BattleEvent.SkillWindowUsed used && used.skill() == ActiveEnum.HIT_AND_RUN).count(),
                            audit.forcedMoves(), audit.violations(), audit.maxDistance(), o.left(), o.right());
                        raw.write(JSON.writeValueAsString(map("case", c.code(), "numerator", DurationDamageScale.NUMERATOR,
                            "sample", s)));
                        raw.newLine();
                        observations.add(s);
                        battles++;
                        violations += audit.violations();
                        timeouts += o.outcome().equals("TIMEOUT") ? 1 : 0;
                    }
                }
                final var summary = map("case", c.code(), "family", c.family(), "tier", c.tier(),
                    "level", c.level(), "size", c.left().size(), "pairs", pairs, "battles", observations.size(),
                    "wins", observations.stream().filter(s -> s.outcome().equals("WIN")).count(),
                    "losses", observations.stream().filter(s -> s.outcome().equals("LOSS")).count(),
                    "draws", observations.stream().filter(s -> s.outcome().equals("DRAW")).count(),
                    "timeouts", observations.stream().filter(s -> s.outcome().equals("TIMEOUT")).count(),
                    "rounds", stats(observations, Sample::rounds), "actions", stats(observations, Sample::actions),
                    "attempts", stats(observations, Sample::attempts), "movementTurns", stats(observations, Sample::movementTurns),
                    "firstDeathRound", stats(observations, Sample::firstDeathRound), "healing", stats(observations, Sample::healing),
                    "reactionDamage", stats(observations, Sample::reactionDamage),
                    "accumulationDischarges", stats(observations, Sample::accumulationDischarges),
                    "hitAndRunWindows", stats(observations, Sample::hitAndRunWindows));
                summaries.add(summary);
                definitions.add(map("case", c, "leftEquipment", manifest(c.left(), c.level()),
                    "rightEquipment", manifest(c.right(), c.level()),
                    "leftNominalGold", economy.nominalGold(c.left().stream().flatMap(g -> g.items(c.level()).stream()).toList()),
                    "rightNominalGold", economy.nominalGold(c.right().stream().flatMap(g -> g.items(c.level()).stream()).toList())));
                System.err.println("factor=" + DurationDamageScale.factor() + " " + c.code() + " " + summaries.size() + "/" + selected.size());
            }
        }
        try (final var out = new GZIPOutputStream(Files.newOutputStream(Path.of(prefix + "-cases.json.gz"), StandardOpenOption.CREATE_NEW))) {
            JSON.writeValue(out, definitions);
        }
        final var output = map("purpose", "Independent multi-agent balance audit; no live settings changed and no universal 50/50 target",
            "catalog", "SCALING_V5", "combat", Boolean.getBoolean("mobility.audit.old") ? "SCALING_SKILLS_V2" : "SCALING_SKILLS_V3", "numerator", DurationDamageScale.NUMERATOR,
            "denominator", 4, "factor", DurationDamageScale.factor(), "rootSeed", root, "pairsPerCondition", pairs,
            "filter", filter.pattern(), "conditions", selected.size(), "battles", battles, "timeouts", timeouts,
            "forcedMoveViolations", violations, "maxRounds", MAX_ROUNDS,
            "seeds", "SplitMix64(rootSeed + JavaStringHash(seedGroup), pairIndex); identical across factors, both side orders",
            "quantiles", "Median averages central pair; p95 nearest rank ceil(0.95*n). Timeouts retained at maxRounds",
            "units", "Rounds are initiative ticks, actions are performed turns, not seconds; firstDeath=-1 if absent",
            "scope", "Targeted audit: role profiles2/4, controlled mobile1/2/4/8; full RARE14/LEGENDARY28 are separate diagnostics. Explicit cases may have unequal budgets; manifests and nominal costs are authoritative. No external effects",
            "scaling", "Round-half-up final post-defense/post-variance damage once at both HP sinks; expected normal damage also scaled; healing unchanged",
            "sinkAudit", DurationDamageScale.audit(), "summaries", summaries);
        try (final var out = Files.newOutputStream(Path.of(prefix + "-summary.json"), StandardOpenOption.CREATE_NEW)) {
            JSON.writerWithDefaultPrettyPrinter().writeValue(out, output);
        }
        if (violations != 0 || timeouts != 0) throw new IllegalStateException("Movement violation or timeout: retained in output");
    }

    static List<Case> cases() {
        final var result = new ArrayList<Case>();
        final var strong = Tier.STRONG;
        final var guardian = gear(Step12RepresentativeBuilds.role(RoleBuild.GUARDIAN), strong);
        final var raiderBuild = Step12RepresentativeBuilds.mixed(MixedBuild.RAIDER);
        final var bruiserBuild = Step12RepresentativeBuilds.role(RoleBuild.BRUISER);
        for (final var rarity : List.of(ItemRarity.RARE, ItemRarity.EPIC, ItemRarity.LEGENDARY)) {
            final var raider = new Gear(raiderBuild.withAssignments(Map.of(
                "rapier", new Assignment(ActiveEnum.PENETRATION, rarity),
                "dirk", new Assignment(ActiveEnum.PENETRATION, rarity),
                "hood", new Assignment(ActiveEnum.HIT_AND_RUN, rarity),
                "cloth_boots", new Assignment(ActiveEnum.HIT_AND_RUN, rarity)
            )), EquipmentCatalogVersion.SCALING_V5);
            final var response = new Gear(bruiserBuild.withAssignments(Map.of(
                "sledgehammer", new Assignment(ActiveEnum.BERSERK, rarity),
                "breastplate", new Assignment(ActiveEnum.SELF_HEAL, rarity),
                "leather_chausses", new Assignment(ActiveEnum.SELF_HEAL, rarity),
                "leather_gloves", new Assignment(ActiveEnum.FEINT, rarity)
            )), EquipmentCatalogVersion.SCALING_V5);
            for (final int level : List.of(0, 6, 20)) {
                for (final int size : List.of(3, 7, 15)) {
                    final var left = new ArrayList<Gear>(); left.add(guardian);
                    final var right = new ArrayList<Gear>(); right.add(guardian);
                    for (int i = 1; i < size; i++) { left.add(raider); right.add(response); }
                    final var name = "MOBILITY_HEAVY_" + rarity + "_N" + size + "_L" + level;
                    result.add(new Case(name, "HEAVY_EQUAL_GOLD_RESPONSE", rarity.name(), level, name, left, right, Set.of()));
                }
            }
        }
        final var ordinaryRaider = gear(raiderBuild, strong);
        final var ordinaryHeal = new Gear(bruiserBuild.withAssignments(Map.of(
            "sledgehammer", new Assignment(ActiveEnum.BERSERK, ItemRarity.RARE),
            "breastplate", new Assignment(ActiveEnum.SELF_HEAL, ItemRarity.RARE)
        )), EquipmentCatalogVersion.SCALING_V5);
        for (final int size : List.of(3, 7, 15)) {
            final var left = new ArrayList<Gear>(); left.add(guardian);
            final var right = new ArrayList<Gear>(); right.add(guardian);
            for (int i = 1; i < size; i++) { left.add(ordinaryRaider); right.add(ordinaryHeal); }
            final var group = "MOBILITY_RAIDER_CAUSAL_N" + size;
            for (final var disabled : List.of(Set.<ActiveEnum>of(), Set.of(ActiveEnum.HIT_AND_RUN),
                Set.of(ActiveEnum.PENETRATION), Set.of(ActiveEnum.HIT_AND_RUN, ActiveEnum.PENETRATION))) {
                final var suffix = disabled.isEmpty() ? "BOTH_ON"
                    : disabled.size() == 2 ? "BOTH_OFF"
                    : disabled.contains(ActiveEnum.HIT_AND_RUN) ? "ONLY_PENETRATION" : "ONLY_HIT_AND_RUN";
                result.add(new Case(group + "_" + suffix, "RAIDER_CAUSAL", "STRONG", 6, group, left, right, disabled));
            }
        }
        final var mobile = Step123ReferenceTeams.specializedTeam(strong, Specialization.MOBILE).members();
        final var support = Step123BattleStudy.historicalV3Build(V3Build.CROSSBOW_SUPPORT).withPosition(Position.MID);
        for (final int points : List.of(1, 2, 4, 8)) {
            final var assignments = switch (points) {
                case 1 -> Map.of("boots", new Assignment(ActiveEnum.HIT_AND_RUN, ItemRarity.UNCOMMON));
                case 2 -> Map.of("boots", new Assignment(ActiveEnum.HIT_AND_RUN, ItemRarity.RARE));
                case 4 -> Map.of("boots", new Assignment(ActiveEnum.HIT_AND_RUN, ItemRarity.RARE),
                    "leather_helm", new Assignment(ActiveEnum.HIT_AND_RUN, ItemRarity.RARE));
                case 8 -> Map.of("boots", new Assignment(ActiveEnum.HIT_AND_RUN, ItemRarity.LEGENDARY),
                    "leather_helm", new Assignment(ActiveEnum.HIT_AND_RUN, ItemRarity.LEGENDARY));
                default -> throw new IllegalStateException();
            };
            final var front = new Gear(mobile.getFirst().build().withAssignments(assignments), EquipmentCatalogVersion.SCALING_V5);
            final var left = List.of(front, mobile.get(1), mobile.get(2));
            for (final var opponent : List.of(V3Build.BRUISER_BLUNT, V3Build.BREAKER_CLOSE_SLASH, V3Build.RANGER_PIERCE)) {
                final var group = "MOBILITY_POINT_CAUSAL_VS_" + opponent;
                final var right = gears(List.of(Step123BattleStudy.historicalV3Build(opponent).withPosition(Position.FRONT), support, support));
                for (final boolean off : List.of(false, true)) {
                    result.add(new Case(group + "_P" + points + (off ? "_OFF" : "_ON"),
                        "MOBILE_POINT_CAUSAL", "POINTS_" + points, 6, group, left, right,
                        off ? Set.of(ActiveEnum.HIT_AND_RUN) : Set.of()));
                }
            }
        }
        for (final var tier : List.of(Tier.MID, Tier.STRONG)) {
            for (final var opponent : List.of(RoleBuild.RANGER_PHYSICAL, RoleBuild.RANGER_MAGICAL, RoleBuild.TACTICIAN_MAGICAL)) {
                final var assassin = gear(Step12RepresentativeBuilds.role(RoleBuild.ASSASSIN), tier);
                final var left = List.of(gear(Step12RepresentativeBuilds.role(RoleBuild.GUARDIAN), tier), assassin, assassin);
                final var name = "MOBILITY_ASSASSIN_NICHE_" + tier + "_VS_" + opponent;
                result.add(new Case(name, "ASSASSIN_NICHE", tier.name(), tier.level(), name,
                    left, protectedTeam(Step12RepresentativeBuilds.role(opponent), tier), Set.of()));
            }
        }
        result.sort(Comparator.comparing(Case::code));
        if (result.stream().map(Case::code).distinct().count() != result.size()) throw new IllegalStateException("Duplicate case");
        return List.copyOf(result);
    }

    private static List<Gear> gears(List<Build> builds) {
        return builds.stream().map(build -> new Gear(build, EquipmentCatalogVersion.SCALING_V5)).toList();
    }

    private static List<Gear> protectedTeam(Build tested, Tier tier) {
        final var guardian = Step12RepresentativeBuilds.role(RoleBuild.GUARDIAN);
        final var ranger = Step12RepresentativeBuilds.role(RoleBuild.RANGER_PHYSICAL).withPosition(Position.MID);
        if (tested.position() == Position.BACK) tested = tested.withPosition(Position.MID);
        return List.of(gear(guardian, tier), gear(tested, tier), gear(ranger, tier));
    }

    private static Gear gear(Build build, Tier tier) {
        final var assignments = new LinkedHashMap<String, Assignment>();
        if (tier.profilePoints() > 0) for (final var item : build.items(0)) {
            final var original = build.assignments().get(item.object().code());
            if (original == null) continue;
            final int points = original.rarity().skillPoints() * tier.profilePoints() / 4;
            if (points == 0) throw new IllegalArgumentException("Unsupported profile carrier");
            final var rarity = Arrays.stream(ItemRarity.values()).filter(r -> r.skillPoints() == points).findFirst().orElseThrow();
            assignments.put(item.object().code(), new Assignment(original.skill(), rarity));
        }
        return new Gear(build.withAssignments(assignments), EquipmentCatalogVersion.SCALING_V5);
    }

    private static void add(List<Case> cases, String name, String family, Tier tier,
                            List<Gear> left, List<Gear> right, Set<ActiveEnum> disabled) {
        final String code = name + "_" + tier;
        final String group = name.replace("_OFF", "").replace("_ON", "") + "_" + tier;
        cases.add(new Case(code, family, tier.name(), tier.level(), group, left, right, disabled));
    }

    private static List<Map<String, Object>> manifest(List<Gear> members, int level) {
        return members.stream().map(g -> map("build", g.build(), "catalog", g.catalog(),
            "actualSkillPoints", g.items(level).stream().mapToInt(Item::skillPoints).sum(),
            "items", g.items(level).stream().map(i -> map("code", i.object().code(), "rarity", i.rarity(),
                "level", i.enhanceLevel(), "points", i.modifier().isPresent() ? i.skillPoints() : 0,
                "skill", i.modifier().map(m -> m.activeEnum().name()).orElse("NONE"),
                "health", i.health(), "speed", i.speed(), "attacks", i.itemAttacks(),
                "defense", i.itemDefense().map(d -> map("type", d.defenseType(), "value", d.defense())).orElse(null))).toList())).toList();
    }

    private static long reactionDamage(BattleEvent event) {
        if (event instanceof BattleEvent.ScalingSkillDamage d && Set.of(ActiveEnum.THORNS, ActiveEnum.COUNTER_ATTACK).contains(d.skill())) return d.damageTaken();
        if (event instanceof BattleEvent.SkillDamage d && Set.of(ActiveEnum.THORNS, ActiveEnum.COUNTER_ATTACK).contains(d.skill())) return d.damageTaken();
        return 0;
    }

    private static Map<String, Object> stats(List<Sample> samples, ToLongFunction<Sample> field) {
        final var values = samples.stream().mapToLong(field).sorted().toArray();
        final int n = values.length;
        return map("median", n % 2 == 0 ? (values[n/2-1] + values[n/2]) / 2.0 : (double) values[n/2],
            "p95", values[(int) Math.ceil(0.95 * n) - 1], "mean", Arrays.stream(values).average().orElseThrow(),
            "min", values[0], "max", values[n-1]);
    }

    private static long iterationSeed(long seed, int iteration) {
        long mixed = seed + 0x9e3779b97f4a7c15L * (iteration + 1L);
        mixed = (mixed ^ mixed >>> 30) * 0xbf58476d1ce4e5b9L;
        mixed = (mixed ^ mixed >>> 27) * 0x94d049bb133111ebL;
        return mixed ^ mixed >>> 31;
    }

    private static Map<String, Object> map(Object... pairs) {
        final var result = new LinkedHashMap<String, Object>();
        for (int i = 0; i < pairs.length; i += 2) result.put((String) pairs[i], pairs[i+1]);
        return result;
    }

    record Case(String code, String family, String tier, int level, String seedGroup,
                List<Gear> left, List<Gear> right, Set<ActiveEnum> disabledLeft) { }

    record Sample(int pair, boolean reverse, long seed, String outcome, int rounds, long actions,
                  long attempts, long movementTurns, long firstDeathRound, long healing, long reactionDamage,
                  long accumulationDischarges, long hitAndRunWindows, long forcedMoves, long forcedMoveViolations, long maxForcedDistance,
                  Step12RepresentativeBattleRunner.TeamMeasure left, Step12RepresentativeBattleRunner.TeamMeasure right) { }
}

