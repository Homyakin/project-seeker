package ru.homyakin.seeker.game.battle;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.ToLongFunction;
import java.util.regex.Pattern;
import java.util.zip.GZIPOutputStream;
import ru.homyakin.seeker.game.battle.Step123BattleRunner.Gear;
import ru.homyakin.seeker.game.battle.Step123ReferenceTeams.Specialization;
import ru.homyakin.seeker.game.battle.Step123ReferenceTeams.Tier;
import ru.homyakin.seeker.game.battle.Step12RepresentativeBuilds.Assignment;
import ru.homyakin.seeker.game.battle.Step12RepresentativeBuilds.Build;
import ru.homyakin.seeker.game.battle.simulation.Step12SimulationFixtures.MixedBuild;
import ru.homyakin.seeker.game.battle.simulation.Step12SimulationFixtures.RoleBuild;
import ru.homyakin.seeker.game.battle.simulation.Step12SimulationFixtures.V3Build;
import ru.homyakin.seeker.game.battle.skill.active_impl.ActiveEnum;
import ru.homyakin.seeker.game.battle.targeting.TargetingTactic;
import ru.homyakin.seeker.game.item.catalog.EquipmentCatalogVersion;
import ru.homyakin.seeker.game.item.models.Item;
import ru.homyakin.seeker.game.item.models.ItemRarity;

/** Standalone diagnostic only: compiled into a temporary class overlay, not the game. */
public final class IndependentBalanceStudy {
    private static final ObjectMapper JSON = new ObjectMapper();
    private static final int MAX_ROUNDS = 10000;
    private static final List<Tier> TIERS = List.of(Tier.BEGINNER, Tier.MID, Tier.STRONG);

    private IndependentBalanceStudy() { }

    public static void main(String[] args) throws Exception {
        if (args.length != 1) throw new IllegalArgumentException("Specify unused output prefix");
        final Path prefix = Path.of(args[0]).toAbsolutePath();
        final int pairs = Integer.getInteger("tempo.pairs", 100);
        final long root = Long.getLong("tempo.seed", 2026110204L);
        final var economy = Step123ReferenceEconomy.configured();
        final var filter = Pattern.compile(System.getProperty("tempo.filter", ".*"));
        final var selected = cases().stream().filter(c -> filter.matcher(c.code()).find()).toList();
        if (pairs < 2 || selected.isEmpty()) throw new IllegalArgumentException("Invalid run");
        final var summaries = new ArrayList<Map<String, Object>>();
        final var definitions = new ArrayList<Map<String, Object>>();
        long battles = 0;
        long violations = 0;
        long timeouts = 0;
        try (final var raw = new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(
            Files.newOutputStream(Path.of(prefix + "-raw.jsonl.gz"), StandardOpenOption.CREATE_NEW)), StandardCharsets.UTF_8))) {
            for (final var c : selected) {
                final var observations = new ArrayList<Sample>();
                for (int pair = 0; pair < pairs; pair++) {
                    final long seed = iterationSeed(root + c.seedGroup().hashCode(), pair);
                    for (final boolean reverse : List.of(false, true)) {
                        final var o = Step123BattleRunner.observe(c.left(), c.right(), c.level(), seed,
                            reverse, MAX_ROUNDS, c.disabledLeft(), Set.of());
                        final var audit = Step123CorrectionsStudy.audit(o.initialPositions(), o.events(), reverse);
                        final long firstDeath = o.events().stream().filter(e -> e instanceof BattleEvent.PersonageDefeated)
                            .mapToLong(BattleEvent::round).min().orElse(-1);
                        final long reaction = o.events().stream().mapToLong(e -> reactionDamage(e)).sum();
                        final long discharges = o.events().stream().filter(e -> e instanceof BattleEvent.SkillChargeChanged charge
                            && charge.discharged()).count();
                        final var s = new Sample(pair, reverse, seed, o.outcome(), o.rounds(),
                            o.left().actions() + o.right().actions(), o.left().attempts() + o.right().attempts(),
                            o.left().movementTurns() + o.right().movementTurns(), firstDeath,
                            o.left().healing() + o.right().healing(), reaction, discharges,
                            o.events().stream().filter(e -> e instanceof BattleEvent.SkillWindowUsed used && used.skill() == ActiveEnum.HIT_AND_RUN).count(),
                            audit.forcedMoves(), audit.violations(), audit.maxDistance(), o.left(), o.right());
                        raw.write(JSON.writeValueAsString(map("case", c.code(), "numerator", DurationDamageScale.NUMERATOR,
                            "sample", s)));
                        raw.newLine();
                        observations.add(s);
                        battles++;
                        violations += audit.violations();
                        timeouts += o.outcome().equals("TIMEOUT") ? 1 : 0;
                    }
                }
                final var summary = map("case", c.code(), "family", c.family(), "tier", c.tier(),
                    "level", c.level(), "size", c.left().size(), "pairs", pairs, "battles", observations.size(),
                    "wins", observations.stream().filter(s -> s.outcome().equals("WIN")).count(),
                    "losses", observations.stream().filter(s -> s.outcome().equals("LOSS")).count(),
                    "draws", observations.stream().filter(s -> s.outcome().equals("DRAW")).count(),
                    "timeouts", observations.stream().filter(s -> s.outcome().equals("TIMEOUT")).count(),
                    "rounds", stats(observations, Sample::rounds), "actions", stats(observations, Sample::actions),
                    "attempts", stats(observations, Sample::attempts), "movementTurns", stats(observations, Sample::movementTurns),
                    "firstDeathRound", stats(observations, Sample::firstDeathRound), "healing", stats(observations, Sample::healing),
                    "reactionDamage", stats(observations, Sample::reactionDamage),
                    "accumulationDischarges", stats(observations, Sample::accumulationDischarges),
                    "hitAndRunWindows", stats(observations, Sample::hitAndRunWindows));
                summaries.add(summary);
                definitions.add(map("case", c, "leftEquipment", manifest(c.left(), c.level()),
                    "rightEquipment", manifest(c.right(), c.level()),
                    "leftNominalGold", economy.nominalGold(c.left().stream().flatMap(g -> g.items(c.level()).stream()).toList()),
                    "rightNominalGold", economy.nominalGold(c.right().stream().flatMap(g -> g.items(c.level()).stream()).toList())));
                System.err.println("factor=" + DurationDamageScale.factor() + " " + c.code() + " " + summaries.size() + "/" + selected.size());
            }
        }
        try (final var out = new GZIPOutputStream(Files.newOutputStream(Path.of(prefix + "-cases.json.gz"), StandardOpenOption.CREATE_NEW))) {
            JSON.writeValue(out, definitions);
        }
        final var output = map("purpose", "Independent multi-agent balance audit; no live settings changed and no universal 50/50 target",
            "catalog", "SCALING_V5", "combat", Boolean.getBoolean("mobility.audit.old") ? "SCALING_SKILLS_V2" : "SCALING_SKILLS_V3", "numerator", DurationDamageScale.NUMERATOR,
            "denominator", 4, "factor", DurationDamageScale.factor(), "rootSeed", root, "pairsPerCondition", pairs,
            "filter", filter.pattern(), "conditions", selected.size(), "battles", battles, "timeouts", timeouts,
            "forcedMoveViolations", violations, "maxRounds", MAX_ROUNDS,
            "seeds", "SplitMix64(rootSeed + JavaStringHash(seedGroup), pairIndex); identical across factors, both side orders",
            "quantiles", "Median averages central pair; p95 nearest rank ceil(0.95*n). Timeouts retained at maxRounds",
            "units", "Rounds are initiative ticks, actions are performed turns, not seconds; firstDeath=-1 if absent",
            "scope", "Targeted audit: role profiles2/4, controlled mobile1/2/4/8; full RARE14/LEGENDARY28 are separate diagnostics. Explicit cases may have unequal budgets; manifests and nominal costs are authoritative. No external effects",
            "scaling", "Round-half-up final post-defense/post-variance damage once at both HP sinks; expected normal damage also scaled; healing unchanged",
            "sinkAudit", DurationDamageScale.audit(), "summaries", summaries);
        try (final var out = Files.newOutputStream(Path.of(prefix + "-summary.json"), StandardOpenOption.CREATE_NEW)) {
            JSON.writerWithDefaultPrettyPrinter().writeValue(out, output);
        }
        if (violations != 0 || timeouts != 0) throw new IllegalStateException("Movement violation or timeout: retained in output");
    }

    static List<Case> cases() {
        final var result = new ArrayList<Case>();
        for (final var tier : List.of(Tier.MID, Tier.STRONG)) {
            for (final var role : List.of(RoleBuild.TACTICIAN_PHYSICAL, RoleBuild.TACTICIAN_MAGICAL)) {
                final var breaker = role == RoleBuild.TACTICIAN_PHYSICAL ? RoleBuild.BREAKER_PHYSICAL : RoleBuild.BREAKER_MAGICAL;
                for (final var opponent : List.of(RoleBuild.BRUISER, breaker)) {
                    for (final boolean off : List.of(false, true)) {
                        add(result, "AUDIT_TACTIC_" + role + "_VS_" + opponent + (off ? "_OFF" : "_ON"),
                            "TACTIC_CAUSAL", tier, protectedTeam(Step12RepresentativeBuilds.role(role), tier),
                            protectedTeam(Step12RepresentativeBuilds.role(opponent), tier),
                            off ? Set.of(ActiveEnum.TEMPO_BREAK) : Set.of());
                    }
                }
            }
            for (final var spec : List.of(Specialization.COMMON_FRONT_PRESSURE, Specialization.PRESSURE)) {
                add(result, "AUDIT_MOBILE_COUNTER_" + spec, "MOBILE_COUNTER", tier,
                    Step123ReferenceTeams.specializedTeam(tier, spec).members(),
                    Step123ReferenceTeams.specializedTeam(tier, Specialization.MOBILE).members(), Set.of());
            }
        }
        for (final var rarity : List.of(ItemRarity.RARE, ItemRarity.LEGENDARY)) {
            for (final var risk : Step12RepresentativeRisks.pairs(rarity)) {
                if (!Set.of("RISK03_MASS_TEMPO_MIXED", "RISK04_MASS_TEMPO_ACCESS_RESPONSE",
                    "RISK07_KNOCKBACK_MELEE", "RISK08_KNOCKBACK_RANGE_RESPONSE").contains(risk.code())) continue;
                final boolean knock = risk.code().startsWith("RISK07") || risk.code().startsWith("RISK08");
                for (final boolean off : knock ? List.of(false, true) : List.of(false)) {
                    final var name = "AUDIT_FULL_" + risk.code() + "_" + rarity + (off ? "_OFF" : "_ON");
                    result.add(new Case(name, knock ? "KNOCKBACK_CAUSAL" : "MASS_TEMPO", "FULL_" + rarity, 6,
                        name.replace("_ON", "").replace("_OFF", ""), gears(risk.left()), gears(risk.right()),
                        off ? Set.of(ActiveEnum.KNOCKBACK) : Set.of()));
                }
            }
        }
        final var strong = Tier.STRONG;
        final var g = gear(Step12RepresentativeBuilds.role(RoleBuild.GUARDIAN), strong);
        final var b = gear(Step12RepresentativeBuilds.role(RoleBuild.BRUISER), strong);
        final var a = gear(Step12RepresentativeBuilds.role(RoleBuild.ASSASSIN), strong);
        final var m = gear(Step12RepresentativeBuilds.role(RoleBuild.RANGER_MAGICAL).withPosition(Position.MID), strong);
        final var r = gear(Step12RepresentativeBuilds.mixed(MixedBuild.RAIDER), strong);
        final var burst = List.of(g, r, r);
        add(result, "AUDIT_BURST_TWO_RAIDERS_VS_PRESSURE", "BURST_RESPONSE", strong, burst,
            Step123ReferenceTeams.specializedTeam(strong, Specialization.PRESSURE).members(), Set.of());
        add(result, "AUDIT_BURST_TWO_RAIDERS_VS_MAIN", "BURST_RESPONSE", strong, burst,
            Step123ReferenceTeams.mainTeam(strong, 3).members(), Set.of());
        add(result, "AUDIT_BURST_TWO_RAIDERS_VS_MOBILE", "BURST_RESPONSE", strong, burst,
            Step123ReferenceTeams.specializedTeam(strong, Specialization.MOBILE).members(), Set.of());
        add(result, "AUDIT_BURST_TWO_RAIDERS_VS_PROTECTED_MAGIC", "BURST_RESPONSE", strong, burst,
            protectedTeam(Step12RepresentativeBuilds.role(RoleBuild.RANGER_MAGICAL), strong), Set.of());
        add(result, "AUDIT_BURST_TWO_ASSASSINS_VS_PRESSURE", "BURST_RESPONSE", strong, List.of(g, a, a),
            Step123ReferenceTeams.specializedTeam(strong, Specialization.PRESSURE).members(), Set.of());
        add(result, "AUDIT_SOLO_RAIDER_VS_BRUISER", "SOLO_RESPONSE", strong, List.of(r), List.of(b), Set.of());
        add(result, "AUDIT_SOLO_ASSASSIN_VS_BRUISER", "SOLO_RESPONSE", strong, List.of(a), List.of(b), Set.of());
        for (final int size : List.of(7, 15)) {
            final var left = new ArrayList<Gear>(); left.add(g);
            final var pressure = new ArrayList<Gear>(); pressure.add(g);
            final var mixed = new ArrayList<Gear>(); mixed.add(g);
            for (int index = 1; index < size; index++) {
                left.add(r); pressure.add(b); mixed.add(index % 2 == 0 ? m : b);
            }
            add(result, "AUDIT_MASS_RAIDER_N" + size + "_VS_PRESSURE", "LARGE_BURST", strong, left, pressure, Set.of());
            add(result, "AUDIT_MASS_RAIDER_N" + size + "_VS_MIXED", "LARGE_BURST", strong, left, mixed, Set.of());
        }
        for (final var skill : List.of(ActiveEnum.TEMPO_BREAK, ActiveEnum.KNOCKBACK)) {
            final String weapon = skill == ActiveEnum.TEMPO_BREAK ? "command_staff" : "bow";
            for (final String armor : List.of("CLOTH", "NEW_CLOTH")) {
                final var build = Step12RepresentativeBuilds.hand("CLOTH_" + armor, List.of(weapon), armor,
                    Position.BACK, TargetingTactic.THREAT).withAssignments(Map.of(weapon, new Assignment(skill, ItemRarity.RARE)));
                for (final var opponent : List.of(Step12RepresentativeMatrix.opponents().get(0),
                    Step12RepresentativeMatrix.opponents().get(1))) {
                    final String name = "AUDIT_CLOTH_" + skill + "_" + armor + "_VS_" + opponent.code();
                    result.add(new Case(name, "CLOTH_COMPARE", "FOUR_POINTS_WITH_COMMON_SUPPORT", 6,
                        "AUDIT_CLOTH_" + skill + "_VS_" + opponent.code(), gears(Step12RepresentativeMatrix.anchored(build)),
                        gears(Step12RepresentativeMatrix.anchored(opponent)), Set.of()));
                }
            }
        }
        for (final String family : List.of("LEATHER", "PLATE", "ARCANE")) {
            for (final String armor : List.of(family, "NEW_" + family)) {
                final var build = Step12RepresentativeBuilds.hand(armor, List.of("rapier", "dirk"), armor,
                    Position.FRONT, TargetingTactic.THREAT);
                for (final var opponent : List.of(Step12RepresentativeMatrix.opponents().get(0),
                    Step12RepresentativeMatrix.opponents().get(3))) {
                    final String name = "AUDIT_ARMOR_" + armor + "_VS_" + opponent.code();
                    result.add(new Case(name, "ARMOR_COMPARE", "COMMON", 6, "AUDIT_ARMOR_" + family + "_VS_" + opponent.code(),
                        gears(List.of(build)), gears(List.of(opponent)), Set.of()));
                }
            }
        }
        for (final var skill : List.of(ActiveEnum.BLEEDING, ActiveEnum.FEINT)) {
            final var assignments = skill == ActiveEnum.BLEEDING
                ? Map.of("spear", new Assignment(skill, ItemRarity.RARE), "dirk", new Assignment(skill, ItemRarity.RARE))
                : Map.of("boots", new Assignment(skill, ItemRarity.RARE), "leather_gloves", new Assignment(skill, ItemRarity.RARE));
            final var build = Step12RepresentativeBuilds.hand("AUX_" + skill, List.of("spear", "dirk"), "LEATHER",
                Position.FRONT, TargetingTactic.THREAT).withAssignments(assignments);
            for (final var opponent : List.of(RoleBuild.BRUISER, RoleBuild.ASSASSIN)) {
                for (final boolean off : List.of(false, true)) {
                    add(result, "AUDIT_AUX_" + skill + "_VS_" + opponent + (off ? "_OFF" : "_ON"), "AUX_CAUSAL", strong,
                        gears(List.of(build)), List.of(gear(Step12RepresentativeBuilds.role(opponent), strong)),
                        off ? Set.of(skill) : Set.of());
                }
            }
        }
        final var mobile = Step123ReferenceTeams.specializedTeam(strong, Specialization.MOBILE).members();
        final var support = Step123BattleStudy.historicalV3Build(V3Build.CROSSBOW_SUPPORT).withPosition(Position.MID);
        for (final int points : List.of(1, 2, 4, 8)) {
            final var assignments = switch (points) {
                case 1 -> Map.of("boots", new Assignment(ActiveEnum.HIT_AND_RUN, ItemRarity.UNCOMMON));
                case 2 -> Map.of("boots", new Assignment(ActiveEnum.HIT_AND_RUN, ItemRarity.RARE));
                case 4 -> Map.of("boots", new Assignment(ActiveEnum.HIT_AND_RUN, ItemRarity.RARE),
                    "leather_helm", new Assignment(ActiveEnum.HIT_AND_RUN, ItemRarity.RARE));
                case 8 -> Map.of("boots", new Assignment(ActiveEnum.HIT_AND_RUN, ItemRarity.LEGENDARY),
                    "leather_helm", new Assignment(ActiveEnum.HIT_AND_RUN, ItemRarity.LEGENDARY));
                default -> throw new IllegalStateException();
            };
            final var front = new Gear(mobile.getFirst().build().withAssignments(assignments), EquipmentCatalogVersion.SCALING_V5);
            final var left = List.of(front, mobile.get(1), mobile.get(2));
            for (final var opponent : List.of(V3Build.BRUISER_BLUNT, V3Build.BREAKER_CLOSE_SLASH)) {
                final String name = "AUDIT_MOBILE_POINTS_P" + points + "_VS_" + opponent;
                result.add(new Case(name, "MOBILE_POINTS", "FIXED_LEVEL6_POINTS_" + points, 6,
                    "AUDIT_MOBILE_POINTS_VS_" + opponent, left,
                    gears(List.of(Step123BattleStudy.historicalV3Build(opponent).withPosition(Position.FRONT), support, support)), Set.of()));
            }
        }
        result.sort(Comparator.comparing(Case::code));
        if (result.stream().map(Case::code).distinct().count() != result.size()) throw new IllegalStateException("Duplicate case");
        return List.copyOf(result);
    }

    private static List<Gear> gears(List<Build> builds) {
        return builds.stream().map(build -> new Gear(build, EquipmentCatalogVersion.SCALING_V5)).toList();
    }

    private static List<Gear> protectedTeam(Build tested, Tier tier) {
        final var guardian = Step12RepresentativeBuilds.role(RoleBuild.GUARDIAN);
        final var ranger = Step12RepresentativeBuilds.role(RoleBuild.RANGER_PHYSICAL).withPosition(Position.MID);
        if (tested.position() == Position.BACK) tested = tested.withPosition(Position.MID);
        return List.of(gear(guardian, tier), gear(tested, tier), gear(ranger, tier));
    }

    private static Gear gear(Build build, Tier tier) {
        final var assignments = new LinkedHashMap<String, Assignment>();
        if (tier.profilePoints() > 0) for (final var item : build.items(0)) {
            final var original = build.assignments().get(item.object().code());
            if (original == null) continue;
            final int points = original.rarity().skillPoints() * tier.profilePoints() / 4;
            if (points == 0) throw new IllegalArgumentException("Unsupported profile carrier");
            final var rarity = Arrays.stream(ItemRarity.values()).filter(r -> r.skillPoints() == points).findFirst().orElseThrow();
            assignments.put(item.object().code(), new Assignment(original.skill(), rarity));
        }
        return new Gear(build.withAssignments(assignments), EquipmentCatalogVersion.SCALING_V5);
    }

    private static void add(List<Case> cases, String name, String family, Tier tier,
                            List<Gear> left, List<Gear> right, Set<ActiveEnum> disabled) {
        final String code = name + "_" + tier;
        final String group = name.replace("_OFF", "").replace("_ON", "") + "_" + tier;
        cases.add(new Case(code, family, tier.name(), tier.level(), group, left, right, disabled));
    }

    private static List<Map<String, Object>> manifest(List<Gear> members, int level) {
        return members.stream().map(g -> map("build", g.build(), "catalog", g.catalog(),
            "actualSkillPoints", g.items(level).stream().mapToInt(Item::skillPoints).sum(),
            "items", g.items(level).stream().map(i -> map("code", i.object().code(), "rarity", i.rarity(),
                "level", i.enhanceLevel(), "points", i.modifier().isPresent() ? i.skillPoints() : 0,
                "skill", i.modifier().map(m -> m.activeEnum().name()).orElse("NONE"),
                "health", i.health(), "speed", i.speed(), "attacks", i.itemAttacks(),
                "defense", i.itemDefense().map(d -> map("type", d.defenseType(), "value", d.defense())).orElse(null))).toList())).toList();
    }

    private static long reactionDamage(BattleEvent event) {
        if (event instanceof BattleEvent.ScalingSkillDamage d && Set.of(ActiveEnum.THORNS, ActiveEnum.COUNTER_ATTACK).contains(d.skill())) return d.damageTaken();
        if (event instanceof BattleEvent.SkillDamage d && Set.of(ActiveEnum.THORNS, ActiveEnum.COUNTER_ATTACK).contains(d.skill())) return d.damageTaken();
        return 0;
    }

    private static Map<String, Object> stats(List<Sample> samples, ToLongFunction<Sample> field) {
        final var values = samples.stream().mapToLong(field).sorted().toArray();
        final int n = values.length;
        return map("median", n % 2 == 0 ? (values[n/2-1] + values[n/2]) / 2.0 : (double) values[n/2],
            "p95", values[(int) Math.ceil(0.95 * n) - 1], "mean", Arrays.stream(values).average().orElseThrow(),
            "min", values[0], "max", values[n-1]);
    }

    private static long iterationSeed(long seed, int iteration) {
        long mixed = seed + 0x9e3779b97f4a7c15L * (iteration + 1L);
        mixed = (mixed ^ mixed >>> 30) * 0xbf58476d1ce4e5b9L;
        mixed = (mixed ^ mixed >>> 27) * 0x94d049bb133111ebL;
        return mixed ^ mixed >>> 31;
    }

    private static Map<String, Object> map(Object... pairs) {
        final var result = new LinkedHashMap<String, Object>();
        for (int i = 0; i < pairs.length; i += 2) result.put((String) pairs[i], pairs[i+1]);
        return result;
    }

    record Case(String code, String family, String tier, int level, String seedGroup,
                List<Gear> left, List<Gear> right, Set<ActiveEnum> disabledLeft) { }

    record Sample(int pair, boolean reverse, long seed, String outcome, int rounds, long actions,
                  long attempts, long movementTurns, long firstDeathRound, long healing, long reactionDamage,
                  long accumulationDischarges, long hitAndRunWindows, long forcedMoves, long forcedMoveViolations, long maxForcedDistance,
                  Step12RepresentativeBattleRunner.TeamMeasure left, Step12RepresentativeBattleRunner.TeamMeasure right) { }
}

