package ru.homyakin.seeker.game.battle;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class MobilityStudyOrigin {
    public static void main(String[] args) throws Exception {
        final var result = new LinkedHashMap<String, Object>();
        for (final var name : List.of("Battle", "BattleContext", "BattlePersonage", "BattleTempoVersion", "VersionedBattleTurn",
            "skill.scaling.SkillFormulaVersion", "skill.scaling.ScalingSkillBook", "skill.scaling.ScalingSkillMath",
            "skill.scaling.ScalingCooldowns", "Step123BattleRunner")) {
            final var cls = Class.forName("ru.homyakin.seeker.game.battle." + name);
            final var resource = "/" + cls.getName().replace('.', '/') + ".class";
            try (final var in = cls.getResourceAsStream(resource)) {
                result.put(cls.getName(), Map.of("origin", cls.getProtectionDomain().getCodeSource().getLocation().toString(),
                    "sha256", HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(in.readAllBytes()))));
            }
        }
        result.put("classpath", System.getProperty("java.class.path"));
        new ObjectMapper().writerWithDefaultPrettyPrinter().writeValue(System.out, result);
    }
}
