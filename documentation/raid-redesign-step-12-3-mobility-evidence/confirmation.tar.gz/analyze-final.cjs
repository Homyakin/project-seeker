const fs = require('fs');
const z = require('zlib');
const assert = require('assert/strict');
const directory = process.argv[2] || '/tmp/seeker-mobility-fix.wba82w';
const read = name => JSON.parse(fs.readFileSync(`${directory}/${name}`, 'utf8'));
const raw = (phase, layer) => {
  const groups = new Map();
  const lines = z.gunzipSync(fs.readFileSync(`${directory}/final-${phase}-${layer}-raw.jsonl.gz`)).toString('utf8').trim().split('\n');
  for (const line of lines) {
    const row = JSON.parse(line, (key, value, context) => key === 'seed' ? BigInt(context.source) : value);
    if (!groups.has(row.case)) groups.set(row.case, []);
    groups.get(row.case).push(row.sample);
  }
  return groups;
};
const score = sample => sample.outcome === 'WIN' ? 1 : sample.outcome === 'DRAW' ? 0.5 : 0;
const pairScores = samples => {
  const pairs = new Map();
  for (const sample of samples) {
    if (!pairs.has(sample.pair)) pairs.set(sample.pair, []);
    pairs.get(sample.pair).push(sample);
  }
  return [...pairs].sort((a, b) => a[0] - b[0]).map(([id, values]) => {
    assert.equal(values.length, 2);
    assert.equal(values.filter(x => x.reverse).length, 1);
    assert.equal(values[0].seed, values[1].seed);
    return {id, seed: values[0].seed, score: values.reduce((a, x) => a + score(x), 0) / 2};
  });
};
const difference = (left, right) => {
  const a = pairScores(left), b = pairScores(right);
  assert.equal(a.length, 500); assert.equal(b.length, 500);
  const values = a.map((x, i) => {
    assert.equal(x.id, b[i].id); assert.equal(x.seed, b[i].seed);
    return x.score - b[i].score;
  });
  const mean = values.reduce((a, x) => a + x, 0) / values.length;
  const variance = values.reduce((a, x) => a + (x - mean) ** 2, 0) / (values.length - 1);
  const radius = 1.96 * Math.sqrt(variance / values.length);
  return {differencePercentagePoints: 100 * mean, approximatePointwise95: [100 * (mean - radius), 100 * (mean + radius)]};
};
const encoded = value => JSON.stringify(value, (key, x) => typeof x === 'bigint' ? x.toString() : x);
const result = {unit: '500 independent seed pairs, each averaged over both side orders; paired normal 1.96-SE intervals, not simultaneous intervals'};
const beforeExtra = raw('before', 'extra'), afterExtra = raw('after', 'extra');
result.raiderCausal = [];
for (const size of [3, 7, 15]) {
  const group = `MOBILITY_RAIDER_CAUSAL_N${size}`;
  for (const data of [beforeExtra, afterExtra]) {
    assert.equal(encoded(data.get(`${group}_BOTH_ON`)), encoded(data.get(`${group}_ONLY_HIT_AND_RUN`)));
    assert.equal(encoded(data.get(`${group}_BOTH_OFF`)), encoded(data.get(`${group}_ONLY_PENETRATION`)));
  }
  result.raiderCausal.push({size, bothOnEqualsOnlyHitAndRun: true, bothOffEqualsOnlyPenetration: true,
    beforeAfter: difference(afterExtra.get(`${group}_BOTH_ON`), beforeExtra.get(`${group}_BOTH_ON`))});
}
result.mobilePoints = [];
for (const opponent of ['BRUISER_BLUNT', 'BREAKER_CLOSE_SLASH', 'RANGER_PIERCE']) {
  const group = `MOBILITY_POINT_CAUSAL_VS_${opponent}`;
  const p1 = afterExtra.get(`${group}_P1_ON`);
  for (const points of [1, 2, 4, 8]) {
    const on = afterExtra.get(`${group}_P${points}_ON`), off = afterExtra.get(`${group}_P${points}_OFF`);
    result.mobilePoints.push({opponent, points, wins: on.filter(s => s.outcome === 'WIN').length,
      offWins: off.filter(s => s.outcome === 'WIN').length, battles: on.length,
      versusDisabled: difference(on, off), versusOnePoint: difference(on, p1)});
  }
  result.mobilePoints.push({opponent, contrast: '8 minus 4', ...difference(afterExtra.get(`${group}_P8_ON`), afterExtra.get(`${group}_P4_ON`))});
}
result.assassinNicheConditionsUnchanged = [...afterExtra].filter(([name, values]) => name.startsWith('MOBILITY_ASSASSIN_NICHE_')
  && encoded(values) === encoded(beforeExtra.get(name))).length;
const beforeMain = raw('before', 'main'), afterMain = raw('after', 'main');
result.mainConditionsExactlyUnchanged = [...afterMain].filter(([name, values]) => encoded(values) === encoded(beforeMain.get(name))).length;
result.equalGoldRaiderOutcomes = [];
const beforeEqual = read('final-before-equal-summary.json'), afterEqual = read('final-after-equal-summary.json');
for (const row of afterEqual.summaries) {
  const previous = beforeEqual.summaries.find(x => x.case === row.case);
  result.equalGoldRaiderOutcomes.push({case: row.case, size: row.size, beforeWins: previous.wins, afterWins: row.wins,
    battles: row.battles, beforeMedianTicks: previous.rounds.median, afterMedianTicks: row.rounds.median});
}
assert.equal(result.mainConditionsExactlyUnchanged, 58);
assert.equal(result.assassinNicheConditionsUnchanged, 6);
console.log(JSON.stringify(result, null, 2));
