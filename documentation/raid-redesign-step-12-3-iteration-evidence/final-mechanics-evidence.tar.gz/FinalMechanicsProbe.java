package ru.homyakin.seeker.game.battle;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import ru.homyakin.seeker.game.battle.Step123BattleRunner.Gear;
import ru.homyakin.seeker.game.battle.skill.active_impl.ActiveEnum;
import ru.homyakin.seeker.game.battle.skill.scaling.AttackAccess;
import ru.homyakin.seeker.game.battle.skill.scaling.SkillFormulaVersion;
import ru.homyakin.seeker.game.item.catalog.EquipmentCatalogLoader;
import ru.homyakin.seeker.game.item.catalog.EquipmentCatalogVersion;
import ru.homyakin.seeker.game.item.models.*;
import ru.homyakin.seeker.utils.RandomUtils;

public final class FinalMechanicsProbe {
    static Object get(Object object, String field) throws Exception {
        Method m = object.getClass().getDeclaredMethod(field);
        m.setAccessible(true);
        return m.invoke(object);
    }

    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        System.setProperty("audit.sizes", "1,3,7,15");
        System.setProperty("audit.levels", "0,6,20");
        Class<?> study = Class.forName("ru.homyakin.seeker.game.battle.Nov07ComparativeStudy");
        Method cases = study.getDeclaredMethod("cases"); cases.setAccessible(true);
        List<?> all = (List<?>) cases.invoke(null);
        Method observe = study.getDeclaredMethod("observe", all.get(0).getClass(), long.class, boolean.class);
        observe.setAccessible(true);
        int checked = 0;
        for (int index = 0; index < 64; index++) {
            Object c = all.get(index * (all.size() - 1) / 63);
            List<Gear> lg = (List<Gear>) get(c, "left");
            List<Gear> rg = (List<Gear>) get(c, "right");
            int level = (int) get(c, "level");
            Set<ActiveEnum> disabled = (Set<ActiveEnum>) get(c, "disabledLeft");
            long seed = 2026110722000L + index;
            for (boolean reverse : List.of(false, true)) {
                Object expected = observe.invoke(null, c, seed, reverse);
                Object[] actual = RandomUtils.withSeed(seed, () -> {
                    var left = lg.stream().map(g -> g.personage(level, disabled)).toList();
                    var right = rg.stream().map(g -> g.personage(level, Set.of())).toList();
                    var result = new Battle(seed).process(reverse ? right : left, reverse ? left : right,
                        3000, BattleTempoVersion.ACCELERATED_V1);
                    var lm = Step12RepresentativeBattleRunner.measure(left, result.actionLog().events(), result.actionLog().traceEvents());
                    var rm = Step12RepresentativeBattleRunner.measure(right, result.actionLog().events(), result.actionLog().traceEvents());
                    return new Object[]{result.rounds(), lm, rm};
                });
                if (!get(expected, "rounds").equals(actual[0]) || !get(expected, "left").equals(actual[1])
                    || !get(expected, "right").equals(actual[2]))
                    throw new AssertionError("Harness drift: " + get(c, "code") + " reverse=" + reverse);
                checked++;
            }
        }
        System.out.println("Direct production Battle versus helper: " + checked + " battles exactly equal for rounds and all 10 team metrics; seeds 2026110722000..2026110722063 mirrored");

        var a = BattlePersonage.forScalingSkills(List.of(item("a", List.of(
            new ItemAttack(AttackType.SLASH, 1, 1, 100),
            new ItemAttack(AttackType.MAGICAL, 2, 2, 200)), 1000)), Position.FRONT,
            Map.of(ActiveEnum.BERSERK, 4), SkillFormulaVersion.SCALING_SKILLS_V3);
        var b = BattlePersonage.forScalingSkills(List.of(item("b", List.of(), 1000)), Position.FRONT,
            Map.of(), SkillFormulaVersion.SCALING_SKILLS_V3);
        new BattleContext(List.of(a), List.of(b), new SeededBattleRandom(2026110722064L), BattleTempoVersion.ACCELERATED_V1);
        a.placeOnBattlefield(0, BattleAdvanceDirection.TOWARD_SECOND_TEAM);
        b.placeOnBattlefield(3, BattleAdvanceDirection.TOWARD_FIRST_TEAM);
        System.out.println("Access diagnostic at distance 3: EV=" + a.expectedDamageAgainst(b)
            + "; normal=" + a.scalingAttackAt(3, AttackAccess.NORMAL)
            + "; penetration=" + a.scalingAttackAt(3, AttackAccess.PENETRATION));
        b.placeOnBattlefield(1, BattleAdvanceDirection.TOWARD_FIRST_TEAM);
        double before = a.expectedDamageAgainst(b);
        a.scalingSkills().activateBerserk();
        System.out.println("Berserk diagnostic: EV before=" + before + "; EV after=" + a.expectedDamageAgainst(b)
            + "; actual normal vector after=" + a.scalingAttackAt(1, AttackAccess.NORMAL));

        int objects = 0, transitions = 0, flat = 0, falling = 0;
        var catalog = EquipmentCatalogLoader.loadValidated(EquipmentCatalogVersion.SCALING_V5);
        for (var object : catalog.itemObjects()) {
            objects++;
            for (int level = 0; level <= 20; level++) {
                var delta = ru.homyakin.seeker.game.item.storm.ItemProgression.transition(object, level);
                long gain = delta.health() + delta.attacks().stream().mapToLong(d -> d.attack()).sum()
                    + delta.defense().map(d -> d.defense()).orElse(0);
                transitions++;
                if (gain == 0) flat++;
                if (gain < 0) falling++;
            }
        }
        System.out.println("V5 progression objects=" + objects + "; transitions=" + transitions + "; all-channel-flat=" + flat + "; falling=" + falling);
    }

    static Item item(String code, List<ItemAttack> attacks, int health) {
        return Item.fromObject(new ItemObject(code, Set.of(), attacks, Optional.empty(), health,
            0, 0, 0, 100, 1, 0, ItemProgressionVersion.V1, Map.of()));
    }
}
