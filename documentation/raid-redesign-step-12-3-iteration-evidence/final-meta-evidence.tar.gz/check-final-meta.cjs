'use strict';
const fs = require('node:fs');
const zlib = require('node:zlib');
const readline = require('node:readline');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const path = require('node:path');
const oldDir = '/tmp/seeker-nov07-archive-check.EWIlV9';
const newDir = '/tmp/nov07-final-meta-asym';
const screen = '/tmp/nov07-final-meta-command-screen';
const asym = path.join(newDir, 'asym-confirmation');
const json = p => JSON.parse(fs.readFileSync(p, 'utf8'));
const zipped = p => JSON.parse(zlib.gunzipSync(fs.readFileSync(p)));
const sha = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === 'object') return Object.fromEntries(Object.keys(value).sort().map(k => [k, canonical(value[k])]));
  return value;
}
function combat(gear) {
  const active = {};
  for (const item of gear.items) if (item.skill !== 'NONE') active[item.skill] = (active[item.skill] ?? 0) + item.skillPoints;
  return canonical({ position: gear.build.position, tactic: gear.build.tactic, active,
    items: gear.items.map(({ rarity, skill, skillPoints, ...stats }) => stats) });
}
async function seeds(file) {
  const set = new Set(); let rows = 0;
  for await (const line of readline.createInterface({ input: fs.createReadStream(file).pipe(zlib.createGunzip()), crlfDelay: Infinity })) {
    if (!line.trim()) continue;
    const m = [...line.matchAll(/"seed"\s*:\s*(-?\d+)(?=\s*[,}])/g)];
    assert.equal(m.length, 1); set.add(BigInt(m[0][1]).toString()); rows++;
  }
  return { set, rows };
}
(async () => {
  const original = json(path.join(oldDir, 'core-confirmation-provenance.json'));
  const newer = json(asym + '-provenance.json');
  const shared = Object.keys(original).filter(k => !k.includes('Nov07ComparativeStudy'));
  for (const key of shared) assert.deepEqual(newer[key], original[key], key);
  const before = zipped(path.join(oldDir, 'protected-confirmation-cases.json.gz'));
  const after = zipped(asym + '-cases.json.gz');
  const equivalent = [];
  for (const level of [0, 6]) {
    const a = before.find(d => d.case.budget === 'RARE' && d.case.level === level).leftEquipment[0];
    const b = after.find(d => d.case.budget === 'RARE' && d.case.level === level).leftEquipment[0];
    assert.deepEqual(combat(a), combat(b));
    assert.equal(combat(a).active.GUARD, 4);
    assert.equal(b.nominalGold, 1600);
    equivalent.push({ level, originalNominalGold: a.nominalGold, twoRareNominalGold: b.nominalGold,
      guardPoints: 4, sameItemCodesAndCombatStats: true, samePositionAndTactic: true });
  }
  const asymSeeds = await seeds(asym + '-pairs.jsonl.gz');
  const comparisons = [];
  for (const file of fs.readdirSync(oldDir).filter(f => f.endsWith('-pairs.jsonl.gz')).sort()) {
    const old = await seeds(path.join(oldDir, file));
    const intersections = [...asymSeeds.set].filter(v => old.set.has(v)).length;
    assert.equal(intersections, 0, file);
    comparisons.push({ file, rows: old.rows, uniqueSeeds: old.set.size, intersections });
  }
  const newScreen = await seeds(screen + '-pairs.jsonl.gz');
  const overlap = [...asymSeeds.set].filter(v => newScreen.set.has(v)).length;
  assert.equal(overlap, 0);
  const summary = json(asym + '-summary.json');
  assert.equal(summary.battles, 8000); assert.equal(summary.pairs, 500);
  for (const row of summary.summaries) {
    assert(row.leftNominalGold <= row.rightNominalGold);
    if (row.budget === 'RARE') assert.equal(row.leftNominalGold, row.rightNominalGold);
  }
  console.log(JSON.stringify({ ok: true, purpose: 'Fresh final-analysis supplement; separate from frozen 418000 confirmation battles',
    asymmetricBattles: summary.battles, uniqueAsymmetricSeeds: asymSeeds.set.size,
    priorFilesCompared: comparisons, newScreen: { rows: newScreen.rows, uniqueSeeds: newScreen.set.size, intersections: overlap },
    unchangedLoadedClasses: shared.length, guardianCombatEquivalence: equivalent,
    sourceSha256: sha(path.join(newDir, 'Nov07AsymmetricStudy.java')),
    frozenHelperSourceSha256: sha('/tmp/nov07-comparative-Go3Io6/Nov07ComparativeStudy.java'),
    limitations: 'Seed/provenance and manifest equivalence check; native validate-study.cjs separately validates outcomes, all 13 summary statistics, costs, slots and seed schedule. No full event-journal replay.' }, null, 2));
})().catch(error => { console.error(error); process.exitCode = 1; });
