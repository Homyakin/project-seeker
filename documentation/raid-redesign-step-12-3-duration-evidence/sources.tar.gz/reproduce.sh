#!/usr/bin/env bash
set -euo pipefail

# All writes are confined to a new study directory and Maven's ordinary target directory.
study_repo=${1:?Specify absolute repository path}
study_out=${2:?Specify a new unused results directory}
study_source=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
if [[ -e "$study_out" ]]; then
    echo "Results path must not exist: $study_out" >&2
    exit 1
fi
mkdir -p -- "$study_out/classes"
cd -- "$study_repo/game"
${TEMPO_MVN:-mvn} -q -DskipTests test-compile dependency:build-classpath "-Dmdep.outputFile=$study_out/dependencies.txt"
study_deps=$(<"$study_out/dependencies.txt")
study_cp="$study_repo/game/target/test-classes:$study_repo/game/target/classes:$study_deps"
${TEMPO_JAVAC:-javac} -cp "$study_cp" -d "$study_out/classes" \
    "$study_source"/source/ru/homyakin/seeker/game/battle/*.java "$study_source"/source-harness/*.java
study_runtime="$study_out/classes:$study_cp"
study_filter='^(DIRECT_PRESSURE_VS_FLANK_(MID|STRONG)|FULL_RISK(05_GUARD_REACTIONS_MELEE|06_GUARD_MAGIC_ACCESS_RESPONSE|09_ACCUMULATION_DAMAGE|10_ACCUMULATION_ACCESS_RESPONSE)_L6|ROLE_TACTICIAN_PHYSICAL_VS_BREAKER_PHYSICAL_STRONG|ROLE_TACTICIAN_MAGICAL_VS_BREAKER_MAGICAL_MID|ROLE_RAIDER_VS_ASSASSIN_STRONG|ROLE_RAIDER_VS_BRUISER_STRONG|ROLE_ASSASSIN_VS_BRUISER_MID|MOBILE_NICHE_VS_(BRUISER_BLUNT|ASSASSIN_PIERCE|BREAKER_CLOSE_SLASH)_(ON|OFF)_STRONG)$'
for study_n in 4 5 6 7; do
    ${TEMPO_JAVA:-java} -Xmx640m "-Dtempo.numerator=$study_n" -cp "$study_runtime" \
        ru.homyakin.seeker.game.battle.DamageTempoProbe "$study_out/probe-$study_n.json" \
        > "$study_out/probe-$study_n.log" 2>&1
    ${TEMPO_JAVA:-java} -Xmx640m "-Dtempo.numerator=$study_n" -cp "$study_runtime" \
        ru.homyakin.seeker.game.battle.DamageTempoPublicPathProbe "$study_out/public-path-$study_n.json" \
        > "$study_out/public-path-$study_n.log" 2>&1
    ${TEMPO_JAVA:-java} -Xmx640m "-Dtempo.numerator=$study_n" \
        "-Dduration.harnessSource=$study_source/source-harness/DurationComparison.java" -cp "$study_runtime" \
        ru.homyakin.seeker.game.battle.DamageTempoHistoricalStudy PVP "$study_out/pvp-$study_n.json" \
        > "$study_out/pvp-$study_n.log" 2>&1
    ${TEMPO_JAVA:-java} -Xmx640m "-Dtempo.numerator=$study_n" -cp "$study_runtime" \
        ru.homyakin.seeker.game.battle.DamageTempoHistoricalStudy PVE "$study_out/pve-$study_n.json" \
        > "$study_out/pve-$study_n.log" 2>&1
    ${TEMPO_JAVA:-java} -Xmx640m "-Dtempo.numerator=$study_n" -Dtempo.pairs=100 -cp "$study_runtime" \
        ru.homyakin.seeker.game.battle.DamageTempoBalanceStudy "$study_out/screen-$study_n" \
        > "$study_out/screen-$study_n.log" 2>&1
    ${TEMPO_JAVA:-java} -Xmx640m "-Dtempo.numerator=$study_n" -Dtempo.pairs=500 -Dtempo.seed=2026110203 \
        -Dtempo.includeDirectResponses=true "-Dtempo.filter=$study_filter" -cp "$study_runtime" \
        ru.homyakin.seeker.game.battle.DamageTempoBalanceStudy "$study_out/confirm-$study_n" \
        > "$study_out/confirm-$study_n.log" 2>&1
done
echo "Completed experimental results: $study_out"
