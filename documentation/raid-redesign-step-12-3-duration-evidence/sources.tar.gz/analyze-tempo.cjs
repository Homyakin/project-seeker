const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const assert = require('node:assert/strict');

const dir = process.argv[2] || __dirname;
const oldDir = process.argv[3] || '/tmp/seeker-duration-comparison.XNZy7z';
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const variants = [4, 5, 6, 7];
const records = (phase, n) => zlib.gunzipSync(fs.readFileSync(path.join(dir, `${phase}-${n}-raw.jsonl.gz`)))
  .toString('utf8').trim().split('\n').map(line => JSON.parse(line.replace(/"seed":(-?\d+)/g, '"seed":"$1"')));
const score = outcome => outcome === 'WIN' ? 1 : outcome === 'DRAW' ? 0.5 : outcome === 'LOSS' ? 0 : null;
const mean = a => a.reduce((s, x) => s + x, 0) / a.length;
function interval(values, difference = false) {
  const n = values.length, estimate = mean(values);
  const variance = values.reduce((s, x) => s + (x - estimate) ** 2, 0) / (n - 1);
  const normal = 1.96 * Math.sqrt(variance / n);
  const hoeffding = (difference ? 2 : 1) * Math.sqrt(Math.log(40) / (2 * n));
  return {estimate, independentSeedPairs: n, approximate95: [estimate - normal, estimate + normal],
    conservativePointwise95: [estimate - hoeffding, estimate + hoeffding]};
}
function pairScores(rows) {
  const result = new Map();
  for (const row of rows) {
    const value = score(row.sample.outcome);
    if (value === null) throw new Error('Timeout cannot silently contribute as a loss');
    const key = row.sample.pair;
    const slot = result.get(key) || {seed: row.sample.seed, scores: []};
    assert.equal(slot.seed, row.sample.seed);
    slot.scores.push(value);
    result.set(key, slot);
  }
  return [...result].sort((a, b) => a[0] - b[0]).map(([pair, value]) => {
    assert.equal(value.scores.length, 2);
    return {pair, seed: value.seed, score: mean(value.scores)};
  });
}

const pvp = variants.map(n => read(path.join(dir, `pvp-${n}.json`)));
const pve = variants.map(n => read(path.join(dir, `pve-${n}.json`)));
const oldPvp = read(path.join(oldDir, 'pvp-old.json'));
const oldPve = read(path.join(oldDir, 'raid-old.json'));
assert.deepEqual(pvp[0].raw, read(path.join(oldDir, 'pvp-new.json')).raw);
assert.deepEqual(pve[0].samplesJson, read(path.join(oldDir, 'raid-new.json')).samplesJson);
const duration = pvp[0].summaries.map(base => {
  const old = oldPvp.summaries.find(s => s.condition === base.condition);
  return {condition: base.condition, size: base.partySize, level: base.level, regime: base.regime,
    old: {rounds: old.rounds, turns: old.turnsBothTeams},
    variants: pvp.map((data, i) => {
      const s = data.summaries.find(s => s.condition === base.condition);
      return {factor: variants[i] / 4, rounds: s.rounds, turns: s.turnsBothTeams,
        medianRatioToCurrent: s.rounds.median / base.rounds.median,
        medianRatioToOld: s.rounds.median / old.rounds.median};
    })};
});
const teamDurationGroups = [];
for (const size of [3, 7, 15]) for (const regime of ['COMMON_NO_MODS', 'RARE_FULL']) {
  const selected = duration.filter(s => s.size === size && s.regime === regime);
  teamDurationGroups.push({size, regime, variants: variants.map((n, i) => {
    const ratios = selected.map(s => s.variants[i].medianRatioToCurrent);
    return {factor: n / 4, reductionPercentRange: [100 * (1 - Math.max(...ratios)), 100 * (1 - Math.min(...ratios))]};
  })});
}

const phases = {};
const tsv = ['phase\tcase\tfactor\tbaselineWinRate\tvariantWinRate\tdeltaPercentagePoints\tapprox95LowPp\tapprox95HighPp'];
for (const phase of ['screen', 'confirm']) {
  const data = variants.map(n => read(path.join(dir, `${phase}-${n}-summary.json`)));
  const raw = variants.map(n => records(phase, n));
  const grouped = raw.map(rows => {
    const groups = new Map();
    for (const row of rows) {
      if (!groups.has(row.case)) groups.set(row.case, []);
      groups.get(row.case).push(row);
    }
    return new Map([...groups].map(([code, rows]) => [code, pairScores(rows)]));
  });
  const comparisons = data[0].summaries.map(b => {
    const basePairs = grouped[0].get(b.case);
    const comparison = {case: b.case, family: b.family, baseline: b,
      baselineScore: interval(basePairs.map(p => p.score)), variants: []};
    for (let i = 1; i < variants.length; i++) {
      const v = data[i].summaries.find(s => s.case === b.case);
      const pairs = grouped[i].get(b.case);
      const diffs = pairs.map((p, j) => {
        assert.equal(p.pair, basePairs[j].pair); assert.equal(p.seed, basePairs[j].seed);
        return p.score - basePairs[j].score;
      });
      const delta = interval(diffs, true);
      comparison.variants.push({factor: variants[i] / 4, summary: v,
        score: interval(pairs.map(p => p.score)), pairedScoreChange: delta});
      tsv.push([phase, b.case, variants[i] / 4, comparison.baselineScore.estimate,
        mean(pairs.map(p => p.score)), 100 * delta.estimate,
        100 * delta.approximate95[0], 100 * delta.approximate95[1]].join('\t'));
    }
    return comparison;
  });
  const mobileCausal = [];
  for (const tier of ['BEGINNER', 'MID', 'STRONG']) for (const opponent of ['BRUISER_BLUNT', 'BREAKER_CLOSE_SLASH', 'ASSASSIN_PIERCE']) {
    const on = `MOBILE_NICHE_VS_${opponent}_ON_${tier}`;
    const off = `MOBILE_NICHE_VS_${opponent}_OFF_${tier}`;
    if (!grouped[0].has(on) || !grouped[0].has(off)) continue;
    mobileCausal.push({opponent, tier, variants: variants.map((n, i) => {
      const a = grouped[i].get(on), b = grouped[i].get(off);
      const changes = a.map((p, j) => {
        assert.equal(p.seed, b[j].seed); return p.score - b[j].score;
      });
      return {factor: n / 4, onMinusOff: interval(changes, true)};
    })});
  }
  phases[phase] = {conditions: data[0].conditions, pairsPerCondition: data[0].pairsPerCondition,
    rootSeed: data[0].rootSeed, battlesAllVariants: data.reduce((s, d) => s + d.battles, 0),
    comparisons, mobileCausal};
}

const output = {
  date: '2026-11-02', purpose: 'Experimental damage tempo comparison; no production mutation or candidate activation',
  newBattles: pvp.reduce((s, d) => s + d.totalBattles, 0) + pve.reduce((s, d) => s + d.iterations, 0)
    + phases.screen.battlesAllVariants + phases.confirm.battlesAllVariants,
  excludedFromNewBattles: '464 smoke battles and small public/private sink checks; earlier old baseline observations reused separately',
  factors: variants.map(n => n / 4), duration, teamDurationGroups,
  pveDiagnostic: {old: oldPve.summary, variants: pve.map((d, i) => ({factor: variants[i] / 4, summary: d.summary})),
    warning: 'One unchanged, not-yet-adapted MYCONID_COLONY generator; not all raids or final PvE acceptance'},
  phases,
  confidence: 'Reverse sides are averaged within each independent seed. Approximate95 uses normal1.96SE of paired seed values; conservativePointwise95 uses Hoeffding. No family-wise coverage claim; screening chose confirmation cases, confirmation uses a new root. No 50/50 gate.',
  recommendation: '1.5 is a cautious candidate compromise, not an objectively proven optimum or authorization to activate',
  independentValidation: read(path.join(dir, 'independent-validation.json'))
};
fs.writeFileSync(path.join(dir, 'analysis.json'), JSON.stringify(output, null, 2) + '\n');
fs.writeFileSync(path.join(dir, 'outcome-changes.tsv'), tsv.join('\n') + '\n');
console.log(JSON.stringify({newBattles: output.newBattles, groups: teamDurationGroups}, null, 2));
