package ru.homyakin.seeker.game.battle;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import ru.homyakin.seeker.game.battle.Step123ReferenceTeams.Tier;
import ru.homyakin.seeker.utils.RandomUtils;

/** Small sink, rounding, overkill and unchanged-heal checks for the experimental overlay. */
public final class DamageTempoProbe {
    private DamageTempoProbe() { }

    public static void main(String[] args) throws Exception {
        final var results = new java.util.ArrayList<Map<String, Object>>();
        final Method oldSink = BattlePersonage.class.getDeclaredMethod("takeDamage", int.class, int.class);
        final Method newSink = BattlePersonage.class.getDeclaredMethod("applyVersionedHealthDamage", int.class, int.class);
        oldSink.setAccessible(true);
        newSink.setAccessible(true);
        for (final Method sink : List.of(oldSink, newSink)) {
            for (final int input : List.of(0, 1, 2, 101, 1700, 1000000)) {
                final var target = Step123ReferenceTeams.mainTeam(Tier.BEGINNER, 1).personages().getFirst();
                final int before = target.health();
                final int withSpread = sink == oldSink
                    ? RandomUtils.withSeed(20261102, () -> RandomUtils.getInPercentRange(input, 10)) : input;
                final int expected = Math.min(before, Math.toIntExact(((long) withSpread * DurationDamageScale.NUMERATOR + 2) / 4));
                final int actual = RandomUtils.withSeed(20261102, () -> {
                    try { return (int) sink.invoke(target, input, input); }
                    catch (ReflectiveOperationException e) { throw new IllegalStateException(e); }
                });
                if (actual != expected || before - target.health() != expected || target.actualDamageTaken() != expected) {
                    throw new AssertionError("Damage sink mismatch " + sink.getName() + " input=" + input);
                }
                final int healed = target.healAndGetActual(17);
                final int expectedHealing = target.isAlive() ? Math.min(17, expected) : 0;
                if (healed != expectedHealing) throw new AssertionError("Healing must not be scaled");
                results.add(Map.of("sink", sink.getName(), "input", input, "unscaledAfterSpread", withSpread,
                    "expectedActualDamage", expected, "actualDamage", actual, "healed", healed));
            }
        }
        if (DurationDamageScale.apply(101, true) != (101 * DurationDamageScale.NUMERATOR + 2) / 4) {
            throw new AssertionError("Rounding");
        }
        final var result = new LinkedHashMap<String, Object>();
        result.put("factor", DurationDamageScale.factor());
        result.put("classOrigin", BattlePersonage.class.getProtectionDomain().getCodeSource().getLocation().toString());
        result.put("checks", results);
        result.put("audit", DurationDamageScale.audit());
        try (final var out = Files.newOutputStream(Path.of(args[0]), StandardOpenOption.CREATE_NEW)) {
            new ObjectMapper().writerWithDefaultPrettyPrinter().writeValue(out, result);
        }
    }
}
