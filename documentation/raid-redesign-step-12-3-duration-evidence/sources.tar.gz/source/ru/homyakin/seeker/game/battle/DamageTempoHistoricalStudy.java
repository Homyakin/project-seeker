package ru.homyakin.seeker.game.battle;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/** Runs the exact prior duration harness with the temporary damage overlay. */
public final class DamageTempoHistoricalStudy {
    private DamageTempoHistoricalStudy() { }

    public static void main(String[] args) throws Exception {
        if (args[0].equals("PVP")) DurationComparison.main(new String[]{"NEW", "500", args[1]});
        else if (args[0].equals("PVE")) RaidDurationProbe.main(new String[]{"NEW", args[1]});
        else throw new IllegalArgumentException("PVP or PVE");
        try (final var out = Files.newOutputStream(Path.of(args[1] + ".audit.json"), StandardOpenOption.CREATE_NEW)) {
            new ObjectMapper().writerWithDefaultPrettyPrinter().writeValue(out, DurationDamageScale.audit());
        }
    }
}
