package ru.homyakin.seeker.game.battle;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import ru.homyakin.seeker.game.battle.effect.PeriodicDamageEffect;
import ru.homyakin.seeker.game.battle.skill.active_impl.ActiveEnum;
import ru.homyakin.seeker.game.battle.skill.active_impl.CounterAttack;
import ru.homyakin.seeker.game.battle.skill.active_impl.Thorns;
import ru.homyakin.seeker.game.item.models.AttackType;
import ru.homyakin.seeker.game.item.models.Item;
import ru.homyakin.seeker.game.item.models.ItemAttack;
import ru.homyakin.seeker.game.item.models.ItemObject;
import ru.homyakin.seeker.game.item.models.ItemRarity;
import ru.homyakin.seeker.game.personage.models.PersonageSlot;
import ru.homyakin.seeker.utils.RandomUtils;

/** Temporary public-path checks; no production settings, private sink calls or reflection. */
public final class DamageTempoPublicPathProbe {
    private static final int RAW = 101;
    private static final long SEED = 2026110207L;
    private static final List<Map<String, Object>> CHECKS = new ArrayList<>();
    private static final BattleRandom MIDPOINT = (sequence, minimum, maximum) -> {
        if (sequence.startsWith("skill-damage-")) return 0;
        if (sequence.startsWith("normal-damage:")) return minimum + (maximum - minimum) / 2;
        return minimum;
    };

    private DamageTempoPublicPathProbe() { }

    public static void main(String[] args) throws Exception {
        if (args.length != 1) throw new IllegalArgumentException("Specify one unused JSON output path");
        legacyNormal(false);
        legacyNormal(true);
        legacyDirect(false);
        legacyDirect(true);
        legacyPeriodic();
        legacyReaction(false);
        legacyReaction(true);
        orderedScalingSkills();
        mixedLegacyNpc();
        scalingOverkill();
        final var result = new LinkedHashMap<String, Object>();
        result.put("factor", DurationDamageScale.factor());
        result.put("classOrigin", BattlePersonage.class.getProtectionDomain().getCodeSource().getLocation().toString());
        result.put("scope", "Public damage/skill/effect entry points and actual ordered turns; no private sink reflection");
        result.put("checks", CHECKS);
        result.put("sinkAudit", DurationDamageScale.audit());
        try (final var out = Files.newOutputStream(Path.of(args[0]), StandardOpenOption.CREATE_NEW)) {
            new ObjectMapper().writerWithDefaultPrettyPrinter().writeValue(out, result);
        }
    }

    private static BattlePersonage personage(boolean scaling, int health, Map<ActiveEnum, Integer> skills) {
        final var object = new ItemObject("tempo_public_probe", Set.of(PersonageSlot.MAIN_HAND),
            Optional.of(new ItemAttack(AttackType.SLASH, 1, RAW)), Optional.empty(),
            health, 0, 0, 0.0, 100, 0, Map.of());
        final var items = List.of(new Item(object, Optional.empty(), ItemRarity.COMMON));
        return scaling ? BattlePersonage.forScalingSkillsV2Combat(items, Position.FRONT, skills, Optional.empty())
            : new BattlePersonage(items, Position.FRONT, skills);
    }

    /** Independent expression, deliberately does not invoke the production overlay scaling helper. */
    private static int scaled(int value) {
        return Math.toIntExact(((long) value * DurationDamageScale.NUMERATOR + 2L) / 4L);
    }

    private static void legacyNormal(boolean critical) {
        final var source = personage(false, 10000, Map.of());
        final var target = personage(false, 10000, Map.of());
        final var context = new BattleContext(List.of(source), List.of(target));
        final var log = new BattleActionLog();
        final int raw = critical ? 2 * RAW : RAW;
        final int unscaled = RandomUtils.withSeed(SEED, () -> {
            RandomUtils.processChance(0);
            return RandomUtils.getInPercentRange(raw, 10);
        });
        final boolean hit = RandomUtils.withSeed(SEED,
            () -> target.receiveDamageFrom(source, new DamageRoll(Map.of(AttackType.SLASH, raw), critical), log, 1, context));
        require(hit, "Legacy ordinary hit unexpectedly dodged");
        verifySingle("legacy-normal-" + (critical ? "critical" : "ordinary"), target, source,
            log.events(), 10000, scaled(unscaled), true);
    }

    private static void legacyDirect(boolean overkill) {
        final var source = personage(false, 10000, Map.of());
        final var target = personage(false, overkill ? 23 : 10000, Map.of());
        final int before = target.health();
        final int raw = overkill ? 1000000 : RAW;
        final int unscaled = RandomUtils.withSeed(SEED, () -> RandomUtils.getInPercentRange(raw, 10));
        final var events = RandomUtils.withSeed(SEED,
            () -> target.applySkillDamage(AttackType.SLASH, raw, source, ActiveEnum.DOUBLE_ATTACK, 1));
        verifySingle("legacy-direct-" + (overkill ? "overkill" : "ordinary"), target, source,
            events, before, Math.min(before, scaled(unscaled)), true);
        if (overkill) {
            require(target.applySkillDamage(AttackType.SLASH, RAW, source, ActiveEnum.THORNS, 2).isEmpty(),
                "Dead target must not receive skill damage");
            require(target.healAndGetActual(17) == 0 && target.health() == 0, "Healing must not resurrect");
        }
    }

    private static void legacyPeriodic() {
        final var source = personage(false, 10000, Map.of());
        final var target = personage(false, 10000, Map.of());
        final var effect = new PeriodicDamageEffect(AttackType.SLASH, RAW, 1, 2, source.id(), ActiveEnum.BLEEDING);
        final int unscaled = RandomUtils.withSeed(SEED, () -> RandomUtils.getInPercentRange(RAW, 10));
        for (int tick = 1; tick <= 2; tick++) {
            final int round = tick;
            final int before = target.health();
            final var log = new BattleActionLog();
            final boolean exhausted = RandomUtils.withSeed(SEED, () -> effect.tickOnOwnTurnBegin(target, log, round));
            require(exhausted == (tick == 2), "Legacy periodic exhaustion changed");
            verifySingle("legacy-periodic-" + tick, target, source, log.events(), before, scaled(unscaled), false);
        }
    }

    private static long counterSeed() {
        for (long candidate = 0; candidate < 1000; candidate++) {
            final long seed = candidate;
            if (RandomUtils.withSeed(seed, () -> RandomUtils.processChance(50))) return seed;
        }
        throw new AssertionError("No deterministic successful counter seed");
    }

    private static void legacyReaction(boolean counter) {
        final var source = personage(false, 10000, Map.of());
        final var target = personage(false, 10000, Map.of());
        final var context = new BattleContext(List.of(source), List.of(target));
        final long seed = counter ? counterSeed() : SEED;
        final int unscaled = RandomUtils.withSeed(seed, () -> {
            if (counter) {
                require(RandomUtils.processChance(50), "Expected counter trigger");
                RandomUtils.getRandomElement(source.attackTypes());
            }
            return RandomUtils.getInPercentRange(counter ? 10 : 5, 10);
        });
        final var events = RandomUtils.withSeed(seed, () -> counter
            ? new CounterAttack(1).apply(context, source, target, 1)
            : new Thorns(1).apply(context, source, target, 1));
        verifySingle("legacy-" + (counter ? "counter" : "thorns"), target, source, events, 10000, scaled(unscaled), true);
    }

    private static void orderedScalingSkills() {
        final var attacker = personage(true, 10000, Map.of(ActiveEnum.DOUBLE_ATTACK, 1, ActiveEnum.BLEEDING, 1));
        final var defender = personage(true, 10000, Map.of(ActiveEnum.COUNTER_ATTACK, 1, ActiveEnum.THORNS, 1));
        final var context = new BattleContext(List.of(attacker), List.of(defender), MIDPOINT);
        final var log = new BattleActionLog();
        attacker.move(context, log, 1);
        require(defender.scalingBleedings().size() == 1, "Scaling bleeding was not installed");
        // Exercise an old periodic effect inside the new common-turn order, alongside scaling bleeding.
        defender.addPeriodicDamageEffect(new PeriodicDamageEffect(AttackType.SLASH, RAW, 1, 1,
            attacker.id(), ActiveEnum.BLEEDING));
        final int legacyPeriodicUnscaled = RandomUtils.withSeed(SEED, () -> RandomUtils.getInPercentRange(RAW, 10));
        RandomUtils.withSeed(SEED, () -> defender.move(context, log, 2));
        final var seen = verifyLedger("ordered-scaling-and-legacy-periodic", List.of(attacker, defender), log.events(),
            Map.of("effect:BLEEDING", legacyPeriodicUnscaled));
        for (final String required : List.of("normal", "scaling:DOUBLE_ATTACK", "scaling:COUNTER_ATTACK",
            "scaling:THORNS", "scaling-periodic:BLEEDING", "effect:BLEEDING")) {
            require(seen.contains(required), "Missing actual ordered public path " + required);
        }
        require(defender.healAndGetActual(17) == 17, "Healing should remain exactly 17, not scaled");
        CHECKS.add(Map.of("check", "ordered-heal-unchanged", "healed", 17));
    }

    private static void mixedLegacyNpc() {
        final var player = personage(true, 10000, Map.of());
        final var npc = personage(false, 10000, Map.of(ActiveEnum.COUNTER_ATTACK, 1, ActiveEnum.THORNS, 1));
        final var context = new BattleContext(List.of(player), List.of(npc), MIDPOINT);
        require(context.usesScalingSkillOrder() && !npc.usesScalingCombatRules(), "Mixed NPC control setup");
        final long seed = counterSeed();
        final var expected = RandomUtils.withSeed(seed, () -> {
            require(RandomUtils.processChance(50), "Expected counter trigger");
            RandomUtils.getRandomElement(npc.attackTypes());
            final int counter = RandomUtils.getInPercentRange(10, 10);
            final int thorns = RandomUtils.getInPercentRange(5, 10);
            return Map.of("legacy:COUNTER_ATTACK", counter, "legacy:THORNS", thorns);
        });
        final var log = new BattleActionLog();
        RandomUtils.withSeed(seed, () -> player.move(context, log, 1));
        npc.move(context, log, 2);
        final var seen = verifyLedger("mixed-legacy-npc-common-order", List.of(player, npc), log.events(), expected);
        require(seen.containsAll(expected.keySet()), "Missing legacy NPC reactions in common order");
        require(log.events().stream().filter(e -> e instanceof BattleEvent.DamageReceived).count() == 2,
            "Both V2 player and legacy NPC must perform their normal attack");
    }

    private static void scalingOverkill() {
        final var source = personage(true, 10000, Map.of());
        final var target = personage(true, 23, Map.of());
        final var context = new BattleContext(List.of(source), List.of(target), MIDPOINT);
        require(source.expectedDamageAgainst(target) == RAW * DurationDamageScale.factor(),
            "Expected ordinary damage must include the same multiplier");
        final var log = new BattleActionLog();
        source.move(context, log, 1);
        verifyLedger("scaling-ordinary-overkill", List.of(source, target), log.events(), Map.of());
        require(target.health() == 0 && target.actualDamageTaken() == 23, "V2 overkill must be capped at HP");
        require(log.events().stream().filter(e -> e instanceof BattleEvent.PersonageDefeated).count() == 1,
            "Exactly one defeat event after V2 lethal normal damage");
    }

    private static void verifySingle(String name, BattlePersonage target, BattlePersonage source,
                                     List<BattleEvent> events, int healthBefore, int expected, boolean credited) {
        final int actual = events.stream().mapToInt(DamageTempoPublicPathProbe::eventDamage).sum();
        require(actual == expected && healthBefore - target.health() == expected,
            name + " event/health/scaling mismatch: " + actual + " vs " + expected);
        require(target.actualDamageTaken() == target.maxHealth() - target.health(), name + " actual damage tracking");
        if (credited) require(source.battlePersonageStats().damageDealt() == expected, name + " source credit");
        require(events.stream().filter(e -> eventDamage(e) > 0).count() == 1, name + " expected one damage event");
        for (final var event : events) {
            if (event instanceof BattleEvent.DamageReceived e) require(e.remainingHealth() == target.health(), name + " event remaining HP");
            if (event instanceof BattleEvent.SkillDamage e) require(e.remainingHealth() == target.health(), name + " event remaining HP");
            if (event instanceof BattleEvent.EffectDamage e) require(e.remainingHealth() == target.health(), name + " event remaining HP");
        }
        CHECKS.add(Map.of("check", name, "damageEvents", events.stream().filter(e -> eventDamage(e) > 0).count(),
            "actualDamage", actual, "expectedDamage", expected, "remainingHealth", target.health()));
    }

    private static Set<String> verifyLedger(String name, List<BattlePersonage> members, List<BattleEvent> events,
                                          Map<String, Integer> legacyUnscaled) {
        final var health = new LinkedHashMap<UUID, Integer>();
        final var credited = new LinkedHashMap<UUID, Long>();
        final var seen = new java.util.HashSet<String>();
        for (final var member : members) {
            health.put(member.id(), member.maxHealth());
            credited.put(member.id(), 0L);
        }
        for (final var event : events) {
            UUID target;
            UUID source;
            int damage;
            int remaining;
            int unscaled;
            boolean givesCredit = true;
            if (event instanceof BattleEvent.DamageReceived e) {
                target = e.targetId(); source = e.attackerId(); damage = e.damageTaken(); remaining = e.remainingHealth();
                require(!e.roll().crit() && e.roll().amount() == RAW, "Normal attack basis changed before sink");
                unscaled = RAW;
                seen.add("normal");
            } else if (event instanceof BattleEvent.ScalingSkillDamage e) {
                target = e.targetId(); source = e.sourceId(); damage = e.damageTaken(); remaining = e.remainingHealth();
                final int expectedBasis = e.skill() == ActiveEnum.THORNS ? 40 * RAW : RAW;
                require(e.basis().values().stream().mapToInt(Integer::intValue).sum() == expectedBasis,
                    "Skill basis must remain unscaled: " + e.skill());
                final BigInteger numerator = e.basis().values().stream().map(BigInteger::valueOf)
                    .reduce(BigInteger.ZERO, BigInteger::add).multiply(BigInteger.valueOf(e.coefficientNumerator()));
                unscaled = Math.max(1, numerator.divide(BigInteger.valueOf(e.coefficientDenominator())).intValueExact());
                seen.add((e.periodic() ? "scaling-periodic:" : "scaling:") + e.skill());
            } else if (event instanceof BattleEvent.SkillDamage e) {
                target = e.targetId(); source = e.sourceId(); damage = e.damageTaken(); remaining = e.remainingHealth();
                unscaled = legacyUnscaled.get("legacy:" + e.skill());
                seen.add("legacy:" + e.skill());
            } else if (event instanceof BattleEvent.EffectDamage e) {
                target = e.targetId(); source = e.sourceId(); damage = e.damageTaken(); remaining = e.remainingHealth();
                unscaled = legacyUnscaled.get("effect:" + e.skill());
                givesCredit = false;
                seen.add("effect:" + e.skill());
            } else continue;
            final int before = health.get(target);
            final int expected = Math.min(before, scaled(unscaled));
            require(damage == expected && remaining == before - damage,
                name + " event must apply exactly one multiplier: " + event + "; expected=" + expected);
            health.put(target, remaining);
            if (givesCredit) credited.put(source, credited.get(source) + damage);
        }
        for (final var member : members) {
            require(member.health() == health.get(member.id()), name + " event ledger must equal final HP");
            require(member.actualDamageTaken() == member.maxHealth() - member.health(), name + " actual damage counter");
            require(member.battlePersonageStats().damageDealt() == credited.get(member.id()), name + " source credit ledger");
        }
        CHECKS.add(Map.of("check", name, "events", events.size(), "damagePaths", seen.stream().sorted().toList(),
            "remainingHealth", members.stream().map(BattlePersonage::health).toList()));
        return Set.copyOf(seen);
    }

    private static int eventDamage(BattleEvent e) {
        if (e instanceof BattleEvent.DamageReceived d) return d.damageTaken();
        if (e instanceof BattleEvent.SkillDamage d) return d.damageTaken();
        if (e instanceof BattleEvent.ScalingSkillDamage d) return d.damageTaken();
        if (e instanceof BattleEvent.EffectDamage d) return d.damageTaken();
        return 0;
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
