const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const base = __dirname;
const evidence = '/home/user/projects/project-seeker/documentation/raid-redesign-step-12-3-duration-evidence';
const sourceEntries = ['source', 'source-harness', 'old-context-source', 'classes', 'frozen-inputs',
  'independent-validator.cjs', 'analyze-tempo.cjs', 'reproduce.sh', 'archive-manifest.cjs'];
const dataEntries = ['previous'];
for (const n of [4, 5, 6, 7]) {
  for (const prefix of ['pvp', 'pve']) dataEntries.push(`${prefix}-${n}.json`, `${prefix}-${n}.json.audit.json`, `${prefix}-${n}.log`);
  for (const phase of ['screen', 'confirm']) dataEntries.push(`${phase}-${n}-summary.json`, `${phase}-${n}-raw.jsonl.gz`, `${phase}-${n}-cases.json.gz`, `${phase}-${n}.log`);
  for (const prefix of ['probe', 'public-path']) dataEntries.push(`${prefix}-${n}.json`);
}
if (process.argv.includes('--list')) {
  for (const [name, entries] of [['source', sourceEntries], ['data', dataEntries]]) {
    for (const p of entries) if (!fs.existsSync(path.join(base, p))) throw new Error(`Missing ${p}`);
    fs.writeFileSync(path.join(base, `${name}-entries.list0`), entries.join('\0') + '\0');
  }
} else {
  const files = ['analysis.json', 'outcome-changes.tsv', 'independent-validation.json', 'sources.tar.gz', 'measurements.tar.gz'];
  const manifest = {date:'2026-11-02', repositoryHead:'09bb5ef70753e9c95cb3772e4024456ba7d7a208',
    productionChanged:false, jdk:'Axiom OpenJDK25.0.1+11-LTS', node:'24.22.1',
    sourceScope:'Selected public Java/TOML inputs, temporary source/classes and diagnostic fixtures; base repository commit needed for other dependencies',
    selection:'No whole src trees, application profiles, environment dumps or production database contents',
    files:Object.fromEntries(files.map(f => {const data=fs.readFileSync(path.join(evidence,f));
      return [f,{sha256:crypto.createHash('sha256').update(data).digest('hex'),bytes:data.length}];}))};
  fs.writeFileSync(path.join(evidence, 'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
  console.log(JSON.stringify(manifest,null,2));
}
