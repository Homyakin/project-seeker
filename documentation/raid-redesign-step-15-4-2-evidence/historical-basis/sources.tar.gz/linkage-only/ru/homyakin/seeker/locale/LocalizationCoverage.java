package ru.homyakin.seeker.locale;

/**
 * Compile-only isolation of unrelated UI coverage wiring.
 * Never supplies a value: any accidental UI invocation aborts the experiment.
 */
public final class LocalizationCoverage {
    private LocalizationCoverage() {
    }

    public static double coverage(Language language) {
        throw new UnsupportedOperationException("UI localization coverage is outside the historical combat probe");
    }
}
