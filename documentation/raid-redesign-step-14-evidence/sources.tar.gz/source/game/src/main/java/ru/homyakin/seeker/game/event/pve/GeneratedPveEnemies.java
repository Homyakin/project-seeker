package ru.homyakin.seeker.game.event.pve;

import java.util.List;
import java.util.Objects;
import ru.homyakin.seeker.game.battle.BattlePersonage;

public record GeneratedPveEnemies(
    List<BattlePersonage> enemies,
    PveCharacteristicScaling.Result calibration
) {
    public GeneratedPveEnemies {
        enemies = List.copyOf(enemies);
        Objects.requireNonNull(calibration, "calibration");
    }
}
