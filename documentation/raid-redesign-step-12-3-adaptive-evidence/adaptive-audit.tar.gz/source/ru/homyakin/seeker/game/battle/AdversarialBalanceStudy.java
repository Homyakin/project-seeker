package ru.homyakin.seeker.game.battle;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;
import java.util.zip.GZIPOutputStream;
import ru.homyakin.seeker.game.battle.Step123BattleRunner.Gear;
import ru.homyakin.seeker.game.battle.Step12RepresentativeBuilds.Assignment;
import ru.homyakin.seeker.game.battle.Step12RepresentativeBuilds.Build;
import ru.homyakin.seeker.game.battle.simulation.Step12SimulationFixtures.MixedBuild;
import ru.homyakin.seeker.game.battle.simulation.Step12SimulationFixtures.RoleBuild;
import ru.homyakin.seeker.game.battle.skill.active_impl.ActiveEnum;
import ru.homyakin.seeker.game.item.catalog.EquipmentCatalogVersion;
import ru.homyakin.seeker.game.item.models.ItemRarity;

/** Read-only diagnostic; production engine is loaded from the existing verified build. */
public final class AdversarialBalanceStudy {
    private static final ObjectMapper JSON = new ObjectMapper();
    private record Case(String code, String group, String family, int level,
                        List<Gear> left, List<Gear> right, Set<ActiveEnum> disabled) { }

    public static void main(String[] args) throws Exception {
        final var prefix = Path.of(args[0]);
        final int pairs = Integer.getInteger("audit.pairs", 100);
        final long root = Long.getLong("audit.seed", 2026110401L);
        final var filter = Pattern.compile(System.getProperty("audit.filter", ".*"));
        final var summaries = new ArrayList<Map<String, Object>>();
        final var definitions = new ArrayList<Map<String, Object>>();
        final var economy = Step123ReferenceEconomy.configured();
        int count = 0;
        try (var raw = new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(Files.newOutputStream(
            Path.of(prefix + "-raw.jsonl.gz"), StandardOpenOption.CREATE_NEW)), StandardCharsets.UTF_8))) {
            for (final var c : cases().stream().filter(x -> filter.matcher(x.code()).find()).toList()) {
                final var outcomes = new LinkedHashMap<String, Integer>();
                final var rounds = new ArrayList<Integer>();
                final var leftStreak = new ArrayList<Integer>();
                final var rightStreak = new ArrayList<Integer>();
                long violations = 0;
                for (int pair = 0; pair < pairs; pair++) {
                    final long seed = seed(root + c.group().hashCode(), pair);
                    for (final boolean reverse : List.of(false, true)) {
                        final var o = Step123BattleRunner.observe(c.left(), c.right(), c.level(), seed, reverse, 10000, c.disabled(), Set.of());
                        final var movement = Step123CorrectionsStudy.audit(o.initialPositions(), o.events(), reverse);
                        violations += movement.violations();
                        final var leftActors = actors(Step123BattleRunner.lastLeftTeam, o.traces());
                        final var rightActors = actors(Step123BattleRunner.lastRightTeam, o.traces());
                        final int leftMax = leftActors.stream().mapToInt(a -> (int) a.get("maxConsecutiveNonAttackOwnTurns")).max().orElse(0);
                        final int rightMax = rightActors.stream().mapToInt(a -> (int) a.get("maxConsecutiveNonAttackOwnTurns")).max().orElse(0);
                        outcomes.merge(o.outcome(), 1, Integer::sum); rounds.add(o.rounds());
                        leftStreak.add(leftMax); rightStreak.add(rightMax);
                        raw.write(JSON.writeValueAsString(map("case", c.code(), "pair", pair, "reverse", reverse, "seed", seed,
                            "outcome", o.outcome(), "rounds", o.rounds(), "left", o.left(), "right", o.right(),
                            "leftActors", leftActors, "rightActors", rightActors, "moveViolations", movement.violations())));
                        raw.newLine();
                    }
                }
                final var summary = map("case", c.code(), "family", c.family(), "size", c.left().size(), "level", c.level(),
                    "battles", pairs * 2, "outcomes", outcomes, "rounds", stats(rounds),
                    "leftMaxNonAttackOwnTurns", stats(leftStreak), "rightMaxNonAttackOwnTurns", stats(rightStreak),
                    "moveViolations", violations);
                summaries.add(summary);
                definitions.add(map("case", c, "leftEquipment", manifest(c.left(), c.level()), "rightEquipment", manifest(c.right(), c.level()),
                    "leftNominalGold", economy.nominalGold(c.left().stream().flatMap(g -> g.items(c.level()).stream()).toList()),
                    "rightNominalGold", economy.nominalGold(c.right().stream().flatMap(g -> g.items(c.level()).stream()).toList())));
                System.err.println(++count + " " + c.code() + " " + outcomes);
            }
        }
        try (var out = new GZIPOutputStream(Files.newOutputStream(Path.of(prefix + "-cases.json.gz"), StandardOpenOption.CREATE_NEW))) {
            JSON.writeValue(out, definitions);
        }
        JSON.writerWithDefaultPrettyPrinter().writeValue(Files.newOutputStream(Path.of(prefix + "-summary.json"), StandardOpenOption.CREATE_NEW),
            map("rootSeed", root, "pairs", pairs, "catalog", "SCALING_V5", "combat", "SCALING_SKILLS_V3", "tempo", "ACCELERATED_V1",
                "conditions", count, "battles", pairs * 2 * count, "summaries", summaries));
    }

    private static List<Map<String, Object>> actors(List<BattlePersonage> team, List<BattleTraceEvent> trace) {
        final var attempts = new java.util.HashSet<Long>();
        for (final var event : trace) if (event instanceof BattleTraceEvent.NormalAttackAttempt a) attempts.add(a.turnId());
        final var result = new ArrayList<Map<String, Object>>();
        for (int index = 0; index < team.size(); index++) {
            final UUID id = team.get(index).id();
            int own = 0, attack = 0, current = 0, longest = 0;
            for (final var event : trace) {
                if (!(event instanceof BattleTraceEvent.TurnFinished end) || !end.personageId().equals(id) || !end.actionPerformed()) continue;
                own++;
                if (attempts.contains(end.turnId())) { attack++; current = 0; }
                else { current++; longest = Math.max(longest, current); }
            }
            result.add(map("index", index, "ownTurns", own, "normalAttempts", attack,
                "maxConsecutiveNonAttackOwnTurns", longest, "alive", team.get(index).isAlive()));
        }
        return result;
    }

    private static List<Case> cases() {
        final var result = new ArrayList<Case>();
        final var gBuild = Step12RepresentativeBuilds.role(RoleBuild.GUARDIAN);
        final var g = gear(gBuild);
        final var raider = Step12RepresentativeBuilds.mixed(MixedBuild.RAIDER);
        final var bruiser = Step12RepresentativeBuilds.role(RoleBuild.BRUISER);
        final var baseVariants = new LinkedHashMap<String, Gear>();
        for (final var skill : List.of(ActiveEnum.PENETRATION, ActiveEnum.DOUBLE_ATTACK, ActiveEnum.BLEEDING,
            ActiveEnum.ACCUMULATION, ActiveEnum.PRECISE_STRIKE, ActiveEnum.BERSERK)) {
            baseVariants.put(skill.name(), gear(raider.withAssignments(Map.of("rapier", a(skill, ItemRarity.RARE),
                "hood", a(ActiveEnum.HIT_AND_RUN, ItemRarity.RARE)))));
        }
        baseVariants.put("HIR4", gear(raider.withAssignments(Map.of("hood", a(ActiveEnum.HIT_AND_RUN, ItemRarity.RARE),
            "cloth_boots", a(ActiveEnum.HIT_AND_RUN, ItemRarity.RARE)))));
        baseVariants.put("FIVE_POINTS", gear(raider.withAssignments(Map.of("rapier", a(ActiveEnum.DOUBLE_ATTACK, ItemRarity.RARE),
            "hood", a(ActiveEnum.HIT_AND_RUN, ItemRarity.UNCOMMON), "cloth_boots", a(ActiveEnum.HIT_AND_RUN, ItemRarity.UNCOMMON),
            "robe", a(ActiveEnum.SELF_HEAL, ItemRarity.UNCOMMON)))));
        baseVariants.put("SIX_UNCOMMON", gear(raider.withAssignments(Map.of("rapier", a(ActiveEnum.BLEEDING, ItemRarity.UNCOMMON),
            "dirk", a(ActiveEnum.DOUBLE_ATTACK, ItemRarity.UNCOMMON), "hood", a(ActiveEnum.HIT_AND_RUN, ItemRarity.UNCOMMON),
            "cloth_boots", a(ActiveEnum.HIT_AND_RUN, ItemRarity.UNCOMMON), "robe", a(ActiveEnum.SELF_HEAL, ItemRarity.UNCOMMON),
            "cloth_chausses", a(ActiveEnum.SELF_HEAL, ItemRarity.UNCOMMON)))));
        final var heal = gear(bruiser.withAssignments(Map.of("sledgehammer", a(ActiveEnum.BERSERK, ItemRarity.RARE),
            "breastplate", a(ActiveEnum.SELF_HEAL, ItemRarity.RARE))));
        final var heavyVariants = new LinkedHashMap<String, Gear>();
        for (final var skill : List.of(ActiveEnum.PENETRATION, ActiveEnum.DOUBLE_ATTACK, ActiveEnum.BLEEDING,
            ActiveEnum.ACCUMULATION, ActiveEnum.PRECISE_STRIKE, ActiveEnum.BERSERK)) {
            heavyVariants.put(skill.name(), gear(raider.withAssignments(Map.of("rapier", a(skill, ItemRarity.LEGENDARY),
                "dirk", a(skill, ItemRarity.LEGENDARY), "hood", a(ActiveEnum.HIT_AND_RUN, ItemRarity.LEGENDARY),
                "cloth_boots", a(ActiveEnum.HIT_AND_RUN, ItemRarity.LEGENDARY)))));
        }
        heavyVariants.put("DOUBLE_BLEED", gear(raider.withAssignments(Map.of("rapier", a(ActiveEnum.DOUBLE_ATTACK, ItemRarity.LEGENDARY),
            "dirk", a(ActiveEnum.BLEEDING, ItemRarity.LEGENDARY), "hood", a(ActiveEnum.HIT_AND_RUN, ItemRarity.LEGENDARY),
            "cloth_boots", a(ActiveEnum.HIT_AND_RUN, ItemRarity.LEGENDARY)))));
        final var heavyHeal = gear(bruiser.withAssignments(Map.of("sledgehammer", a(ActiveEnum.BERSERK, ItemRarity.LEGENDARY),
            "breastplate", a(ActiveEnum.SELF_HEAL, ItemRarity.LEGENDARY), "leather_chausses", a(ActiveEnum.SELF_HEAL, ItemRarity.LEGENDARY),
            "leather_gloves", a(ActiveEnum.FEINT, ItemRarity.LEGENDARY))));
        for (final int level : List.of(0, 6)) for (final int size : List.of(3, 7, 15)) {
            for (final var entry : baseVariants.entrySet()) result.add(new Case("BASE_" + entry.getKey() + "_N" + size + "_L" + level,
                "BASE_N" + size + "_L" + level, "ADAPTIVE_BASE", level, team(g, entry.getValue(), size), team(g, heal, size), Set.of()));
            for (final var entry : heavyVariants.entrySet()) result.add(new Case("HEAVY_" + entry.getKey() + "_N" + size + "_L" + level,
                "HEAVY_N" + size + "_L" + level, "ADAPTIVE_HEAVY", level, team(g, entry.getValue(), size), team(g, heavyHeal, size), Set.of()));
        }
        record Reply(String code, String weapon, String armor, Position position) { }
        for (final var reply : List.of(new Reply("COMMAND_LEATHER", "command_staff", "LEATHER", Position.FRONT),
            new Reply("COMMAND_PLATE", "command_staff", "PLATE", Position.FRONT),
            new Reply("LONGBOW_PLATE", "longbow", "PLATE", Position.BACK),
            new Reply("BATTLE_ARCANE", "battle_staff", "ARCANE", Position.BACK))) {
            final var armor = Step12RepresentativeBuilds.armor(reply.armor());
            final var handSkill = reply.position() == Position.FRONT ? ActiveEnum.BERSERK : ActiveEnum.DOUBLE_ATTACK;
            final var counterBuild = Step12RepresentativeBuilds.hand("RESPONSE_" + reply.code(), List.of(reply.weapon()),
                reply.armor(), reply.position(), ru.homyakin.seeker.game.battle.targeting.TargetingTactic.WOUNDED_HUNTER);
            final var rareCounter = gear(counterBuild.withAssignments(Map.of(reply.weapon(), a(handSkill, ItemRarity.RARE),
                armor.get(0), a(ActiveEnum.SELF_HEAL, ItemRarity.RARE))));
            final var legendaryCounter = gear(counterBuild.withAssignments(Map.of(reply.weapon(), a(handSkill, ItemRarity.LEGENDARY),
                armor.get(0), a(ActiveEnum.SELF_HEAL, ItemRarity.LEGENDARY), armor.get(1), a(ActiveEnum.SELF_HEAL, ItemRarity.LEGENDARY),
                armor.get(4), a(reply.position() == Position.FRONT ? ActiveEnum.FEINT : ActiveEnum.THORNS, ItemRarity.LEGENDARY))));
            for (final int level : List.of(0, 6)) for (final int size : List.of(7, 15)) {
                for (final var variant : List.of("BLEEDING", "SIX_UNCOMMON")) {
                    result.add(new Case("RESPONSE_BASE_" + variant + "_" + reply.code() + "_N" + size + "_L" + level,
                        "RESPONSE_BASE_N" + size + "_L" + level, "ADAPTIVE_RESPONSE", level,
                        team(g, baseVariants.get(variant), size), team(g, rareCounter, size), Set.of()));
                }
                for (final var variant : List.of("BLEEDING", "DOUBLE_BLEED")) {
                    result.add(new Case("RESPONSE_HEAVY_" + variant + "_" + reply.code() + "_N" + size + "_L" + level,
                        "RESPONSE_HEAVY_N" + size + "_L" + level, "ADAPTIVE_RESPONSE", level,
                        team(g, heavyVariants.get(variant), size), team(g, legendaryCounter, size), Set.of()));
                }
            }
        }
        for (final var rarity : List.of(ItemRarity.RARE, ItemRarity.LEGENDARY)) for (final int size : List.of(3, 7, 15)) {
            final var guard = gear(Step12RepresentativeRisks.ranked("G", rarity));
            final var blocker = gear(Step12RepresentativeRisks.ranked("K", rarity));
            final var target = gear(Step12RepresentativeRisks.ranked("C", rarity));
            for (final boolean off : List.of(false, true)) {
                final var group = "KNOCK_" + rarity + "_N" + size;
                result.add(new Case(group + (off ? "_OFF" : "_ON"), group, "MASS_KNOCKBACK", 6,
                    team(guard, blocker, size), team(guard, target, size), off ? Set.of(ActiveEnum.KNOCKBACK) : Set.of()));
            }
        }
        result.sort(Comparator.comparing(Case::code));
        return result;
    }

    private static Gear gear(Build build) { return new Gear(build, EquipmentCatalogVersion.SCALING_V5); }
    private static Assignment a(ActiveEnum skill, ItemRarity rarity) { return new Assignment(skill, rarity); }
    private static List<Gear> team(Gear guard, Gear member, int size) {
        final var list = new ArrayList<Gear>(); list.add(guard);
        for (int i = 1; i < size; i++) list.add(member);
        return List.copyOf(list);
    }
    private static List<Object> manifest(List<Gear> team, int level) {
        return team.stream().map(g -> (Object) map("build", g.build(), "catalog", g.catalog(), "items", g.items(level).stream().map(i ->
            map("code", i.object().code(), "rarity", i.rarity(), "level", i.enhanceLevel(), "points", i.modifier().isPresent() ? i.skillPoints() : 0,
                "skill", i.modifier().map(m -> m.activeEnum().name()).orElse("NONE"), "health", i.health(), "speed", i.speed(),
                "attacks", i.itemAttacks(), "defense", i.itemDefense().map(d -> map("type", d.defenseType(), "value", d.defense())).orElse(null)))
            .toList())).toList();
    }
    private static Map<String, Object> stats(List<Integer> samples) {
        final var values = samples.stream().mapToInt(Integer::intValue).sorted().toArray();
        return map("median", (values[(values.length - 1) / 2] + values[values.length / 2]) / 2.0,
            "p95", values[(int) Math.ceil(values.length * .95) - 1], "max", values[values.length - 1],
            "mean", samples.stream().mapToInt(Integer::intValue).average().orElseThrow());
    }
    private static long seed(long value, int iteration) {
        long x = value + 0x9e3779b97f4a7c15L * (iteration + 1L);
        x = (x ^ x >>> 30) * 0xbf58476d1ce4e5b9L;
        x = (x ^ x >>> 27) * 0x94d049bb133111ebL;
        return x ^ x >>> 31;
    }
    private static Map<String, Object> map(Object... pairs) {
        final var result = new LinkedHashMap<String, Object>();
        for (int i = 0; i < pairs.length; i += 2) result.put((String) pairs[i], pairs[i + 1]);
        return result;
    }
}
